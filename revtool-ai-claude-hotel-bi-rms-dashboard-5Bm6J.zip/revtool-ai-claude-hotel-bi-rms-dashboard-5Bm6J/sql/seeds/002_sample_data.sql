-- ============================================================================
-- REVTOOL AI - Sample Seed Data
-- Description: Minimal sample data for development and testing
--
-- No dimension tables to seed (except dim_hotels).
-- Segments, channels, room types, meal plans, and countries are all
-- embedded as text directly in fact tables.
--
-- Users table is minimal (only upn).
-- user_hotel_access is just upn + hotel_name (no access levels).
-- No billing_config or billing_monthly tables.
-- ============================================================================

-- Sample hotels
-- Hotel Playa Dorada: Fully configured (setup_complete = TRUE)
-- Hotel Sierra Nevada Resort: Configured (setup_complete = TRUE)
-- Hotel Costa Luz: Not configured yet (setup_complete = FALSE, only name)
INSERT INTO dim_hotels (hotel_name, hotel_type, target_client, destination, province, city, country, total_rooms, currency, setup_complete, setup_by, setup_at) VALUES
    ('Hotel Playa Dorada', 'vacation', 'family', 'Mallorca', 'Islas Baleares', 'Palma', 'ES', 200, 'EUR', TRUE, 'rm.mallorca@hotel.com', '2026-01-15 10:00:00+01'),
    ('Hotel Sierra Nevada Resort', 'mixed', 'mixed', 'Sierra Nevada', 'Granada', 'Sierra Nevada', 'ES', 120, 'EUR', TRUE, 'rm.granada@hotel.com', '2026-01-20 14:30:00+01'),
    ('Hotel Costa Luz', NULL, NULL, NULL, NULL, NULL, 'ES', NULL, 'EUR', FALSE, NULL, NULL)
ON CONFLICT (hotel_name) DO NOTHING;

-- Sample users (authenticated via Microsoft Entra ID)
-- Minimal: only upn needed
INSERT INTO users (upn) VALUES
    ('admin@revtool.com'),
    ('rm.mallorca@hotel.com'),
    ('rm.granada@hotel.com'),
    ('director@hotel.com')
ON CONFLICT (upn) DO NOTHING;

-- Sample hotel access (text keys: upn + hotel_name, binary access)
-- Admin: access to all hotels
INSERT INTO user_hotel_access (upn, hotel_name) VALUES
    ('admin@revtool.com', 'Hotel Playa Dorada'),
    ('admin@revtool.com', 'Hotel Sierra Nevada Resort'),
    ('admin@revtool.com', 'Hotel Costa Luz'),
    ('rm.mallorca@hotel.com', 'Hotel Playa Dorada'),
    ('rm.granada@hotel.com', 'Hotel Sierra Nevada Resort'),
    ('director@hotel.com', 'Hotel Playa Dorada'),
    ('director@hotel.com', 'Hotel Sierra Nevada Resort'),
    ('director@hotel.com', 'Hotel Costa Luz')
ON CONFLICT (upn, hotel_name) DO NOTHING;

-- Sample credit balances (prepaid, keyed by UPN)
INSERT INTO credit_balance (upn, balance_eur, total_topped_up, total_consumed, low_balance_alert) VALUES
    ('admin@revtool.com', 100.00, 100.00, 0, 5.00),
    ('rm.mallorca@hotel.com', 25.00, 50.00, 25.00, 2.00),
    ('rm.granada@hotel.com', 0.50, 10.00, 9.50, 2.00),
    ('director@hotel.com', 0.00, 30.00, 30.00, 2.00)
ON CONFLICT (upn) DO NOTHING;

-- Sample credit transactions
INSERT INTO credit_transactions (upn, transaction_type, amount_eur, balance_after, description, created_by) VALUES
    ('admin@revtool.com', 'topup', 100.00, 100.00, 'Carga inicial admin', 'system'),
    ('rm.mallorca@hotel.com', 'topup', 50.00, 50.00, 'Recarga de 50€ vía Stripe', 'stripe_webhook'),
    ('rm.mallorca@hotel.com', 'consumption', -25.00, 25.00, 'Consumo acumulado febrero 2026', 'system'),
    ('rm.granada@hotel.com', 'topup', 10.00, 10.00, 'Recarga de 10€ vía Stripe', 'stripe_webhook'),
    ('rm.granada@hotel.com', 'consumption', -9.50, 0.50, 'Consumo acumulado febrero 2026', 'system'),
    ('director@hotel.com', 'topup', 30.00, 30.00, 'Recarga de 30€ vía Stripe', 'stripe_webhook'),
    ('director@hotel.com', 'consumption', -30.00, 0.00, 'Consumo acumulado — saldo agotado', 'system');

-- ============================================================================
-- BENCHMARK SECTORIAL - Sample data
-- ============================================================================

-- Update sample hotels with benchmark configuration
-- Hotel Playa Dorada: Spain → Upscale → Mallorca → benchmark_available = TRUE
-- Hotel Sierra Nevada Resort: Spain → Upper Midscale → Sierra Nevada → benchmark_available = TRUE
-- Hotel Costa Luz: not configured yet (setup_complete = FALSE)
-- Note: ALL Spain hotels have benchmark_available = TRUE (all combinations covered)
UPDATE dim_hotels SET
    benchmark_category = 'Upscale',
    benchmark_country  = 'España',
    benchmark_ccaa     = 'Islas Baleares',
    benchmark_province = 'Islas Baleares',
    benchmark_zone     = 'Mallorca',
    benchmark_available = TRUE
WHERE hotel_name = 'Hotel Playa Dorada';

UPDATE dim_hotels SET
    benchmark_category = 'Upper Midscale',
    benchmark_country  = 'España',
    benchmark_ccaa     = 'Andalucía',
    benchmark_province = 'Granada',
    benchmark_zone     = 'Sierra Nevada',
    benchmark_available = TRUE
WHERE hotel_name = 'Hotel Sierra Nevada Resort';

-- Sample benchmark sectorial data
-- Coverage: Islas Baleares (Mallorca), Andalucía (Costa del Sol, Sierra Nevada)
-- All Spain geographic combinations are covered in production
INSERT INTO benchmark_sectorial (country, ccaa, province, zone, category, year, month_num, occ, adr, revpar, occ_ly, adr_ly, revpar_ly, yoy_occ, yoy_adr, yoy_revpar) VALUES
    -- Mallorca, Upscale — 2025 (past, crystallized)
    ('España', 'Islas Baleares', 'Islas Baleares', 'Mallorca', 'Upscale', 2025, 1,  42.30, 95.00,  40.19, 40.10, 90.00, 36.09,  2.20,  5.56, 11.36),
    ('España', 'Islas Baleares', 'Islas Baleares', 'Mallorca', 'Upscale', 2025, 2,  45.80, 98.50,  45.11, 43.50, 93.00, 40.46,  2.30,  5.91, 11.49),
    ('España', 'Islas Baleares', 'Islas Baleares', 'Mallorca', 'Upscale', 2025, 3,  55.20, 110.00, 60.72, 52.00, 105.00, 54.60, 3.20,  4.76, 11.21),
    ('España', 'Islas Baleares', 'Islas Baleares', 'Mallorca', 'Upscale', 2025, 4,  68.90, 135.00, 93.02, 65.50, 128.00, 83.84, 3.40,  5.47, 10.95),
    ('España', 'Islas Baleares', 'Islas Baleares', 'Mallorca', 'Upscale', 2025, 5,  78.40, 155.00, 121.52, 75.20, 148.00, 111.30, 3.20, 4.73, 9.18),
    ('España', 'Islas Baleares', 'Islas Baleares', 'Mallorca', 'Upscale', 2025, 6,  88.50, 185.00, 163.73, 86.00, 178.00, 153.08, 2.50, 3.93, 6.96),
    ('España', 'Islas Baleares', 'Islas Baleares', 'Mallorca', 'Upscale', 2025, 7,  94.20, 220.00, 207.24, 92.80, 210.00, 194.88, 1.40, 4.76, 6.34),
    ('España', 'Islas Baleares', 'Islas Baleares', 'Mallorca', 'Upscale', 2025, 8,  95.80, 230.00, 220.34, 94.50, 222.00, 209.79, 1.30, 3.60, 5.03),
    ('España', 'Islas Baleares', 'Islas Baleares', 'Mallorca', 'Upscale', 2025, 9,  82.10, 170.00, 139.57, 80.00, 162.00, 129.60, 2.10, 4.94, 7.69),
    ('España', 'Islas Baleares', 'Islas Baleares', 'Mallorca', 'Upscale', 2025, 10, 65.30, 130.00, 84.89,  63.00, 125.00, 78.75,  2.30, 4.00, 7.80),
    ('España', 'Islas Baleares', 'Islas Baleares', 'Mallorca', 'Upscale', 2025, 11, 48.50, 100.00, 48.50,  46.20, 95.00,  43.89,  2.30, 5.26, 10.50),
    ('España', 'Islas Baleares', 'Islas Baleares', 'Mallorca', 'Upscale', 2025, 12, 44.10, 105.00, 46.31,  42.00, 100.00, 42.00,  2.10, 5.00, 10.25),

    -- Mallorca, Upscale — 2026 (past months crystallized, future months projected)
    ('España', 'Islas Baleares', 'Islas Baleares', 'Mallorca', 'Upscale', 2026, 1,  44.50, 100.00, 44.50,  42.30, 95.00,  40.19,  2.20, 5.26, 10.72),
    ('España', 'Islas Baleares', 'Islas Baleares', 'Mallorca', 'Upscale', 2026, 2,  48.00, 103.00, 49.44,  45.80, 98.50,  45.11,  2.20, 4.57, 9.60),
    ('España', 'Islas Baleares', 'Islas Baleares', 'Mallorca', 'Upscale', 2026, 3,  57.50, 115.00, 66.13,  55.20, 110.00, 60.72,  2.30, 4.55, 8.90),
    ('España', 'Islas Baleares', 'Islas Baleares', 'Mallorca', 'Upscale', 2026, 4,  71.00, 140.00, 99.40,  68.90, 135.00, 93.02,  2.10, 3.70, 6.86),
    ('España', 'Islas Baleares', 'Islas Baleares', 'Mallorca', 'Upscale', 2026, 5,  80.50, 160.00, 128.80, 78.40, 155.00, 121.52, 2.10, 3.23, 5.99),
    ('España', 'Islas Baleares', 'Islas Baleares', 'Mallorca', 'Upscale', 2026, 6,  90.00, 190.00, 171.00, 88.50, 185.00, 163.73, 1.50, 2.70, 4.44),
    ('España', 'Islas Baleares', 'Islas Baleares', 'Mallorca', 'Upscale', 2026, 7,  95.00, 225.00, 213.75, 94.20, 220.00, 207.24, 0.80, 2.27, 3.14),
    ('España', 'Islas Baleares', 'Islas Baleares', 'Mallorca', 'Upscale', 2026, 8,  96.50, 235.00, 226.78, 95.80, 230.00, 220.34, 0.70, 2.17, 2.92),
    ('España', 'Islas Baleares', 'Islas Baleares', 'Mallorca', 'Upscale', 2026, 9,  84.00, 175.00, 147.00, 82.10, 170.00, 139.57, 1.90, 2.94, 5.32),
    ('España', 'Islas Baleares', 'Islas Baleares', 'Mallorca', 'Upscale', 2026, 10, 67.00, 135.00, 90.45,  65.30, 130.00, 84.89,  1.70, 3.85, 6.55),
    ('España', 'Islas Baleares', 'Islas Baleares', 'Mallorca', 'Upscale', 2026, 11, 50.00, 105.00, 52.50,  48.50, 100.00, 48.50,  1.50, 5.00, 8.25),
    ('España', 'Islas Baleares', 'Islas Baleares', 'Mallorca', 'Upscale', 2026, 12, 46.00, 110.00, 50.60,  44.10, 105.00, 46.31,  1.90, 4.76, 9.27),

    -- Costa del Sol, Upscale — 2026 (additional geographic coverage)
    ('España', 'Andalucía', 'Málaga', 'Costa del Sol', 'Upscale', 2026, 1,  52.00, 105.00, 54.60,  50.00, 100.00, 50.00,  2.00, 5.00, 9.20),
    ('España', 'Andalucía', 'Málaga', 'Costa del Sol', 'Upscale', 2026, 2,  55.30, 110.00, 60.83,  53.00, 105.00, 55.65,  2.30, 4.76, 9.31),
    ('España', 'Andalucía', 'Málaga', 'Costa del Sol', 'Upscale', 2026, 3,  62.00, 125.00, 77.50,  59.50, 120.00, 71.40,  2.50, 4.17, 8.54),
    ('España', 'Andalucía', 'Málaga', 'Costa del Sol', 'Upscale', 2026, 4,  72.50, 145.00, 105.13, 70.00, 138.00, 96.60,  2.50, 5.07, 8.83),
    ('España', 'Andalucía', 'Málaga', 'Costa del Sol', 'Upscale', 2026, 5,  78.00, 158.00, 123.24, 75.80, 150.00, 113.70, 2.20, 5.33, 8.39),
    ('España', 'Andalucía', 'Málaga', 'Costa del Sol', 'Upscale', 2026, 6,  85.50, 180.00, 153.90, 83.00, 172.00, 142.76, 2.50, 4.65, 7.81),

    -- Sierra Nevada, Upper Midscale — 2026 (ski resort, seasonal pattern)
    ('España', 'Andalucía', 'Granada', 'Sierra Nevada', 'Upper Midscale', 2026, 1,  72.00, 88.00,  63.36,  69.50, 84.00,  58.38,  2.50, 4.76, 8.53),
    ('España', 'Andalucía', 'Granada', 'Sierra Nevada', 'Upper Midscale', 2026, 2,  78.50, 95.00,  74.58,  76.00, 90.00,  68.40,  2.50, 5.56, 9.03),
    ('España', 'Andalucía', 'Granada', 'Sierra Nevada', 'Upper Midscale', 2026, 3,  65.00, 82.00,  53.30,  62.50, 78.00,  48.75,  2.50, 5.13, 9.33),
    ('España', 'Andalucía', 'Granada', 'Sierra Nevada', 'Upper Midscale', 2026, 4,  35.00, 65.00,  22.75,  33.00, 62.00,  20.46,  2.00, 4.84, 11.20),
    ('España', 'Andalucía', 'Granada', 'Sierra Nevada', 'Upper Midscale', 2026, 5,  25.00, 55.00,  13.75,  23.50, 52.00,  12.22,  1.50, 5.77, 12.52),
    ('España', 'Andalucía', 'Granada', 'Sierra Nevada', 'Upper Midscale', 2026, 6,  30.00, 60.00,  18.00,  28.00, 57.00,  15.96,  2.00, 5.26, 12.78)
ON CONFLICT (country, ccaa, province, zone, category, year, month_num) DO NOTHING;

-- ============================================================================
-- PRICING STRATEGY BY ROOM TYPE - Sample data
-- ============================================================================

-- Hotel Playa Dorada: manages pricing by room type (advanced approach)
-- Each room type has independent signals for the same dates.
-- This demonstrates how different room types can have different recommendations.
INSERT INTO daily_pricing_strategy_by_roomtype (hotel_name, stay_date, room_type_name, close_intermediaries, price_delta, rooms_remaining, rooms_remaining_diff_prev, rooms_remaining_diff_next) VALUES
    -- 2026-03-01: Doble Estándar almost full (PEAK), Superior has room, Suite relaxed
    ('Hotel Playa Dorada', '2026-03-01', 'Doble Estándar',     TRUE,  15,  5,  8,  6),
    ('Hotel Playa Dorada', '2026-03-01', 'Doble Superior',     FALSE,  8, 15,  3,  2),
    ('Hotel Playa Dorada', '2026-03-01', 'Junior Suite',       FALSE,  0, 10, -2, -1),
    ('Hotel Playa Dorada', '2026-03-01', 'Suite',              FALSE, -5,  8, -3, -4),

    -- 2026-03-02: Doble Estándar still tight, Superior picking up, Suite valley
    ('Hotel Playa Dorada', '2026-03-02', 'Doble Estándar',     TRUE,  12,  8,  6,  4),
    ('Hotel Playa Dorada', '2026-03-02', 'Doble Superior',     FALSE, 10, 12,  2,  5),
    ('Hotel Playa Dorada', '2026-03-02', 'Junior Suite',       FALSE,  0, 11, -1,  0),
    ('Hotel Playa Dorada', '2026-03-02', 'Suite',              FALSE, -8, 12, -4, -3),

    -- 2026-07-15: High season — all room types strong
    ('Hotel Playa Dorada', '2026-07-15', 'Doble Estándar',     TRUE,  25,  3, 10, 12),
    ('Hotel Playa Dorada', '2026-07-15', 'Doble Superior',     TRUE,  20,  5,  8,  9),
    ('Hotel Playa Dorada', '2026-07-15', 'Junior Suite',       TRUE,  15,  4,  5,  6),
    ('Hotel Playa Dorada', '2026-07-15', 'Suite',              FALSE, 10,  6,  2,  3)
ON CONFLICT (hotel_name, stay_date, room_type_name) DO NOTHING;
