-- =============================================================================
-- 017_custom_email_reports.sql
-- User-defined custom email reports with personal prompts.
--
-- Each custom report belongs to a single user (upn). The email is sent ONLY
-- to that user — never to other users with access to the same hotel.
-- The user is charged individually for each execution.
--
-- A custom report can be associated with multiple hotels via the junction
-- table custom_email_report_hotels.
-- =============================================================================

CREATE TABLE IF NOT EXISTS custom_email_reports (
    id              SERIAL          PRIMARY KEY,
    upn             VARCHAR(200)    NOT NULL REFERENCES users(upn),
    title           VARCHAR(100)    NOT NULL,
    prompt          TEXT            NOT NULL,
    weekdays        SMALLINT        NOT NULL DEFAULT 62,  -- bitmask: bit0=Mon..bit6=Sun
    active          BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE custom_email_reports IS
    'User-defined email reports with custom prompts. Private to each user.';

COMMENT ON COLUMN custom_email_reports.weekdays IS
    'Bitmask of active weekdays. 1=Mon, 2=Tue, 4=Wed, 8=Thu, 16=Fri, 32=Sat, 64=Sun. Default 62 = Mon-Fri.';

CREATE INDEX IF NOT EXISTS idx_custom_reports_upn
    ON custom_email_reports (upn);

-- Junction table: which hotels receive each custom report
CREATE TABLE IF NOT EXISTS custom_email_report_hotels (
    custom_report_id  INT             NOT NULL REFERENCES custom_email_reports(id) ON DELETE CASCADE,
    hotel_name        VARCHAR(200)    NOT NULL,
    PRIMARY KEY (custom_report_id, hotel_name)
);

CREATE INDEX IF NOT EXISTS idx_custom_report_hotels_hotel
    ON custom_email_report_hotels (hotel_name);

GRANT SELECT, INSERT, UPDATE, DELETE ON custom_email_reports TO revtool_ai;
GRANT USAGE, SELECT ON SEQUENCE custom_email_reports_id_seq TO revtool_ai;
GRANT SELECT, INSERT, DELETE ON custom_email_report_hotels TO revtool_ai;
