-- ============================================================================
-- REVTOOL AI - Campaign Profiles (Marketing Intelligence)
-- Description: Historical booking profiles by nationality and occupancy type,
-- segmented by booking window (anticipation). Used by the AI to recommend
-- campaign targeting when users ask about marketing actions.
--
-- PURPOSE: Answer "Who should I target with campaigns for month X?"
-- This table captures HOW guests booked in the previous 12 months:
-- which nationalities, what occupancy type (individual/couples/families),
-- how far in advance they booked, what their average length of stay was,
-- and their share of total room nights.
--
-- DATA COVERAGE: Rolling 12-month retrospective (no year column).
-- The data aggregates the previous 12 months of actual bookings to define
-- booking profiles. Since it's always a rolling window, there is no year
-- dimension — the profiles represent "how guests have been booking recently"
-- regardless of calendar year boundaries.
--
-- WORKFLOW:
-- 1. User asks: "I want to launch a campaign for guests staying in August"
-- 2. AI calculates booking_window from current month vs stay month:
--    months_diff = stay_month - current_month (adjusted for year wrap)
--    Maps to the corresponding booking_window range (see BOOKING WINDOW below)
-- 3. AI queries this table: hotel + month_num + booking_window
-- 4. Result: ranked list of (country, occupancy_type) profiles with share_rn
--    and avg_length_of_stay
-- 5. AI cross-references the MIXED ADR (all channels combined) from
--    monthly_hotel_summary for the target stay month and applies a +30%
--    markup to suggest a public selling price (PVP). Using the mixed ADR
--    as the base ensures that any booking captured at the campaign PVP
--    will contribute to increasing the hotel's overall average ADR.
-- 6. AI presents the campaign recommendation with targeting, suggested stay
--    duration, and suggested PVP (with disclaimer for user validation)
--
-- BOOKING WINDOW (booking_window):
-- Fixed text ranges representing how far in advance guests booked:
--   'en el mes'                  → booked in the same month as stay (0 months)
--   'entre 1 y 2 meses antes'   → booked 1-2 months before stay
--   'entre 2 y 3 meses antes'   → booked 2-3 months before stay
--   'entre 3 y 4 meses antes'   → booked 3-4 months before stay
--   'entre 4 y 5 meses antes'   → booked 4-5 months before stay
--   'entre 5 y 6 meses antes'   → booked 5-6 months before stay
--   'entre 6 y 7 meses antes'   → booked 6-7 months before stay
--   'entre 7 y 8 meses antes'   → booked 7-8 months before stay
--   'entre 8 y 12 meses antes'  → booked 8-12 months before stay
--
-- AI BOOKING WINDOW CALCULATION:
-- months_diff = stay_month_num - current_month_num
-- If months_diff < 0: months_diff = months_diff + 12 (wraps across year boundary)
-- Mapping:
--   0     → 'en el mes'
--   1     → 'entre 1 y 2 meses antes'
--   2     → 'entre 2 y 3 meses antes'
--   3     → 'entre 3 y 4 meses antes'
--   4     → 'entre 4 y 5 meses antes'
--   5     → 'entre 5 y 6 meses antes'
--   6     → 'entre 6 y 7 meses antes'
--   7     → 'entre 7 y 8 meses antes'
--   8-11  → 'entre 8 y 12 meses antes'
--
-- OCCUPANCY TYPE (occupancy_type):
-- Describes room occupancy pattern, which defines campaign targeting:
--   'Individual'  → Room occupied by 1 person (single traveler campaigns)
--   'Adultos'     → Room occupied by 2 persons (couples campaigns)
--   'Familias'    → Room occupied by 3+ persons (family campaigns)
--
-- SHARE_RN:
-- Percentage of total room nights for the given hotel + month + booking_window.
-- Higher share = stronger historical demand from that profile = primary target.
-- The AI should present profiles ordered by share_rn descending and focus
-- campaign recommendations on the top contributors.
--
-- AVG_LENGTH_OF_STAY:
-- Average stay duration in whole nights for that profile. This tells the campaign
-- manager what stay duration to configure in the campaign offer.
-- Example: avg_length_of_stay = 4 → "Configure the campaign for 4-night stays"
-- ============================================================================

CREATE TABLE IF NOT EXISTS campaign_profiles (
    hotel_name              VARCHAR(200) NOT NULL REFERENCES dim_hotels(hotel_name),
    month_num               SMALLINT NOT NULL CHECK (month_num BETWEEN 1 AND 12),

    -- Booking anticipation range (how far in advance guests booked)
    booking_window          VARCHAR(30) NOT NULL CHECK (booking_window IN (
                                'en el mes',
                                'entre 1 y 2 meses antes',
                                'entre 2 y 3 meses antes',
                                'entre 3 y 4 meses antes',
                                'entre 4 y 5 meses antes',
                                'entre 5 y 6 meses antes',
                                'entre 6 y 7 meses antes',
                                'entre 7 y 8 meses antes',
                                'entre 8 y 12 meses antes'
                            )),

    -- Occupancy type (defines campaign audience)
    occupancy_type          VARCHAR(20) NOT NULL CHECK (occupancy_type IN (
                                'Individual',
                                'Adultos',
                                'Familias'
                            )),

    -- Guest nationality (text, same convention as monthly_hotel_guest_country)
    country_name            VARCHAR(100) NOT NULL,

    -- Share of room nights (% contribution, base 100: e.g., 25.95 = 25.95%)
    share_rn                DECIMAL(5,2) NOT NULL DEFAULT 0,

    -- Average length of stay in whole nights (stay duration for campaign configuration)
    avg_length_of_stay      SMALLINT NOT NULL DEFAULT 0,

    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),

    PRIMARY KEY(hotel_name, month_num, booking_window, occupancy_type, country_name)
);

-- Primary query pattern: hotel + month + booking_window → list of profiles
CREATE INDEX idx_campaign_profiles_query
    ON campaign_profiles(hotel_name, month_num, booking_window);

-- Secondary: lookup by country across hotels (portfolio-level country analysis)
CREATE INDEX idx_campaign_profiles_country
    ON campaign_profiles(hotel_name, country_name);

-- ---------------------------------------------------------------------------
-- Extend dim_hotels with marketing highlights for campaign briefs
-- Free-text field where users describe their hotel's key selling points
-- (e.g., 'Sea views, infinity pool, kids club, direct beach access').
-- Used by the AI to personalize campaign copy and image prompts.
-- ---------------------------------------------------------------------------
ALTER TABLE dim_hotels ADD COLUMN IF NOT EXISTS marketing_highlights TEXT;
