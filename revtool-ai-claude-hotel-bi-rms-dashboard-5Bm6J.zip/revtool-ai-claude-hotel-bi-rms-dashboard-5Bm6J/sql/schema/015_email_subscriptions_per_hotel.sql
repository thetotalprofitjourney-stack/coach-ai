-- =============================================================================
-- 015_email_subscriptions_per_hotel.sql
-- Rebuild email_report_subscriptions with per-hotel granularity and weekday
-- scheduling.
--
-- New PK: (upn, hotel_name, report_type)
-- New column: weekdays SMALLINT bitmask (bit 0=Mon .. bit 6=Sun, 127=all)
--
-- The cron runs daily; build_report_queue filters rows where the current
-- weekday bit is set.
-- =============================================================================

-- Drop old table (no production data yet — table was created in 014)
DROP TABLE IF EXISTS email_report_subscriptions;

CREATE TABLE email_report_subscriptions (
    upn             VARCHAR(200)    NOT NULL,
    hotel_name      VARCHAR(200)    NOT NULL,
    report_type     SMALLINT        NOT NULL CHECK (report_type IN (1, 2, 3, 4)),
    weekdays        SMALLINT        NOT NULL DEFAULT 62,
    enabled         BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    PRIMARY KEY (upn, hotel_name, report_type),
    FOREIGN KEY (upn) REFERENCES users(upn),
    FOREIGN KEY (upn, hotel_name) REFERENCES user_hotel_access(upn, hotel_name)
);

COMMENT ON TABLE email_report_subscriptions IS
    'Per-hotel, per-report-type email subscriptions with weekday scheduling. weekdays is a bitmask: bit0=Mon(1), bit1=Tue(2), ..., bit6=Sun(64). Default 62 = Mon-Fri.';

COMMENT ON COLUMN email_report_subscriptions.weekdays IS
    'Bitmask of active weekdays. 1=Mon, 2=Tue, 4=Wed, 8=Thu, 16=Fri, 32=Sat, 64=Sun. Default 62 = Mon-Fri.';

CREATE INDEX IF NOT EXISTS idx_ers_hotel_report
    ON email_report_subscriptions (hotel_name, report_type);

GRANT SELECT, INSERT, UPDATE, DELETE ON email_report_subscriptions TO revtool_ai;
