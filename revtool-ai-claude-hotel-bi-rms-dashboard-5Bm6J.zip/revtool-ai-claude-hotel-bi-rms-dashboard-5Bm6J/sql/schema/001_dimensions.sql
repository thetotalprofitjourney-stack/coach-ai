-- ============================================================================
-- REVTOOL AI - Hotel Dimension (only dimension table)
-- Description: Hotel catalog with descriptive metadata.
-- All other "dimensions" (segments, channels, room types, meal plans, countries)
-- are embedded as text directly in fact tables — PowerBI sends names, not IDs.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- dim_hotels: Hotel catalog with descriptive metadata
-- PK is hotel_name (the unique business identifier from PowerBI).
-- Initially only hotel_name + active are loaded.
-- Descriptive fields are configured by users via the web form (⚙️ button).
-- Once any user with access completes the setup, setup_complete = TRUE
-- and other users won't be prompted again.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dim_hotels (
    hotel_name      VARCHAR(200) PRIMARY KEY,       -- Unique hotel name from PowerBI (the business key)

    -- Descriptive fields (configured via web form ⚙️)
    hotel_type      VARCHAR(20) CHECK (hotel_type IN ('vacation', 'urban', 'mixed')),
    target_client   VARCHAR(20) CHECK (target_client IN ('family', 'adults_only', 'mixed')),
    destination     VARCHAR(100),                    -- Tourist destination (e.g., 'Mallorca', 'Costa del Sol')
    province        VARCHAR(100),                    -- Province/region (e.g., 'Islas Baleares', 'Málaga')
    city            VARCHAR(100),                    -- City (used by AI for local event resolution)
    country         VARCHAR(5) DEFAULT 'ES',         -- ISO country code
    total_rooms     INT,                             -- Total room inventory (optional, derivable from daily data)
    currency        VARCHAR(3) DEFAULT 'EUR',        -- Hotel's operating currency
    marketing_highlights TEXT,                        -- Free-text bullet points for campaign briefs (e.g., 'Sea views, Infinity pool, Kids club')

    -- Setup tracking (web form onboarding)
    setup_complete  BOOLEAN DEFAULT FALSE,           -- TRUE once descriptive fields configured via web form
    setup_by        VARCHAR(200),                    -- UPN of user who completed the setup
    setup_at        TIMESTAMPTZ,                     -- When setup was completed

    active          BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- NOTE: No dim_calendar table. The AI resolves dates, holidays, events
-- (Semana Santa, San Fermín, Feria de Abril, etc.) from its own knowledge
-- or via web search, then queries fact tables with concrete date ranges.

-- NOTE: No dim_segments, dim_channels, dim_room_types, dim_meal_plans, or
-- dim_guest_countries tables. PowerBI sends text names (not IDs) for all
-- dimensions. These are embedded directly in the fact tables. This eliminates
-- the need for ID resolution during ETL — Power Automate just sends text.
