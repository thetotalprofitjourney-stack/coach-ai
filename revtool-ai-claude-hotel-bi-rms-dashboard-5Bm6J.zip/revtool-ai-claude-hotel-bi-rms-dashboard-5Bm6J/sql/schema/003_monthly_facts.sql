-- ============================================================================
-- REVTOOL AI - Monthly Fact Tables (Layer 2)
-- Description: Monthly aggregations for high-level queries
-- Pre-aggregated to avoid summing 30 daily rows per query
--
-- DATA COVERAGE: previous year, current year, and next year.
-- Example: if today is 2026-02-23, data spans Jan 2025 → Dec 2027.
--
-- All dimension references use TEXT names (not integer IDs).
-- CRITICAL: ADR, occupancy, and cancellation rates are RECALCULATED from
-- base values (SUM revenue / SUM rn), NEVER averaged from daily ratios.
--
-- DIMENSIONAL BREAKDOWNS (segment, channel, roomtype, mealplan, country):
-- ALL dimension values are stored — no top-5 limit at monthly level.
-- This complements the daily tables (which only store the top 5 per dimension
-- per day for volume optimization). Monthly tables are the source of truth for
-- full dimensional analysis across all segments, channels, room types, meal plans
-- and guest countries.
--
-- Carry the SAME metric set as monthly_hotel_summary.
-- ALL include occupancy fields (occ_*).
-- ALL include share fields (share_rn_otb, share_revenue_otb,
-- share_rn_sdly, share_revenue_sdly) — percentage contribution of each dimension
-- to the hotel total. SDLY shares enable YoY mix shift analysis.
-- rooms_available ONLY in summary (hotel-level) and
-- roomtype (physical inventory per type).
-- For segment/channel/mealplan/country: occ = rn / hotel rooms_available.
-- For roomtype: occ = rn / that room type's own rooms_available.
--
-- No is_closed field. The AI derives open/closed status dynamically:
--   (year < current_year) OR (year = current_year AND month_num < current_month)
--   → closed (crystallized actual result)
--   Otherwise → open (still evolving)
-- ============================================================================

-- ----------------------------------------------------------------------------
-- monthly_hotel_summary: One row per hotel per month
-- Mirrors daily_hotel_summary structure, aggregated to month level
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS monthly_hotel_summary (
    hotel_name              VARCHAR(200) NOT NULL REFERENCES dim_hotels(hotel_name),
    year                    SMALLINT NOT NULL,
    month_num               SMALLINT NOT NULL,

    -- Month metadata
    rooms_available         INT NOT NULL,              -- SUM(rooms_available) for all days in month

    -- ── OTB ──
    rn_otb                  INT NOT NULL DEFAULT 0,
    revenue_otb             DECIMAL(16,2) NOT NULL DEFAULT 0,
    adr_otb                 DECIMAL(10,2) NOT NULL DEFAULT 0,
    occ_otb                 DECIMAL(5,2) NOT NULL DEFAULT 0,

    -- ── OTB Projected ──
    rn_otb_proj             INT NOT NULL DEFAULT 0,
    revenue_otb_proj        DECIMAL(16,2) NOT NULL DEFAULT 0,
    adr_otb_proj            DECIMAL(10,2) NOT NULL DEFAULT 0,
    occ_otb_proj            DECIMAL(5,2) NOT NULL DEFAULT 0,

    -- ── SDLY Gross ──
    rn_sdly_gross           INT,
    revenue_sdly_gross      DECIMAL(16,2),
    adr_sdly_gross          DECIMAL(10,2),
    occ_sdly_gross          DECIMAL(5,2),

    -- ── SDLY Net ──
    rn_sdly_net             INT,
    revenue_sdly_net        DECIMAL(16,2),
    adr_sdly_net            DECIMAL(10,2),
    occ_sdly_net            DECIMAL(5,2),

    -- ── LY (crystallized) ──
    rn_ly                   INT,
    revenue_ly              DECIMAL(16,2),
    adr_ly                  DECIMAL(10,2),
    occ_ly                  DECIMAL(5,2),

    -- ── Forecast ──
    rn_forecast             INT,
    revenue_forecast        DECIMAL(16,2),
    adr_forecast            DECIMAL(10,2),
    occ_forecast            DECIMAL(5,2),

    -- ── Budget ──
    rn_budget               INT,
    revenue_budget          DECIMAL(16,2),
    adr_budget              DECIMAL(10,2),
    occ_budget              DECIMAL(5,2),

    -- ── Pickup 7d ──
    pickup_rn_7d            INT NOT NULL DEFAULT 0,
    pickup_rev_7d           DECIMAL(16,2) NOT NULL DEFAULT 0,
    pickup_rn_7d_sdly       INT,
    pickup_rev_7d_sdly      DECIMAL(16,2),

    -- ── Pickup 1d ──
    pickup_rn_1d            INT NOT NULL DEFAULT 0,
    pickup_rev_1d           DECIMAL(16,2) NOT NULL DEFAULT 0,
    pickup_rn_1d_sdly       INT,
    pickup_rev_1d_sdly      DECIMAL(16,2),

    -- ── Cancellations: window ──
    cancel_rn_7d            INT NOT NULL DEFAULT 0,
    cancel_rev_7d           DECIMAL(16,2),
    cancel_rn_1d            INT NOT NULL DEFAULT 0,
    cancel_rev_1d           DECIMAL(16,2),

    -- ── Cancellations: cumulative rates ──
    cancel_rate_otb         DECIMAL(5,2) NOT NULL DEFAULT 0,
    cancel_rate_sdly        DECIMAL(5,2),
    cancel_rate_ly          DECIMAL(5,2),

    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),

    PRIMARY KEY(hotel_name, year, month_num)
);

CREATE INDEX idx_monthly_summary_hotel_year ON monthly_hotel_summary(hotel_name, year);

-- ----------------------------------------------------------------------------
-- monthly_hotel_segment: Monthly metrics by market segment
-- Occupancy = rn / hotel rooms_available (contribution to hotel occupancy).
-- No rooms_available — use summary for denominator.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS monthly_hotel_segment (
    hotel_name              VARCHAR(200) NOT NULL REFERENCES dim_hotels(hotel_name),
    year                    SMALLINT NOT NULL,
    month_num               SMALLINT NOT NULL,
    segment_name            VARCHAR(100) NOT NULL,

    -- ── OTB ──
    rn_otb                  INT NOT NULL DEFAULT 0,
    revenue_otb             DECIMAL(16,2) NOT NULL DEFAULT 0,
    adr_otb                 DECIMAL(10,2) NOT NULL DEFAULT 0,

    -- ── OTB Projected ──
    rn_otb_proj             INT NOT NULL DEFAULT 0,
    revenue_otb_proj        DECIMAL(16,2) NOT NULL DEFAULT 0,
    adr_otb_proj            DECIMAL(10,2) NOT NULL DEFAULT 0,

    -- ── SDLY Gross ──
    rn_sdly_gross           INT,
    revenue_sdly_gross      DECIMAL(16,2),
    adr_sdly_gross          DECIMAL(10,2),

    -- ── SDLY Net ──
    rn_sdly_net             INT,
    revenue_sdly_net        DECIMAL(16,2),
    adr_sdly_net            DECIMAL(10,2),

    -- ── LY ──
    rn_ly                   INT,
    revenue_ly              DECIMAL(16,2),
    adr_ly                  DECIMAL(10,2),

    -- ── Forecast ──
    rn_forecast             INT,
    revenue_forecast        DECIMAL(16,2),
    adr_forecast            DECIMAL(10,2),

    -- ── Budget ──
    rn_budget               INT,
    revenue_budget          DECIMAL(16,2),
    adr_budget              DECIMAL(10,2),

    -- ── Occupancy (vs hotel total room nights) ──
    occ_otb                 DECIMAL(5,2),
    occ_otb_proj            DECIMAL(5,2),
    occ_sdly_gross          DECIMAL(5,2),
    occ_sdly_net            DECIMAL(5,2),
    occ_ly                  DECIMAL(5,2),
    occ_forecast            DECIMAL(5,2),
    occ_budget              DECIMAL(5,2),

    -- ── Pickup 7d ──
    pickup_rn_7d            INT NOT NULL DEFAULT 0,
    pickup_rev_7d           DECIMAL(16,2) NOT NULL DEFAULT 0,
    pickup_rn_7d_sdly       INT,
    pickup_rev_7d_sdly      DECIMAL(16,2),

    -- ── Pickup 1d ──
    pickup_rn_1d            INT NOT NULL DEFAULT 0,
    pickup_rev_1d           DECIMAL(16,2) NOT NULL DEFAULT 0,
    pickup_rn_1d_sdly       INT,
    pickup_rev_1d_sdly      DECIMAL(16,2),

    -- ── Cancellations: window ──
    cancel_rn_7d            INT NOT NULL DEFAULT 0,
    cancel_rev_7d           DECIMAL(16,2),
    cancel_rn_1d            INT NOT NULL DEFAULT 0,
    cancel_rev_1d           DECIMAL(16,2),

    -- ── Cancellations: cumulative rates ──
    cancel_rate_otb         DECIMAL(5,2) NOT NULL DEFAULT 0,
    cancel_rate_sdly        DECIMAL(5,2),
    cancel_rate_ly          DECIMAL(5,2),

    -- ── Shares (% of hotel total for this month) ──
    share_rn_otb            DECIMAL(5,2),
    share_revenue_otb       DECIMAL(5,2),
    share_rn_sdly           DECIMAL(5,2),              -- SDLY gross share, for YoY mix shift analysis
    share_revenue_sdly      DECIMAL(5,2),

    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),

    PRIMARY KEY(hotel_name, year, month_num, segment_name)
);

CREATE INDEX idx_monthly_segment_hotel ON monthly_hotel_segment(hotel_name, year, month_num);

-- ----------------------------------------------------------------------------
-- monthly_hotel_channel: Monthly metrics by distribution channel
-- Occupancy = rn / hotel rooms_available.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS monthly_hotel_channel (
    hotel_name              VARCHAR(200) NOT NULL REFERENCES dim_hotels(hotel_name),
    year                    SMALLINT NOT NULL,
    month_num               SMALLINT NOT NULL,
    channel_name            VARCHAR(200) NOT NULL,

    -- ── OTB ──
    rn_otb                  INT NOT NULL DEFAULT 0,
    revenue_otb             DECIMAL(16,2) NOT NULL DEFAULT 0,
    adr_otb                 DECIMAL(10,2) NOT NULL DEFAULT 0,

    -- ── OTB Projected ──
    rn_otb_proj             INT NOT NULL DEFAULT 0,
    revenue_otb_proj        DECIMAL(16,2) NOT NULL DEFAULT 0,
    adr_otb_proj            DECIMAL(10,2) NOT NULL DEFAULT 0,

    -- ── SDLY Gross ──
    rn_sdly_gross           INT,
    revenue_sdly_gross      DECIMAL(16,2),
    adr_sdly_gross          DECIMAL(10,2),

    -- ── SDLY Net ──
    rn_sdly_net             INT,
    revenue_sdly_net        DECIMAL(16,2),
    adr_sdly_net            DECIMAL(10,2),

    -- ── LY ──
    rn_ly                   INT,
    revenue_ly              DECIMAL(16,2),
    adr_ly                  DECIMAL(10,2),

    -- ── Forecast ──
    rn_forecast             INT,
    revenue_forecast        DECIMAL(16,2),
    adr_forecast            DECIMAL(10,2),

    -- ── Budget ──
    rn_budget               INT,
    revenue_budget          DECIMAL(16,2),
    adr_budget              DECIMAL(10,2),

    -- ── Occupancy (vs hotel total room nights) ──
    occ_otb                 DECIMAL(5,2),
    occ_otb_proj            DECIMAL(5,2),
    occ_sdly_gross          DECIMAL(5,2),
    occ_sdly_net            DECIMAL(5,2),
    occ_ly                  DECIMAL(5,2),
    occ_forecast            DECIMAL(5,2),
    occ_budget              DECIMAL(5,2),

    -- ── Pickup 7d ──
    pickup_rn_7d            INT NOT NULL DEFAULT 0,
    pickup_rev_7d           DECIMAL(16,2) NOT NULL DEFAULT 0,
    pickup_rn_7d_sdly       INT,
    pickup_rev_7d_sdly      DECIMAL(16,2),

    -- ── Pickup 1d ──
    pickup_rn_1d            INT NOT NULL DEFAULT 0,
    pickup_rev_1d           DECIMAL(16,2) NOT NULL DEFAULT 0,
    pickup_rn_1d_sdly       INT,
    pickup_rev_1d_sdly      DECIMAL(16,2),

    -- ── Cancellations: window ──
    cancel_rn_7d            INT NOT NULL DEFAULT 0,
    cancel_rev_7d           DECIMAL(16,2),
    cancel_rn_1d            INT NOT NULL DEFAULT 0,
    cancel_rev_1d           DECIMAL(16,2),

    -- ── Cancellations: cumulative rates ──
    cancel_rate_otb         DECIMAL(5,2) NOT NULL DEFAULT 0,
    cancel_rate_sdly        DECIMAL(5,2),
    cancel_rate_ly          DECIMAL(5,2),

    -- ── Shares (% of hotel total for this month) ──
    share_rn_otb            DECIMAL(5,2),
    share_revenue_otb       DECIMAL(5,2),
    share_rn_sdly           DECIMAL(5,2),              -- SDLY gross share, for YoY mix shift analysis
    share_revenue_sdly      DECIMAL(5,2),

    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),

    PRIMARY KEY(hotel_name, year, month_num, channel_name)
);

CREATE INDEX idx_monthly_channel_hotel ON monthly_hotel_channel(hotel_name, year, month_num);

-- ----------------------------------------------------------------------------
-- monthly_hotel_roomtype: Monthly metrics by room type
-- rooms_available = SUM(rooms_available) for all days of this room type in month
-- Occupancy = rn / this room type's rooms_available (NOT hotel total)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS monthly_hotel_roomtype (
    hotel_name              VARCHAR(200) NOT NULL REFERENCES dim_hotels(hotel_name),
    year                    SMALLINT NOT NULL,
    month_num               SMALLINT NOT NULL,
    room_type_name          VARCHAR(100) NOT NULL,

    -- ── OTB ──
    rn_otb                  INT NOT NULL DEFAULT 0,
    revenue_otb             DECIMAL(16,2) NOT NULL DEFAULT 0,
    adr_otb                 DECIMAL(10,2) NOT NULL DEFAULT 0,

    -- ── OTB Projected ──
    rn_otb_proj             INT NOT NULL DEFAULT 0,
    revenue_otb_proj        DECIMAL(16,2) NOT NULL DEFAULT 0,
    adr_otb_proj            DECIMAL(10,2) NOT NULL DEFAULT 0,

    -- ── SDLY Gross ──
    rn_sdly_gross           INT,
    revenue_sdly_gross      DECIMAL(16,2),
    adr_sdly_gross          DECIMAL(10,2),

    -- ── SDLY Net ──
    rn_sdly_net             INT,
    revenue_sdly_net        DECIMAL(16,2),
    adr_sdly_net            DECIMAL(10,2),

    -- ── LY ──
    rn_ly                   INT,
    revenue_ly              DECIMAL(16,2),
    adr_ly                  DECIMAL(10,2),

    -- ── Forecast ──
    rn_forecast             INT,
    revenue_forecast        DECIMAL(16,2),
    adr_forecast            DECIMAL(10,2),

    -- ── Budget ──
    rn_budget               INT,
    revenue_budget          DECIMAL(16,2),
    adr_budget              DECIMAL(10,2),

    -- ── Capacity & Occupancy (per room type's own inventory) ──
    rooms_available         INT,                       -- SUM(rooms_available) for this room type in month
    occ_otb                 DECIMAL(5,2),
    occ_otb_proj            DECIMAL(5,2),
    occ_sdly_gross          DECIMAL(5,2),
    occ_sdly_net            DECIMAL(5,2),
    occ_ly                  DECIMAL(5,2),
    occ_forecast            DECIMAL(5,2),
    occ_budget              DECIMAL(5,2),

    -- ── Pickup 7d ──
    pickup_rn_7d            INT NOT NULL DEFAULT 0,
    pickup_rev_7d           DECIMAL(16,2) NOT NULL DEFAULT 0,
    pickup_rn_7d_sdly       INT,
    pickup_rev_7d_sdly      DECIMAL(16,2),

    -- ── Pickup 1d ──
    pickup_rn_1d            INT NOT NULL DEFAULT 0,
    pickup_rev_1d           DECIMAL(16,2) NOT NULL DEFAULT 0,
    pickup_rn_1d_sdly       INT,
    pickup_rev_1d_sdly      DECIMAL(16,2),

    -- ── Cancellations: window ──
    cancel_rn_7d            INT NOT NULL DEFAULT 0,
    cancel_rev_7d           DECIMAL(16,2),
    cancel_rn_1d            INT NOT NULL DEFAULT 0,
    cancel_rev_1d           DECIMAL(16,2),

    -- ── Cancellations: cumulative rates ──
    cancel_rate_otb         DECIMAL(5,2) NOT NULL DEFAULT 0,
    cancel_rate_sdly        DECIMAL(5,2),
    cancel_rate_ly          DECIMAL(5,2),

    -- ── Shares (% of hotel total for this month) ──
    share_rn_otb            DECIMAL(5,2),
    share_revenue_otb       DECIMAL(5,2),
    share_rn_sdly           DECIMAL(5,2),              -- SDLY gross share, for YoY mix shift analysis
    share_revenue_sdly      DECIMAL(5,2),

    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),

    PRIMARY KEY(hotel_name, year, month_num, room_type_name)
);

CREATE INDEX idx_monthly_roomtype_hotel ON monthly_hotel_roomtype(hotel_name, year, month_num);

-- ----------------------------------------------------------------------------
-- monthly_hotel_mealplan: Monthly metrics by meal plan
-- Occupancy = rn / hotel rooms_available.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS monthly_hotel_mealplan (
    hotel_name              VARCHAR(200) NOT NULL REFERENCES dim_hotels(hotel_name),
    year                    SMALLINT NOT NULL,
    month_num               SMALLINT NOT NULL,
    meal_plan_name          VARCHAR(50) NOT NULL,

    -- ── OTB ──
    rn_otb                  INT NOT NULL DEFAULT 0,
    revenue_otb             DECIMAL(16,2) NOT NULL DEFAULT 0,
    adr_otb                 DECIMAL(10,2) NOT NULL DEFAULT 0,

    -- ── OTB Projected ──
    rn_otb_proj             INT NOT NULL DEFAULT 0,
    revenue_otb_proj        DECIMAL(16,2) NOT NULL DEFAULT 0,
    adr_otb_proj            DECIMAL(10,2) NOT NULL DEFAULT 0,

    -- ── SDLY Gross ──
    rn_sdly_gross           INT,
    revenue_sdly_gross      DECIMAL(16,2),
    adr_sdly_gross          DECIMAL(10,2),

    -- ── SDLY Net ──
    rn_sdly_net             INT,
    revenue_sdly_net        DECIMAL(16,2),
    adr_sdly_net            DECIMAL(10,2),

    -- ── LY ──
    rn_ly                   INT,
    revenue_ly              DECIMAL(16,2),
    adr_ly                  DECIMAL(10,2),

    -- ── Forecast ──
    rn_forecast             INT,
    revenue_forecast        DECIMAL(16,2),
    adr_forecast            DECIMAL(10,2),

    -- ── Budget ──
    rn_budget               INT,
    revenue_budget          DECIMAL(16,2),
    adr_budget              DECIMAL(10,2),

    -- ── Occupancy (vs hotel total room nights) ──
    occ_otb                 DECIMAL(5,2),
    occ_otb_proj            DECIMAL(5,2),
    occ_sdly_gross          DECIMAL(5,2),
    occ_sdly_net            DECIMAL(5,2),
    occ_ly                  DECIMAL(5,2),
    occ_forecast            DECIMAL(5,2),
    occ_budget              DECIMAL(5,2),

    -- ── Pickup 7d ──
    pickup_rn_7d            INT NOT NULL DEFAULT 0,
    pickup_rev_7d           DECIMAL(16,2) NOT NULL DEFAULT 0,
    pickup_rn_7d_sdly       INT,
    pickup_rev_7d_sdly      DECIMAL(16,2),

    -- ── Pickup 1d ──
    pickup_rn_1d            INT NOT NULL DEFAULT 0,
    pickup_rev_1d           DECIMAL(16,2) NOT NULL DEFAULT 0,
    pickup_rn_1d_sdly       INT,
    pickup_rev_1d_sdly      DECIMAL(16,2),

    -- ── Cancellations: window ──
    cancel_rn_7d            INT NOT NULL DEFAULT 0,
    cancel_rev_7d           DECIMAL(16,2),
    cancel_rn_1d            INT NOT NULL DEFAULT 0,
    cancel_rev_1d           DECIMAL(16,2),

    -- ── Cancellations: cumulative rates ──
    cancel_rate_otb         DECIMAL(5,2) NOT NULL DEFAULT 0,
    cancel_rate_sdly        DECIMAL(5,2),
    cancel_rate_ly          DECIMAL(5,2),

    -- ── Shares (% of hotel total for this month) ──
    share_rn_otb            DECIMAL(5,2),
    share_revenue_otb       DECIMAL(5,2),
    share_rn_sdly           DECIMAL(5,2),              -- SDLY gross share, for YoY mix shift analysis
    share_revenue_sdly      DECIMAL(5,2),

    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),

    PRIMARY KEY(hotel_name, year, month_num, meal_plan_name)
);

CREATE INDEX idx_monthly_mealplan_hotel ON monthly_hotel_mealplan(hotel_name, year, month_num);

-- ----------------------------------------------------------------------------
-- monthly_hotel_guest_country: Monthly metrics by guest nationality
-- country_name is embedded directly (no dimension table).
-- Occupancy = rn / hotel rooms_available.
--
-- IMPORTANT: Guest country data is ONLY RELIABLE for closed months.
-- For open/future months, many bookings won't have guest country assigned
-- until check-in. The AI derives closed status dynamically from today's date
-- and must warn about this limitation when analyzing open months.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS monthly_hotel_guest_country (
    hotel_name              VARCHAR(200) NOT NULL REFERENCES dim_hotels(hotel_name),
    year                    SMALLINT NOT NULL,
    month_num               SMALLINT NOT NULL,
    country_name            VARCHAR(100) NOT NULL,

    -- ── OTB ──
    rn_otb                  INT NOT NULL DEFAULT 0,
    revenue_otb             DECIMAL(16,2) NOT NULL DEFAULT 0,
    adr_otb                 DECIMAL(10,2) NOT NULL DEFAULT 0,

    -- ── OTB Projected ──
    rn_otb_proj             INT NOT NULL DEFAULT 0,
    revenue_otb_proj        DECIMAL(16,2) NOT NULL DEFAULT 0,
    adr_otb_proj            DECIMAL(10,2) NOT NULL DEFAULT 0,

    -- ── SDLY Gross ──
    rn_sdly_gross           INT,
    revenue_sdly_gross      DECIMAL(16,2),
    adr_sdly_gross          DECIMAL(10,2),

    -- ── SDLY Net ──
    rn_sdly_net             INT,
    revenue_sdly_net        DECIMAL(16,2),
    adr_sdly_net            DECIMAL(10,2),

    -- ── LY ──
    rn_ly                   INT,
    revenue_ly              DECIMAL(16,2),
    adr_ly                  DECIMAL(10,2),

    -- ── Forecast ──
    rn_forecast             INT,
    revenue_forecast        DECIMAL(16,2),
    adr_forecast            DECIMAL(10,2),

    -- ── Budget ──
    rn_budget               INT,
    revenue_budget          DECIMAL(16,2),
    adr_budget              DECIMAL(10,2),

    -- ── Occupancy (vs hotel total room nights) ──
    occ_otb                 DECIMAL(5,2),
    occ_otb_proj            DECIMAL(5,2),
    occ_sdly_gross          DECIMAL(5,2),
    occ_sdly_net            DECIMAL(5,2),
    occ_ly                  DECIMAL(5,2),
    occ_forecast            DECIMAL(5,2),
    occ_budget              DECIMAL(5,2),

    -- ── Pickup 7d ──
    pickup_rn_7d            INT NOT NULL DEFAULT 0,
    pickup_rev_7d           DECIMAL(16,2) NOT NULL DEFAULT 0,
    pickup_rn_7d_sdly       INT,
    pickup_rev_7d_sdly      DECIMAL(16,2),

    -- ── Pickup 1d ──
    pickup_rn_1d            INT NOT NULL DEFAULT 0,
    pickup_rev_1d           DECIMAL(16,2) NOT NULL DEFAULT 0,
    pickup_rn_1d_sdly       INT,
    pickup_rev_1d_sdly      DECIMAL(16,2),

    -- ── Cancellations: window ──
    cancel_rn_7d            INT NOT NULL DEFAULT 0,
    cancel_rev_7d           DECIMAL(16,2),
    cancel_rn_1d            INT NOT NULL DEFAULT 0,
    cancel_rev_1d           DECIMAL(16,2),

    -- ── Cancellations: cumulative rates ──
    cancel_rate_otb         DECIMAL(5,2) NOT NULL DEFAULT 0,
    cancel_rate_sdly        DECIMAL(5,2),
    cancel_rate_ly          DECIMAL(5,2),

    -- ── Shares (% of hotel total for this month) ──
    share_rn_otb            DECIMAL(5,2),
    share_revenue_otb       DECIMAL(5,2),
    share_rn_sdly           DECIMAL(5,2),              -- SDLY gross share, for YoY mix shift analysis
    share_revenue_sdly      DECIMAL(5,2),

    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),

    PRIMARY KEY(hotel_name, year, month_num, country_name)
);

CREATE INDEX idx_monthly_guest_country_hotel ON monthly_hotel_guest_country(hotel_name, year, month_num);
