-- =============================================================================
-- 018_user_hotel_access_cascade_and_sync.sql
--
-- Problem: TRUNCATE on user_hotel_access deletes ALL email_report_subscriptions
-- because of the FK constraint, even for users whose access hasn't changed.
--
-- Solution:
--   1. Change FK to ON DELETE CASCADE so only DELETED rows cascade.
--   2. Replace TRUNCATE with a sync procedure that:
--      a) Loads new data into a temp table
--      b) DELETEs only rows that no longer exist (CASCADE cleans subscriptions)
--      c) INSERTs new rows that didn't exist before
--
-- Result: Only subscriptions for revoked user+hotel pairs are removed.
-- =============================================================================

-- Step 1: Recreate the FK with ON DELETE CASCADE
-- -----------------------------------------------
ALTER TABLE email_report_subscriptions
    DROP CONSTRAINT IF EXISTS email_report_subscriptions_upn_hotel_name_fkey;

ALTER TABLE email_report_subscriptions
    ADD CONSTRAINT email_report_subscriptions_upn_hotel_name_fkey
    FOREIGN KEY (upn, hotel_name)
    REFERENCES user_hotel_access(upn, hotel_name)
    ON DELETE CASCADE;

-- Step 2: Sync procedure for Power Automate
-- ------------------------------------------
-- Usage from Power Automate:
--   1. CREATE TEMP TABLE _uha_staging (upn VARCHAR(200), hotel_name VARCHAR(200));
--   2. INSERT INTO _uha_staging VALUES ('user@domain.com', 'Hotel Name'), ...;
--   3. SELECT sync_user_hotel_access();   -- or pass a tenant filter
--   4. The temp table is auto-dropped at end of session.
--
-- For multi-tenant: pass the list of hotel_names owned by this tenant
-- so we only delete stale rows for THIS tenant's hotels, not others.
-- ------------------------------------------

CREATE OR REPLACE FUNCTION sync_user_hotel_access(
    p_tenant_hotels TEXT[] DEFAULT NULL
)
RETURNS TABLE(deleted_count INT, inserted_count INT) AS $$
DECLARE
    v_deleted INT;
    v_inserted INT;
BEGIN
    -- Delete rows that no longer exist in the staging data.
    -- If p_tenant_hotels is provided, only touch rows for those hotels
    -- (multi-tenant safe: won't delete another tenant's rows).
    IF p_tenant_hotels IS NOT NULL THEN
        DELETE FROM user_hotel_access uha
        WHERE uha.hotel_name = ANY(p_tenant_hotels)
          AND NOT EXISTS (
              SELECT 1 FROM _uha_staging s
              WHERE s.upn = uha.upn AND s.hotel_name = uha.hotel_name
          );
    ELSE
        DELETE FROM user_hotel_access uha
        WHERE NOT EXISTS (
            SELECT 1 FROM _uha_staging s
            WHERE s.upn = uha.upn AND s.hotel_name = uha.hotel_name
        );
    END IF;
    GET DIAGNOSTICS v_deleted = ROW_COUNT;

    -- Insert new rows that don't exist yet
    INSERT INTO user_hotel_access (upn, hotel_name)
    SELECT s.upn, s.hotel_name
    FROM _uha_staging s
    ON CONFLICT (upn, hotel_name) DO NOTHING;
    GET DIAGNOSTICS v_inserted = ROW_COUNT;

    RETURN QUERY SELECT v_deleted, v_inserted;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION sync_user_hotel_access IS
    'Syncs user_hotel_access from _uha_staging temp table. Deletes revoked access (cascades to email_report_subscriptions), inserts new access. Pass p_tenant_hotels to scope deletes to one tenant.';
