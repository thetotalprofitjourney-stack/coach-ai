-- =============================================================================
-- 019_custom_report_hotel_access_cascade.sql
--
-- Problem: When a user_hotel_access row is deleted (e.g. via sync_user_hotel_access),
-- the corresponding custom_email_report_hotels rows are NOT cleaned up.
-- This leaves custom reports in an "active but empty" state — they won't execute
-- (because the INNER JOIN produces zero rows), but they appear active in the UI
-- with no hotels assigned, which is confusing.
--
-- Solution: Add a trigger on user_hotel_access AFTER DELETE that:
--   1. Removes matching rows from custom_email_report_hotels
--   2. Deactivates any custom reports that now have zero hotels
-- =============================================================================

CREATE OR REPLACE FUNCTION cascade_uha_delete_to_custom_reports()
RETURNS TRIGGER AS $$
BEGIN
    -- Remove hotels from custom reports that belong to this user
    DELETE FROM custom_email_report_hotels crh
    USING custom_email_reports cr
    WHERE crh.custom_report_id = cr.id
      AND cr.upn = OLD.upn
      AND crh.hotel_name = OLD.hotel_name;

    -- Deactivate custom reports that now have zero hotels
    UPDATE custom_email_reports cr
    SET active = FALSE, updated_at = NOW()
    WHERE cr.upn = OLD.upn
      AND cr.active = TRUE
      AND NOT EXISTS (
          SELECT 1 FROM custom_email_report_hotels crh
          WHERE crh.custom_report_id = cr.id
      );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_uha_delete_cascade_custom_reports
    AFTER DELETE ON user_hotel_access
    FOR EACH ROW
    EXECUTE FUNCTION cascade_uha_delete_to_custom_reports();

COMMENT ON FUNCTION cascade_uha_delete_to_custom_reports IS
    'When user_hotel_access is deleted, removes matching custom_email_report_hotels rows and deactivates custom reports left with zero hotels.';
