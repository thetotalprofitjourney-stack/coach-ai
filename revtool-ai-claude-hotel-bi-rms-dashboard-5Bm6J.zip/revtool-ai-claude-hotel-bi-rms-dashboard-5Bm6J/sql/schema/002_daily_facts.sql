-- ============================================================================
-- REVTOOL AI - Daily Fact Tables (Layer 1)
-- Description: Daily granularity tables - one row per hotel + stay_date
-- Refreshed daily from PowerBI via Power Automate (UPSERT, no snapshots)
--
-- DATA COVERAGE: today → today + 270 days (≈9 months), same horizon as pricing.
-- Example: if today is 2026-02-23, data spans 2026-02-23 → 2026-11-21.
-- Past dates and dates beyond 270 days are NOT stored (volume optimization).
-- Each row embeds pre-calculated SDLY and LY fields from PowerBI,
-- so historical comparisons are available without separate LY rows.
-- For full historical queries, use monthly_facts (Jan prev_year → Dec next_year).
--
-- All dimension references use TEXT names (not integer IDs).
-- PowerBI sends names directly — no ID resolution needed in ETL.
--
-- DIMENSIONAL BREAKDOWNS (segment, channel, roomtype, mealplan):
-- TOP 5 PER DIMENSION PER DAY (Pareto principle): Only the 5 dimension values
-- with the highest rn_otb are stored per hotel + stay_date. This reduces data
-- volume dramatically (e.g., 20 channels → 5 per day) while retaining the
-- dimension values that have real business impact (~80% of revenue/RN).
-- Rows are only generated for days with sales (rn_otb > 0 for at least one value).
-- For FULL dimensional detail (all values, not just top 5), use monthly tables.
--
-- Carry the SAME metric set as the summary table (OTB, OTB Proj, SDLY Gross,
-- SDLY Net, LY, Forecast, Budget, Pickup, Cancellations).
-- ALL dimensional tables include occupancy fields (occ_*).
-- ALL dimensional tables include share fields (share_rn_otb, share_revenue_otb,
-- share_rn_sdly, share_revenue_sdly) — percentage contribution of each dimension
-- to the hotel total. SDLY shares enable YoY mix shift analysis.
-- rooms_available is ONLY in summary (hotel-level) and roomtype (physical inventory
-- per room type). For segment/channel/mealplan, occupancy = rn / hotel rooms_available.
-- For roomtype, occupancy = rn / rooms_available of that specific room type.
--
-- NOTE: No is_closed field. The AI derives open/closed status from today's date:
--   stay_date < today → closed (actual result)
--   stay_date >= today → open (still evolving)
-- ============================================================================

-- ----------------------------------------------------------------------------
-- daily_hotel_summary: Global hotel metrics per stay date
-- This is the most-queried table. One row per hotel per stay date.
--
-- ADR = Gross package pre-stay (accommodation + board).
--   Booking.com ADR includes their ~17% commission.
--   Tour operator ADR does NOT include their margin.
--   This is deliberate: higher gross ADR = more cash-in, regardless of commission.
--
-- OTB = PMS raw data. Always matches what the user sees in their system.
-- OTB Proj = Revtool model. Used by AI for internal reasoning, NEVER shown
--            to the user as "their data".
-- Pickup = Confirmed bookings only (no cancellations).
-- Cancellations = Analyzed separately, never mixed with pickup.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS daily_hotel_summary (
    hotel_name              VARCHAR(200) NOT NULL REFERENCES dim_hotels(hotel_name),
    stay_date               DATE NOT NULL,

    -- ── OTB (On The Books) — PMS raw, what the user recognizes ──
    rn_otb                  INT NOT NULL DEFAULT 0,
    revenue_otb             DECIMAL(14,2) NOT NULL DEFAULT 0,
    adr_otb                 DECIMAL(10,2) NOT NULL DEFAULT 0,

    -- ── OTB Projected — Revtool model (expected actual stays after cancellations) ──
    -- INTERNAL USE ONLY: AI uses this for reasoning, never presents as "user's data"
    rn_otb_proj             INT NOT NULL DEFAULT 0,
    revenue_otb_proj        DECIMAL(14,2) NOT NULL DEFAULT 0,
    adr_otb_proj            DECIMAL(10,2) NOT NULL DEFAULT 0,

    -- ── SDLY Gross (Same Day Last Year, raw snapshot, includes future cancellations) ──
    rn_sdly_gross           INT,
    revenue_sdly_gross      DECIMAL(14,2),
    adr_sdly_gross          DECIMAL(10,2),

    -- ── SDLY Net (Same Day Last Year, adjusted for known cancellations) ──
    rn_sdly_net             INT,
    revenue_sdly_net        DECIMAL(14,2),
    adr_sdly_net            DECIMAL(10,2),

    -- ── LY (Last Year, crystallized final result — inherently net) ──
    rn_ly                   INT,
    revenue_ly              DECIMAL(14,2),
    adr_ly                  DECIMAL(10,2),

    -- ── Forecast ──
    rn_forecast             INT,
    revenue_forecast        DECIMAL(14,2),
    adr_forecast            DECIMAL(10,2),

    -- ── Budget (monthly budget prorated to daily) ──
    rn_budget               INT,
    revenue_budget          DECIMAL(14,2),
    adr_budget              DECIMAL(10,2),

    -- ── Capacity ──
    rooms_available         INT NOT NULL,

    -- ── Occupancy ──
    occ_otb                 DECIMAL(5,2) NOT NULL DEFAULT 0,
    occ_otb_proj            DECIMAL(5,2) NOT NULL DEFAULT 0,
    occ_sdly_gross          DECIMAL(5,2),
    occ_sdly_net            DECIMAL(5,2),
    occ_ly                  DECIMAL(5,2),
    occ_forecast            DECIMAL(5,2),
    occ_budget              DECIMAL(5,2),

    -- ── Pickup 7 days (CONFIRMED ONLY — no cancellations) ──
    pickup_rn_7d            INT NOT NULL DEFAULT 0,
    pickup_rev_7d           DECIMAL(14,2) NOT NULL DEFAULT 0,
    pickup_rn_7d_sdly       INT,
    pickup_rev_7d_sdly      DECIMAL(14,2),

    -- ── Pickup 1 day (CONFIRMED ONLY — yesterday's new business) ──
    pickup_rn_1d            INT NOT NULL DEFAULT 0,
    pickup_rev_1d           DECIMAL(14,2) NOT NULL DEFAULT 0,
    pickup_rn_1d_sdly       INT,
    pickup_rev_1d_sdly      DECIMAL(14,2),

    -- ── Cancellations: recent window ──
    cancel_rn_7d            INT NOT NULL DEFAULT 0,
    cancel_rev_7d           DECIMAL(14,2),
    cancel_rn_1d            INT NOT NULL DEFAULT 0,
    cancel_rev_1d           DECIMAL(14,2),

    -- ── Cancellations: cumulative rates ──
    cancel_rate_otb         DECIMAL(5,2) NOT NULL DEFAULT 0,
    cancel_rate_sdly        DECIMAL(5,2),
    cancel_rate_ly          DECIMAL(5,2),

    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),

    PRIMARY KEY(hotel_name, stay_date)
);

CREATE INDEX idx_daily_summary_stay_month ON daily_hotel_summary(hotel_name, DATE_TRUNC('month', stay_date::timestamp));

-- ----------------------------------------------------------------------------
-- daily_hotel_segment: Metrics broken down by market segment
-- TOP 5 segments per hotel+day ranked by rn_otb descending.
-- Only days with sales (rn_otb > 0 for at least one segment).
-- For ALL segments, use monthly_hotel_segment.
-- Occupancy calculated against HOTEL total rooms_available (not segment-specific).
-- No rooms_available column — the AI uses the summary table for the denominator.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS daily_hotel_segment (
    hotel_name              VARCHAR(200) NOT NULL REFERENCES dim_hotels(hotel_name),
    stay_date               DATE NOT NULL,
    segment_name            VARCHAR(100) NOT NULL,


    -- ── OTB ──
    rn_otb                  INT NOT NULL DEFAULT 0,
    revenue_otb             DECIMAL(14,2) NOT NULL DEFAULT 0,
    adr_otb                 DECIMAL(10,2) NOT NULL DEFAULT 0,

    -- ── OTB Projected ──
    rn_otb_proj             INT NOT NULL DEFAULT 0,
    revenue_otb_proj        DECIMAL(14,2) NOT NULL DEFAULT 0,
    adr_otb_proj            DECIMAL(10,2) NOT NULL DEFAULT 0,

    -- ── SDLY Gross ──
    rn_sdly_gross           INT,
    revenue_sdly_gross      DECIMAL(14,2),
    adr_sdly_gross          DECIMAL(10,2),

    -- ── SDLY Net ──
    rn_sdly_net             INT,
    revenue_sdly_net        DECIMAL(14,2),
    adr_sdly_net            DECIMAL(10,2),

    -- ── LY ──
    rn_ly                   INT,
    revenue_ly              DECIMAL(14,2),
    adr_ly                  DECIMAL(10,2),

    -- ── Forecast ──
    rn_forecast             INT,
    revenue_forecast        DECIMAL(14,2),
    adr_forecast            DECIMAL(10,2),

    -- ── Budget ──
    rn_budget               INT,
    revenue_budget          DECIMAL(14,2),
    adr_budget              DECIMAL(10,2),

    -- ── Occupancy (vs hotel total rooms_available) ──
    occ_otb                 DECIMAL(5,2),
    occ_otb_proj            DECIMAL(5,2),
    occ_sdly_gross          DECIMAL(5,2),
    occ_sdly_net            DECIMAL(5,2),
    occ_ly                  DECIMAL(5,2),
    occ_forecast            DECIMAL(5,2),
    occ_budget              DECIMAL(5,2),

    -- ── Pickup 7d ──
    pickup_rn_7d            INT NOT NULL DEFAULT 0,
    pickup_rev_7d           DECIMAL(14,2) NOT NULL DEFAULT 0,
    pickup_rn_7d_sdly       INT,
    pickup_rev_7d_sdly      DECIMAL(14,2),

    -- ── Pickup 1d ──
    pickup_rn_1d            INT NOT NULL DEFAULT 0,
    pickup_rev_1d           DECIMAL(14,2) NOT NULL DEFAULT 0,
    pickup_rn_1d_sdly       INT,
    pickup_rev_1d_sdly      DECIMAL(14,2),

    -- ── Cancellations: window ──
    cancel_rn_7d            INT NOT NULL DEFAULT 0,
    cancel_rev_7d           DECIMAL(14,2),
    cancel_rn_1d            INT NOT NULL DEFAULT 0,
    cancel_rev_1d           DECIMAL(14,2),

    -- ── Cancellations: cumulative rates ──
    cancel_rate_otb         DECIMAL(5,2) NOT NULL DEFAULT 0,
    cancel_rate_sdly        DECIMAL(5,2),
    cancel_rate_ly          DECIMAL(5,2),

    -- ── Shares (% of hotel total for this stay_date) ──
    share_rn_otb            DECIMAL(5,2),
    share_revenue_otb       DECIMAL(5,2),
    share_rn_sdly           DECIMAL(5,2),              -- SDLY gross share, for YoY mix shift analysis
    share_revenue_sdly      DECIMAL(5,2),

    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),

    PRIMARY KEY(hotel_name, stay_date, segment_name)
);

CREATE INDEX idx_daily_segment_hotel_date ON daily_hotel_segment(hotel_name, stay_date);

-- ----------------------------------------------------------------------------
-- daily_hotel_channel: Metrics broken down by distribution channel
-- TOP 5 channels per hotel+day ranked by rn_otb descending.
-- Only days with sales (rn_otb > 0 for at least one channel).
-- For ALL channels, use monthly_hotel_channel.
-- Occupancy calculated against HOTEL total rooms_available.
-- ADR includes channel commission where applicable (gross = cash-in).
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS daily_hotel_channel (
    hotel_name              VARCHAR(200) NOT NULL REFERENCES dim_hotels(hotel_name),
    stay_date               DATE NOT NULL,
    channel_name            VARCHAR(200) NOT NULL,


    -- ── OTB ──
    rn_otb                  INT NOT NULL DEFAULT 0,
    revenue_otb             DECIMAL(14,2) NOT NULL DEFAULT 0,
    adr_otb                 DECIMAL(10,2) NOT NULL DEFAULT 0,

    -- ── OTB Projected ──
    rn_otb_proj             INT NOT NULL DEFAULT 0,
    revenue_otb_proj        DECIMAL(14,2) NOT NULL DEFAULT 0,
    adr_otb_proj            DECIMAL(10,2) NOT NULL DEFAULT 0,

    -- ── SDLY Gross ──
    rn_sdly_gross           INT,
    revenue_sdly_gross      DECIMAL(14,2),
    adr_sdly_gross          DECIMAL(10,2),

    -- ── SDLY Net ──
    rn_sdly_net             INT,
    revenue_sdly_net        DECIMAL(14,2),
    adr_sdly_net            DECIMAL(10,2),

    -- ── LY ──
    rn_ly                   INT,
    revenue_ly              DECIMAL(14,2),
    adr_ly                  DECIMAL(10,2),

    -- ── Forecast ──
    rn_forecast             INT,
    revenue_forecast        DECIMAL(14,2),
    adr_forecast            DECIMAL(10,2),

    -- ── Budget ──
    rn_budget               INT,
    revenue_budget          DECIMAL(14,2),
    adr_budget              DECIMAL(10,2),

    -- ── Occupancy (vs hotel total rooms_available) ──
    occ_otb                 DECIMAL(5,2),
    occ_otb_proj            DECIMAL(5,2),
    occ_sdly_gross          DECIMAL(5,2),
    occ_sdly_net            DECIMAL(5,2),
    occ_ly                  DECIMAL(5,2),
    occ_forecast            DECIMAL(5,2),
    occ_budget              DECIMAL(5,2),

    -- ── Pickup 7d ──
    pickup_rn_7d            INT NOT NULL DEFAULT 0,
    pickup_rev_7d           DECIMAL(14,2) NOT NULL DEFAULT 0,
    pickup_rn_7d_sdly       INT,
    pickup_rev_7d_sdly      DECIMAL(14,2),

    -- ── Pickup 1d ──
    pickup_rn_1d            INT NOT NULL DEFAULT 0,
    pickup_rev_1d           DECIMAL(14,2) NOT NULL DEFAULT 0,
    pickup_rn_1d_sdly       INT,
    pickup_rev_1d_sdly      DECIMAL(14,2),

    -- ── Cancellations: window ──
    cancel_rn_7d            INT NOT NULL DEFAULT 0,
    cancel_rev_7d           DECIMAL(14,2),
    cancel_rn_1d            INT NOT NULL DEFAULT 0,
    cancel_rev_1d           DECIMAL(14,2),

    -- ── Cancellations: cumulative rates ──
    cancel_rate_otb         DECIMAL(5,2) NOT NULL DEFAULT 0,
    cancel_rate_sdly        DECIMAL(5,2),
    cancel_rate_ly          DECIMAL(5,2),

    -- ── Shares (% of hotel total for this stay_date) ──
    share_rn_otb            DECIMAL(5,2),
    share_revenue_otb       DECIMAL(5,2),
    share_rn_sdly           DECIMAL(5,2),              -- SDLY gross share, for YoY mix shift analysis
    share_revenue_sdly      DECIMAL(5,2),

    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),

    PRIMARY KEY(hotel_name, stay_date, channel_name)
);

CREATE INDEX idx_daily_channel_hotel_date ON daily_hotel_channel(hotel_name, stay_date);

-- ----------------------------------------------------------------------------
-- daily_hotel_roomtype: Metrics broken down by room type
-- TOP 5 room types per hotel+day ranked by rn_otb descending.
-- Only days with sales (rn_otb > 0 for at least one room type).
-- For ALL room types, use monthly_hotel_roomtype.
-- rooms_available = physical inventory for THIS room type (e.g., 50 Doble, 30 Suite)
-- Occupancy = rn / rooms_available of this specific room type (NOT hotel total)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS daily_hotel_roomtype (
    hotel_name              VARCHAR(200) NOT NULL REFERENCES dim_hotels(hotel_name),
    stay_date               DATE NOT NULL,
    room_type_name          VARCHAR(100) NOT NULL,


    -- ── OTB ──
    rn_otb                  INT NOT NULL DEFAULT 0,
    revenue_otb             DECIMAL(14,2) NOT NULL DEFAULT 0,
    adr_otb                 DECIMAL(10,2) NOT NULL DEFAULT 0,

    -- ── OTB Projected ──
    rn_otb_proj             INT NOT NULL DEFAULT 0,
    revenue_otb_proj        DECIMAL(14,2) NOT NULL DEFAULT 0,
    adr_otb_proj            DECIMAL(10,2) NOT NULL DEFAULT 0,

    -- ── SDLY Gross ──
    rn_sdly_gross           INT,
    revenue_sdly_gross      DECIMAL(14,2),
    adr_sdly_gross          DECIMAL(10,2),

    -- ── SDLY Net ──
    rn_sdly_net             INT,
    revenue_sdly_net        DECIMAL(14,2),
    adr_sdly_net            DECIMAL(10,2),

    -- ── LY ──
    rn_ly                   INT,
    revenue_ly              DECIMAL(14,2),
    adr_ly                  DECIMAL(10,2),

    -- ── Forecast ──
    rn_forecast             INT,
    revenue_forecast        DECIMAL(14,2),
    adr_forecast            DECIMAL(10,2),

    -- ── Budget ──
    rn_budget               INT,
    revenue_budget          DECIMAL(14,2),
    adr_budget              DECIMAL(10,2),

    -- ── Capacity & Occupancy (per room type's own inventory) ──
    rooms_available         INT,
    occ_otb                 DECIMAL(5,2),
    occ_otb_proj            DECIMAL(5,2),
    occ_sdly_gross          DECIMAL(5,2),
    occ_sdly_net            DECIMAL(5,2),
    occ_ly                  DECIMAL(5,2),
    occ_forecast            DECIMAL(5,2),
    occ_budget              DECIMAL(5,2),

    -- ── Pickup 7d ──
    pickup_rn_7d            INT NOT NULL DEFAULT 0,
    pickup_rev_7d           DECIMAL(14,2) NOT NULL DEFAULT 0,
    pickup_rn_7d_sdly       INT,
    pickup_rev_7d_sdly      DECIMAL(14,2),

    -- ── Pickup 1d ──
    pickup_rn_1d            INT NOT NULL DEFAULT 0,
    pickup_rev_1d           DECIMAL(14,2) NOT NULL DEFAULT 0,
    pickup_rn_1d_sdly       INT,
    pickup_rev_1d_sdly      DECIMAL(14,2),

    -- ── Cancellations: window ──
    cancel_rn_7d            INT NOT NULL DEFAULT 0,
    cancel_rev_7d           DECIMAL(14,2),
    cancel_rn_1d            INT NOT NULL DEFAULT 0,
    cancel_rev_1d           DECIMAL(14,2),

    -- ── Cancellations: cumulative rates ──
    cancel_rate_otb         DECIMAL(5,2) NOT NULL DEFAULT 0,
    cancel_rate_sdly        DECIMAL(5,2),
    cancel_rate_ly          DECIMAL(5,2),

    -- ── Shares (% of hotel total for this stay_date) ──
    share_rn_otb            DECIMAL(5,2),
    share_revenue_otb       DECIMAL(5,2),
    share_rn_sdly           DECIMAL(5,2),              -- SDLY gross share, for YoY mix shift analysis
    share_revenue_sdly      DECIMAL(5,2),

    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),

    PRIMARY KEY(hotel_name, stay_date, room_type_name)
);

CREATE INDEX idx_daily_roomtype_hotel_date ON daily_hotel_roomtype(hotel_name, stay_date);

-- ----------------------------------------------------------------------------
-- daily_hotel_mealplan: Metrics broken down by meal plan / board type
-- TOP 5 meal plans per hotel+day ranked by rn_otb descending.
-- Only days with sales (rn_otb > 0 for at least one meal plan).
-- For ALL meal plans, use monthly_hotel_mealplan.
-- Occupancy calculated against HOTEL total rooms_available.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS daily_hotel_mealplan (
    hotel_name              VARCHAR(200) NOT NULL REFERENCES dim_hotels(hotel_name),
    stay_date               DATE NOT NULL,
    meal_plan_name          VARCHAR(50) NOT NULL,


    -- ── OTB ──
    rn_otb                  INT NOT NULL DEFAULT 0,
    revenue_otb             DECIMAL(14,2) NOT NULL DEFAULT 0,
    adr_otb                 DECIMAL(10,2) NOT NULL DEFAULT 0,

    -- ── OTB Projected ──
    rn_otb_proj             INT NOT NULL DEFAULT 0,
    revenue_otb_proj        DECIMAL(14,2) NOT NULL DEFAULT 0,
    adr_otb_proj            DECIMAL(10,2) NOT NULL DEFAULT 0,

    -- ── SDLY Gross ──
    rn_sdly_gross           INT,
    revenue_sdly_gross      DECIMAL(14,2),
    adr_sdly_gross          DECIMAL(10,2),

    -- ── SDLY Net ──
    rn_sdly_net             INT,
    revenue_sdly_net        DECIMAL(14,2),
    adr_sdly_net            DECIMAL(10,2),

    -- ── LY ──
    rn_ly                   INT,
    revenue_ly              DECIMAL(14,2),
    adr_ly                  DECIMAL(10,2),

    -- ── Forecast ──
    rn_forecast             INT,
    revenue_forecast        DECIMAL(14,2),
    adr_forecast            DECIMAL(10,2),

    -- ── Budget ──
    rn_budget               INT,
    revenue_budget          DECIMAL(14,2),
    adr_budget              DECIMAL(10,2),

    -- ── Occupancy (vs hotel total rooms_available) ──
    occ_otb                 DECIMAL(5,2),
    occ_otb_proj            DECIMAL(5,2),
    occ_sdly_gross          DECIMAL(5,2),
    occ_sdly_net            DECIMAL(5,2),
    occ_ly                  DECIMAL(5,2),
    occ_forecast            DECIMAL(5,2),
    occ_budget              DECIMAL(5,2),

    -- ── Pickup 7d ──
    pickup_rn_7d            INT NOT NULL DEFAULT 0,
    pickup_rev_7d           DECIMAL(14,2) NOT NULL DEFAULT 0,
    pickup_rn_7d_sdly       INT,
    pickup_rev_7d_sdly      DECIMAL(14,2),

    -- ── Pickup 1d ──
    pickup_rn_1d            INT NOT NULL DEFAULT 0,
    pickup_rev_1d           DECIMAL(14,2) NOT NULL DEFAULT 0,
    pickup_rn_1d_sdly       INT,
    pickup_rev_1d_sdly      DECIMAL(14,2),

    -- ── Cancellations: window ──
    cancel_rn_7d            INT NOT NULL DEFAULT 0,
    cancel_rev_7d           DECIMAL(14,2),
    cancel_rn_1d            INT NOT NULL DEFAULT 0,
    cancel_rev_1d           DECIMAL(14,2),

    -- ── Cancellations: cumulative rates ──
    cancel_rate_otb         DECIMAL(5,2) NOT NULL DEFAULT 0,
    cancel_rate_sdly        DECIMAL(5,2),
    cancel_rate_ly          DECIMAL(5,2),

    -- ── Shares (% of hotel total for this stay_date) ──
    share_rn_otb            DECIMAL(5,2),
    share_revenue_otb       DECIMAL(5,2),
    share_rn_sdly           DECIMAL(5,2),              -- SDLY gross share, for YoY mix shift analysis
    share_revenue_sdly      DECIMAL(5,2),

    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),

    PRIMARY KEY(hotel_name, stay_date, meal_plan_name)
);

CREATE INDEX idx_daily_mealplan_hotel_date ON daily_hotel_mealplan(hotel_name, stay_date);
