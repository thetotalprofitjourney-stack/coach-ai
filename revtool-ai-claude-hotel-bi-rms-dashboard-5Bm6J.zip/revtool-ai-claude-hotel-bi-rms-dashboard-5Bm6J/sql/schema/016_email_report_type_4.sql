-- =============================================================================
-- 016_email_report_type_4.sql
-- Add report_type 4 (Campañas online) to the CHECK constraint.
-- =============================================================================

-- Recreate CHECK constraint to allow report_type 4
ALTER TABLE email_report_subscriptions DROP CONSTRAINT IF EXISTS email_report_subscriptions_report_type_check;
ALTER TABLE email_report_subscriptions ADD CONSTRAINT email_report_subscriptions_report_type_check
    CHECK (report_type IN (1, 2, 3, 4));
