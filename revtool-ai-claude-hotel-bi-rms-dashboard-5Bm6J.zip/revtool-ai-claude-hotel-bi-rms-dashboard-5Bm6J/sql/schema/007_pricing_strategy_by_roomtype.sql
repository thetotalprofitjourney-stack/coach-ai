-- ============================================================================
-- REVTOOL AI - Pricing Strategy by Room Type (Layer 3b)
-- Description: Daily signals from Revtool's model for the 3 levers of
-- operational revenue management, broken down by ROOM TYPE.
--
-- DATA HORIZON: today → today + 270 days (≈9 months).
-- Recommendations beyond 9 months are not useful — booking activity at that
-- distance is negligible. Limiting the horizon also optimizes storage.
--
-- This table is the room-type-level counterpart of daily_pricing_strategy.
-- While daily_pricing_strategy provides hotel-level recommendations
-- (suitable for hotels using base-room derivation pricing), this table
-- provides per-room-type recommendations for hotels that manage each
-- room type as an independent "sub-hotel" with its own pricing, minimum
-- stay restrictions, and partial closures.
--
-- Two pricing approaches exist in hotel revenue management:
--   1. DERIVATION: The hotel sets a base room price and derives all other
--      room types from it (e.g., base double + X% for superior, + Y% for
--      suite). For these hotels, daily_pricing_strategy (hotel-level) is
--      sufficient.
--   2. BY ROOM TYPE: The hotel manages each room type independently,
--      recognizing that each has its own demand rhythm, booking pace, and
--      competitive dynamics. For these hotels, this table provides
--      room-type-specific signals.
--
-- This is INPUT to the AI from the PowerBI/Revtool model.
-- The AI uses these signals to inform its advice, but the final tactical
-- decision is ALWAYS the hotel user's.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- daily_pricing_strategy_by_roomtype: One row per hotel + future stay date
-- + room type.
-- Contains the same 3 operational levers as daily_pricing_strategy, but
-- at the room type granularity:
--   1. Intermediary control (close/open OTA channels for this room type)
--   2. Price adjustment (delta to add/subtract for this room type)
--   3. Minimum stay analysis (rooms remaining for this room type + diffs)
--
-- stay_date range: CURRENT_DATE to CURRENT_DATE + 270
-- ETL must only load rows within this window.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS daily_pricing_strategy_by_roomtype (
    hotel_name              VARCHAR(200) NOT NULL REFERENCES dim_hotels(hotel_name),
    stay_date               DATE NOT NULL,
    room_type_name          VARCHAR(100) NOT NULL,

    -- LEVER 1: Intermediary control (per room type)
    close_intermediaries    BOOLEAN NOT NULL DEFAULT FALSE,

    -- LEVER 2: Price adjustment (per room type, whole euros, no decimals)
    price_delta             INT NOT NULL DEFAULT 0,

    -- LEVER 3: Minimum stay analysis (per room type)
    rooms_remaining         INT NOT NULL DEFAULT 0,
    rooms_remaining_diff_prev INT NOT NULL DEFAULT 0,
    rooms_remaining_diff_next INT NOT NULL DEFAULT 0,

    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),

    PRIMARY KEY(hotel_name, stay_date, room_type_name)
);

-- NOTE: 270-day horizon is enforced at ETL level (Power Automate),
-- not via CHECK constraint, because CURRENT_DATE in CHECK is volatile
-- and breaks UPSERT operations on stale rows.
-- Views already filter stay_date >= CURRENT_DATE.
-- Periodic cleanup: DELETE FROM daily_pricing_strategy_by_roomtype WHERE stay_date < CURRENT_DATE;

CREATE INDEX idx_pricing_strategy_rt_hotel_date ON daily_pricing_strategy_by_roomtype(hotel_name, stay_date);
CREATE INDEX idx_pricing_strategy_rt_close ON daily_pricing_strategy_by_roomtype(hotel_name) WHERE close_intermediaries = TRUE;
CREATE INDEX idx_pricing_strategy_rt_roomtype ON daily_pricing_strategy_by_roomtype(hotel_name, room_type_name, stay_date);
