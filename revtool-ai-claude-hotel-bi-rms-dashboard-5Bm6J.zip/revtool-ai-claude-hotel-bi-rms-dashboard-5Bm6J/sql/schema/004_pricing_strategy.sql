-- ============================================================================
-- REVTOOL AI - Pricing Strategy Table (Layer 3)
-- Description: Daily signals from Revtool's model for the 3 levers of
-- operational revenue management: price, distribution, and restrictions.
--
-- DATA HORIZON: today → today + 270 days (≈9 months).
-- Recommendations beyond 9 months are not useful — booking activity at that
-- distance is negligible. Limiting the horizon also optimizes storage.
--
-- This is INPUT to the AI from the PowerBI/Revtool model.
-- The AI uses these signals to inform its advice, but the final tactical
-- decision is ALWAYS the hotel user's.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- daily_pricing_strategy: One row per hotel + future stay date
-- Contains the 3 operational levers:
--   1. Intermediary control (close/open OTA channels)
--   2. Price adjustment (delta to add/subtract from channel manager)
--   3. Minimum stay analysis (rooms remaining + neighbor diffs)
--
-- stay_date range: CURRENT_DATE to CURRENT_DATE + 270
-- ETL must only load rows within this window.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS daily_pricing_strategy (
    hotel_name              VARCHAR(200) NOT NULL REFERENCES dim_hotels(hotel_name),
    stay_date               DATE NOT NULL,

    -- ── LEVER 1: Intermediary control ──
    close_intermediaries    BOOLEAN NOT NULL DEFAULT FALSE,

    -- ── LEVER 2: Price adjustment (whole euros, no decimals) ──
    price_delta             INT NOT NULL DEFAULT 0,

    -- ── LEVER 3: Minimum stay analysis ──
    rooms_remaining         INT NOT NULL DEFAULT 0,
    rooms_remaining_diff_prev INT NOT NULL DEFAULT 0,
    rooms_remaining_diff_next INT NOT NULL DEFAULT 0,

    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),

    PRIMARY KEY(hotel_name, stay_date)
);

-- NOTE: 270-day horizon is enforced at ETL level (Power Automate),
-- not via CHECK constraint, because CURRENT_DATE in CHECK is volatile
-- and breaks UPSERT operations on stale rows.
-- Views already filter stay_date >= CURRENT_DATE.
-- Periodic cleanup: DELETE FROM daily_pricing_strategy WHERE stay_date < CURRENT_DATE;

CREATE INDEX idx_pricing_strategy_hotel_date ON daily_pricing_strategy(hotel_name, stay_date);
CREATE INDEX idx_pricing_strategy_close ON daily_pricing_strategy(hotel_name) WHERE close_intermediaries = TRUE;
