-- ============================================================================
-- 012: Error log — tracks AI interactions that failed and were not billed
-- ============================================================================
-- When all SQL queries in a request fail, the user is not charged but
-- the platform still incurs the Anthropic API cost. This table records
-- those absorbed costs for monitoring and reconciliation.
-- ============================================================================

CREATE TABLE IF NOT EXISTS error_log (
    id              BIGSERIAL PRIMARY KEY,
    upn             VARCHAR(320) NOT NULL,
    model_used      VARCHAR(100) NOT NULL,
    tokens_input    INT NOT NULL DEFAULT 0,
    tokens_output   INT NOT NULL DEFAULT 0,
    cache_creation_tokens INT NOT NULL DEFAULT 0,
    cache_read_tokens     INT NOT NULL DEFAULT 0,
    cost_input_usd        DECIMAL(10,6) NOT NULL DEFAULT 0,
    cost_output_usd       DECIMAL(10,6) NOT NULL DEFAULT 0,
    cost_cache_creation_usd DECIMAL(10,6) NOT NULL DEFAULT 0,
    cost_cache_read_usd     DECIMAL(10,6) NOT NULL DEFAULT 0,
    cost_total_usd  DECIMAL(10,6) NOT NULL DEFAULT 0,
    cost_eur_absorbed DECIMAL(10,6) NOT NULL DEFAULT 0,   -- what the user WOULD have paid (with markup)
    usd_to_eur_rate NUMERIC(10,6),
    markup_percent  NUMERIC(5,2),
    sql_queries_attempted INT NOT NULL DEFAULT 0,
    sql_queries_failed    INT NOT NULL DEFAULT 0,
    error_details   TEXT,                                  -- first SQL error message(s)
    analysis_mode   VARCHAR(20),
    selected_hotels TEXT[],
    user_question   TEXT,                                  -- first 500 chars of the user's question
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_error_log_upn ON error_log(upn);
CREATE INDEX IF NOT EXISTS idx_error_log_created_at ON error_log(created_at);

COMMENT ON TABLE error_log IS
    'AI interactions where all SQL queries failed. The user was not charged '
    'but the platform absorbed the Anthropic API cost. Use this table to '
    'monitor error rates and absorbed costs.';

GRANT SELECT, INSERT ON error_log TO revtool;
GRANT USAGE ON SEQUENCE error_log_id_seq TO revtool;
