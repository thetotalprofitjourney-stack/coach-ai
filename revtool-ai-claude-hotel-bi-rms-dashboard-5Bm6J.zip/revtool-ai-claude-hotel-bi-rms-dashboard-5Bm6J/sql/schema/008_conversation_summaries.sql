-- ============================================================================
-- REVTOOL AI - Conversation Summaries
-- Description: Rolling cumulative summaries for session persistence.
--
-- Each AI interaction is summarized by Claude Haiku and stored per user
-- per UTC calendar day. Summaries are retained for 48 hours (rolling),
-- then purged automatically. This gives the AI conversational context
-- across reconnections without storing individual messages.
--
-- The summary captures: topics analyzed, key data points discussed,
-- recommendations given, files analyzed, and decisions pending.
-- Individual messages and file attachments are NOT stored.
--
-- All dates are UTC. No timezone management per user.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- conversation_summaries: One cumulative summary per user per UTC day
-- Updated via UPSERT after each AI interaction (by Haiku in background).
-- On reconnection, summaries from the last 2 UTC days are loaded and
-- injected as {conversation_summary} in the system prompt.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS conversation_summaries (
    upn             VARCHAR(200) NOT NULL REFERENCES users(upn),
    summary_date    DATE NOT NULL,              -- UTC calendar date
    summary_text    TEXT NOT NULL,               -- Cumulative summary for this day

    PRIMARY KEY (upn, summary_date)
);

CREATE INDEX idx_conversation_summaries_date ON conversation_summaries(summary_date);

-- ============================================================================
-- PURGE: Delete summaries older than 48 hours (2 calendar days)
-- Run on session load or via periodic job (cron, pg_cron, etc.)
-- ============================================================================
-- DELETE FROM conversation_summaries
-- WHERE summary_date < CURRENT_DATE - INTERVAL '2 days';
