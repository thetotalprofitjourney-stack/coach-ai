-- ============================================================================
-- REVTOOL AI - User Billing Profile & Sales Ledger
-- Description: Company billing data per user + transaction log for invoicing.
--
-- Each user must fill their billing profile before using the app.
-- The profile determines VAT treatment:
--   - Spain (not Canarias/Ceuta/Melilla) → 21% IVA
--   - Canarias, Ceuta, Melilla, or international → 0% IVA
--
-- The sales_ledger captures a snapshot of billing data at payment time,
-- so future profile edits don't affect past invoices.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- user_billing_profile: Company/billing info per user
-- Linked to UPN (Microsoft Entra ID). Must be completed before first topup.
-- The notification_email is independent of the UPN — used for invoices and
-- communications (UPN may not be a real mailbox).
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS user_billing_profile (
    upn                 VARCHAR(200) PRIMARY KEY REFERENCES users(upn),
    company_name        VARCHAR(300) NOT NULL,
    tax_id              VARCHAR(30)  NOT NULL,           -- NIF / CIF / VAT number
    notification_email  VARCHAR(300) NOT NULL,           -- Email for invoices & communications (NOT the UPN)
    address_line        VARCHAR(500) NOT NULL,
    city                VARCHAR(200) NOT NULL,
    province            VARCHAR(200) NOT NULL,
    postal_code         VARCHAR(20),
    country             VARCHAR(100) NOT NULL,

    -- Auto-calculated: TRUE = IVA 21% applies (Spain mainland + Balearic Islands)
    -- FALSE = 0% (Canarias, Ceuta, Melilla, or any other country)
    vat_applicable      BOOLEAN GENERATED ALWAYS AS (
        country = 'España'
        AND province NOT IN ('Las Palmas', 'Santa Cruz de Tenerife', 'Ceuta', 'Melilla')
    ) STORED,

    created_at          TIMESTAMPTZ DEFAULT NOW(),
    updated_at          TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- sales_ledger: Immutable record of every topup for invoicing
-- Snapshots billing data at payment time. Each row = one future invoice line.
-- Export this table periodically to your ERP for invoice generation.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sales_ledger (
    id                          BIGSERIAL PRIMARY KEY,
    upn                         VARCHAR(200) NOT NULL REFERENCES users(upn),
    transaction_date            TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    -- Billing data snapshot (copied from user_billing_profile at payment time)
    company_name                VARCHAR(300) NOT NULL,
    tax_id                      VARCHAR(30)  NOT NULL,
    notification_email          VARCHAR(300) NOT NULL,
    address_line                VARCHAR(500),
    city                        VARCHAR(200),
    province                    VARCHAR(200),
    postal_code                 VARCHAR(20),
    country                     VARCHAR(100) NOT NULL,

    -- Amounts
    total_paid_eur              DECIMAL(12,4) NOT NULL,   -- What Stripe charged
    vat_rate                    DECIMAL(5,2)  NOT NULL,    -- 21.00 or 0.00
    base_amount_eur             DECIMAL(12,4) NOT NULL,    -- Net taxable base
    vat_amount_eur              DECIMAL(12,4) NOT NULL,    -- VAT portion

    -- Credits loaded to user balance (= base_amount_eur)
    credits_loaded_eur          DECIMAL(12,4) NOT NULL,

    -- Stripe traceability
    stripe_payment_intent_id    VARCHAR(100),
    stripe_checkout_session_id  VARCHAR(100),

    notes                       VARCHAR(500),
    created_at                  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_sales_ledger_date ON sales_ledger(transaction_date);
CREATE INDEX idx_sales_ledger_upn ON sales_ledger(upn);
CREATE INDEX idx_sales_ledger_upn_date ON sales_ledger(upn, transaction_date);
