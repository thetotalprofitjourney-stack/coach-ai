-- ============================================================================
-- 011: Exchange rates table + cache token tracking in token_usage_log
-- ============================================================================

-- ----------------------------------------------------------------------------
-- exchange_rates: Daily USD/EUR exchange rates
-- Fed manually or via automation with the official daily rate.
-- Used by the cost calculation to convert provider costs (USD) to user costs (EUR).
-- Falls back to the static config value if no rate exists for today.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS exchange_rates (
    rate_date   DATE PRIMARY KEY,
    usd_to_eur  NUMERIC(10,6) NOT NULL,
    source      VARCHAR(100) DEFAULT 'manual',    -- e.g. 'manual', 'ecb', 'api'
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

COMMENT ON TABLE exchange_rates IS
    'Daily USD→EUR exchange rates. The cost engine looks up today''s rate here '
    'and falls back to the static config value if no row exists.';

-- Grant SELECT to the app user (adjust 'revtool' if your app role is different)
GRANT SELECT ON exchange_rates TO revtool;

-- ----------------------------------------------------------------------------
-- token_usage_log: Add columns for prompt caching token tracking
--
-- Anthropic API reports three types of input tokens:
--   input_tokens             → billed at base input rate
--   cache_creation_input_tokens → billed at 1.25× base rate (cache write)
--   cache_read_input_tokens    → billed at 0.1× base rate (cache hit)
--
-- Previously only input_tokens and output_tokens were tracked, which
-- under-reported the actual API cost significantly.
-- ----------------------------------------------------------------------------
ALTER TABLE token_usage_log
    ADD COLUMN IF NOT EXISTS cache_creation_tokens  INT DEFAULT 0,
    ADD COLUMN IF NOT EXISTS cache_read_tokens       INT DEFAULT 0,
    ADD COLUMN IF NOT EXISTS cost_cache_creation_usd DECIMAL(10,6) DEFAULT 0,
    ADD COLUMN IF NOT EXISTS cost_cache_read_usd     DECIMAL(10,6) DEFAULT 0,
    ADD COLUMN IF NOT EXISTS usd_to_eur_rate         NUMERIC(10,6);

COMMENT ON COLUMN token_usage_log.cache_creation_tokens IS
    'Tokens written to Anthropic prompt cache (billed at 1.25× base input rate)';
COMMENT ON COLUMN token_usage_log.cache_read_tokens IS
    'Tokens read from Anthropic prompt cache (billed at 0.1× base input rate)';
COMMENT ON COLUMN token_usage_log.usd_to_eur_rate IS
    'USD→EUR rate applied for this request (for audit trail)';
