-- ============================================================================
-- REVTOOL AI - Benchmark Sectorial (Competitive Set Data)
-- Description: Sector-level benchmark data (from INE / industry sources)
--              loaded via Power Automate from PowerBI.
--
-- Contains: occupancy, ADR, RevPAR (current + LY + YoY) by geographic area,
--           hotel category, month and year. Includes both crystallized past
--           data and projected future data.
--
-- Purpose: Allow the AI to compare each hotel's performance against its
--          competitive set (same category + geographic area). When benchmark
--          data is available, the AI uses it directly. When not available
--          (hotel in an area without data), the AI searches the web.
--
-- Hotel configuration: Each hotel selects its benchmark category and
--          geographic area during onboarding. The form shows available options
--          from benchmark_sectorial via cascading dropdowns, but also allows
--          manual entry for areas not covered.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- benchmark_categories: Fixed reference table for hotel categories
-- These are industry-standard STR/hotel classification categories.
-- Used both in benchmark_sectorial data and in hotel configuration.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS benchmark_categories (
    category_name   VARCHAR(30) PRIMARY KEY,             -- 'Economy', 'Luxury', etc.
    sort_order      SMALLINT NOT NULL DEFAULT 0           -- Display order in dropdowns
);

INSERT INTO benchmark_categories (category_name, sort_order) VALUES
    ('Economy',         1),
    ('Midscale',        2),
    ('Upper Midscale',  3),
    ('Upscale',         4),
    ('Upper Upscale',   5),
    ('Luxury',          6)
ON CONFLICT (category_name) DO NOTHING;

-- ----------------------------------------------------------------------------
-- benchmark_sectorial: Sector benchmark data by geography + category + month
--
-- PK: (country, ccaa, province, zone, category, year, month_num)
--
-- Contains 9 KPIs:
--   - occ, adr, revpar          (current period)
--   - occ_ly, adr_ly, revpar_ly (same period last year)
--   - yoy_occ, yoy_adr, yoy_revpar (year-over-year variation)
--
-- Data characteristics:
--   - Past months: crystallized actual values from INE/industry sources
--   - Future months: projected/forecast values
--   - Not all geographic combinations exist (limited coverage)
--   - Loaded via Power Automate from PowerBI (same ETL pattern as other tables)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS benchmark_sectorial (
    -- Geographic dimensions (hierarchical: country > ccaa > province > zone)
    country         VARCHAR(100) NOT NULL,               -- e.g., 'España', 'Portugal'
    ccaa            VARCHAR(100) NOT NULL,               -- Comunidad Autónoma, e.g., 'Andalucía'
    province        VARCHAR(100) NOT NULL,               -- e.g., 'Málaga', 'Barcelona'
    zone            VARCHAR(100) NOT NULL,               -- Tourism zone, e.g., 'Costa del Sol'

    -- Category dimension
    category        VARCHAR(30) NOT NULL REFERENCES benchmark_categories(category_name),

    -- Time dimensions
    year            SMALLINT NOT NULL,
    month_num       SMALLINT NOT NULL CHECK (month_num BETWEEN 1 AND 12),

    -- Current period KPIs
    occ             DECIMAL(5,2),                        -- Occupancy % (e.g., 72.50)
    adr             DECIMAL(10,2),                       -- Average Daily Rate in EUR
    revpar          DECIMAL(10,2),                       -- Revenue Per Available Room in EUR

    -- Last Year KPIs (same month, previous year)
    occ_ly          DECIMAL(5,2),                        -- Occupancy % last year
    adr_ly          DECIMAL(10,2),                       -- ADR last year
    revpar_ly       DECIMAL(10,2),                       -- RevPAR last year

    -- Year-over-Year variation
    yoy_occ         DECIMAL(6,2),                        -- YoY occupancy (percentage points, e.g., +3.50)
    yoy_adr         DECIMAL(6,2),                        -- YoY ADR (% change, e.g., +5.20)
    yoy_revpar      DECIMAL(6,2),                        -- YoY RevPAR (% change, e.g., +8.10)

    -- Metadata
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW(),

    PRIMARY KEY (country, ccaa, province, zone, category, year, month_num)
);

-- Indexes for common query patterns
CREATE INDEX idx_benchmark_geo ON benchmark_sectorial(country, ccaa, province, zone);
CREATE INDEX idx_benchmark_category ON benchmark_sectorial(category);
CREATE INDEX idx_benchmark_period ON benchmark_sectorial(year, month_num);
CREATE INDEX idx_benchmark_geo_cat_period ON benchmark_sectorial(country, ccaa, province, zone, category, year, month_num);

-- ----------------------------------------------------------------------------
-- Extend dim_hotels with benchmark configuration fields
-- These fields link each hotel to its competitive set in benchmark_sectorial.
--
-- Filled during hotel onboarding (chat-guided setup), using either:
--   a) Dropdown selection from available benchmark data (benchmark_available = TRUE)
--   b) Manual text entry for areas not covered (benchmark_available = FALSE)
--
-- When benchmark_available = TRUE, the AI queries benchmark_sectorial directly.
-- When benchmark_available = FALSE, the AI searches the web for competitive data.
-- ----------------------------------------------------------------------------
ALTER TABLE dim_hotels ADD COLUMN IF NOT EXISTS benchmark_category VARCHAR(30);
ALTER TABLE dim_hotels ADD COLUMN IF NOT EXISTS benchmark_country  VARCHAR(100);
ALTER TABLE dim_hotels ADD COLUMN IF NOT EXISTS benchmark_ccaa     VARCHAR(100);
ALTER TABLE dim_hotels ADD COLUMN IF NOT EXISTS benchmark_province VARCHAR(100);
ALTER TABLE dim_hotels ADD COLUMN IF NOT EXISTS benchmark_zone     VARCHAR(100);
ALTER TABLE dim_hotels ADD COLUMN IF NOT EXISTS benchmark_available BOOLEAN DEFAULT FALSE;
