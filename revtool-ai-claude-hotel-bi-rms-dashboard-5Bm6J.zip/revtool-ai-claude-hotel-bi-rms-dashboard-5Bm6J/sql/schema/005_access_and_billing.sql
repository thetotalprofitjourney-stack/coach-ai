-- ============================================================================
-- REVTOOL AI - Access Control & Credits Tables
-- Description: User authentication (Microsoft Entra ID), hotel access,
--              prepaid credit system (Stripe), and token tracking.
--
-- Users are identified by UPN (User Principal Name) from Microsoft login.
-- Hotels are identified by hotel_name (text, matching dim_hotels PK).
-- No integer IDs — all references use natural text keys.
--
-- Billing model: PREPAID CREDITS
--   User adds EUR via Stripe → credit_balance increases
--   Each AI interaction → cost calculated → deducted from credit_balance
--   Balance reaches 0 → chat blocked until topup
--
-- NOTE: Invoice generation and billing configuration are managed externally
-- via Stripe + accounting software. No billing_config or billing_monthly
-- tables are needed in this database.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- users: Registered users (authenticated via Microsoft Entra ID / Azure AD)
-- The UPN (User Principal Name) comes from Microsoft login.
-- This is a minimal table: we only need the UPN to authenticate and track.
-- No profile, no roles — users don't configure anything about themselves.
-- Language is automatic: the AI responds in whatever language the user writes in.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    upn             VARCHAR(200) PRIMARY KEY,         -- Microsoft UPN (user@domain.com)
    active          BOOLEAN DEFAULT TRUE,
    first_login_at  TIMESTAMPTZ,
    last_login_at   TIMESTAMPTZ,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- user_hotel_access: Which hotels each user can query
-- Minimal: just upn + hotel_name. If the row exists, the user has access.
-- Power Automate can load this table directly without resolving any IDs.
-- No access levels, no expiration — access is binary (row exists = access).
-- To revoke access, delete the row.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS user_hotel_access (
    upn             VARCHAR(200) NOT NULL,            -- No FK to users: access can be pre-loaded before user's first login
    hotel_name      VARCHAR(200) NOT NULL REFERENCES dim_hotels(hotel_name),

    PRIMARY KEY (upn, hotel_name)
);

CREATE INDEX idx_user_hotel_access_upn ON user_hotel_access(upn);
CREATE INDEX idx_user_hotel_access_hotel ON user_hotel_access(hotel_name);

-- ============================================================================
-- CREDIT SYSTEM (Stripe prepaid)
--
-- Purchase flow:
--   1. User must have a billing profile (user_billing_profile) — completed
--      during onboarding via the 🏢 button in the header.
--   2. User clicks "Recargar crédito" in chat UI, sees IVA breakdown.
--   3. Backend creates a Stripe Checkout Session with:
--      - metadata.upn = user's UPN (internal link, invisible to user)
--      - customer = stripe_customer_id (if returning) or new Customer
--   4. Stripe Checkout page asks only for payment method.
--   5. On success, Stripe webhook (checkout.session.completed) fires:
--      - Extracts metadata.upn → looks up user_billing_profile for VAT
--      - Calculates base amount and VAT → updates credit_balance (base only)
--      - Creates credit_transaction + sales_ledger records
--   6. Invoicing data lives in user_billing_profile + sales_ledger.
--
-- IMPORTANT: UPN ≠ notification email. The UPN is a Microsoft Entra ID
-- identifier that may not be a functional mailbox. The notification email
-- lives in user_billing_profile.notification_email.
-- Revtool stores stripe_customer_id to link UPN ↔ Stripe Customer.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- stripe_customers: Links UPN to Stripe Customer ID
-- Created on first purchase. The Stripe Customer object holds payment
-- methods. Billing data (company, tax ID, address) lives in
-- user_billing_profile. One UPN = one Stripe Customer. If
-- stripe_customer_id exists, reuse it when creating new Checkout Sessions.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS stripe_customers (
    upn                 VARCHAR(200) PRIMARY KEY REFERENCES users(upn),
    stripe_customer_id  VARCHAR(100) NOT NULL UNIQUE,   -- cus_XXXXXXXXX
    created_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_stripe_customers_cid ON stripe_customers(stripe_customer_id);

-- ----------------------------------------------------------------------------
-- credit_balance: Materialized current balance per user
-- One row per user. Updated atomically on every topup/consumption.
-- This is the FAST read path — every AI request checks this before proceeding.
-- If balance_eur <= 0, the chat is BLOCKED until topup.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS credit_balance (
    upn                 VARCHAR(200) PRIMARY KEY REFERENCES users(upn),
    balance_eur         DECIMAL(12,4) NOT NULL DEFAULT 0,
    total_topped_up     DECIMAL(12,4) NOT NULL DEFAULT 0,
    total_consumed      DECIMAL(12,4) NOT NULL DEFAULT 0,
    low_balance_alert   DECIMAL(12,4) DEFAULT 2.00,
    last_topup_at       TIMESTAMPTZ,
    last_consumption_at TIMESTAMPTZ,
    updated_at          TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- TOKEN TRACKING
-- ============================================================================

-- ----------------------------------------------------------------------------
-- token_usage_log: Per-request token tracking
-- One row per AI interaction (question + response)
-- Links to credit_transactions for the deduction
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS token_usage_log (
    id                  BIGSERIAL PRIMARY KEY,
    upn                 VARCHAR(200) NOT NULL REFERENCES users(upn),
    session_id          UUID,
    request_timestamp   TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    -- Token counts
    tokens_input        INT NOT NULL DEFAULT 0,
    tokens_output       INT NOT NULL DEFAULT 0,
    tokens_total        INT GENERATED ALWAYS AS (tokens_input + tokens_output) STORED,

    -- Model info
    model_used          VARCHAR(50) NOT NULL,

    -- Cost calculation (USD, raw provider cost)
    cost_input_usd      DECIMAL(10,6) DEFAULT 0,
    cost_output_usd     DECIMAL(10,6) DEFAULT 0,
    cost_total_usd      DECIMAL(10,6) GENERATED ALWAYS AS (cost_input_usd + cost_output_usd) STORED,

    -- Final EUR cost charged to user (after markup + exchange rate)
    cost_eur            DECIMAL(10,6) NOT NULL DEFAULT 0,

    -- Query metadata
    query_type          VARCHAR(30),                  -- 'text', 'audio', 'audio_response'
    hotels_queried      TEXT[],                        -- Array of hotel_names accessed
    analysis_mode       VARCHAR(10),                  -- 'hotel' (single) or 'group' (multi)
    query_summary       VARCHAR(500),

    created_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_token_usage_upn ON token_usage_log(upn);
CREATE INDEX idx_token_usage_timestamp ON token_usage_log(request_timestamp);

-- Wrapper IMMUTABLE for DATE_TRUNC on TIMESTAMPTZ columns.
-- The native date_trunc(text, timestamptz) is STABLE (timezone-dependent),
-- which PostgreSQL forbids in index expressions.
-- Safe as long as the server timezone stays constant (standard for production).
CREATE OR REPLACE FUNCTION date_trunc_month_immutable(ts TIMESTAMPTZ)
RETURNS TIMESTAMPTZ AS $$
    SELECT DATE_TRUNC('month', ts);
$$ LANGUAGE SQL IMMUTABLE PARALLEL SAFE;

CREATE INDEX idx_token_usage_upn_month ON token_usage_log(upn, date_trunc_month_immutable(request_timestamp));

-- ----------------------------------------------------------------------------
-- credit_transactions: Immutable log of every credit movement
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS credit_transactions (
    id                      BIGSERIAL PRIMARY KEY,
    upn                     VARCHAR(200) NOT NULL REFERENCES users(upn),
    transaction_type        VARCHAR(20) NOT NULL,

    amount_eur              DECIMAL(12,4) NOT NULL,
    balance_after           DECIMAL(12,4) NOT NULL,

    -- Stripe fields (for topups and refunds)
    stripe_payment_intent_id VARCHAR(100),
    stripe_checkout_session_id VARCHAR(100),
    stripe_refund_id        VARCHAR(100),

    -- AI consumption fields
    token_usage_log_id      BIGINT REFERENCES token_usage_log(id),

    -- Metadata
    description             VARCHAR(500),
    created_by              VARCHAR(200),
    created_at              TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_credit_tx_upn ON credit_transactions(upn);
CREATE INDEX idx_credit_tx_type ON credit_transactions(transaction_type);
CREATE INDEX idx_credit_tx_stripe ON credit_transactions(stripe_payment_intent_id)
    WHERE stripe_payment_intent_id IS NOT NULL;
CREATE INDEX idx_credit_tx_upn_date ON credit_transactions(upn, created_at);
