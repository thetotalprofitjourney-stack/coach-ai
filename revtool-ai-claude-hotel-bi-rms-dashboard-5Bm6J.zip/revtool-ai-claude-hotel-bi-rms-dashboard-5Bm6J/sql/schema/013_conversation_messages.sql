-- =============================================================================
-- 013_conversation_messages.sql
-- Persists individual chat messages (user + assistant) for 24h.
-- Allows users to close the browser and come back to see their full conversation.
-- Purge: messages older than 24 hours are deleted on session load.
-- =============================================================================

CREATE TABLE IF NOT EXISTS conversation_messages (
    id              BIGSERIAL       PRIMARY KEY,
    upn             VARCHAR(200)    NOT NULL REFERENCES users(upn),
    role            VARCHAR(10)     NOT NULL CHECK (role IN ('user', 'assistant')),
    content         TEXT            NOT NULL,
    cost_eur        NUMERIC(10,4),
    balance_after   NUMERIC(10,4),
    analysis_mode   VARCHAR(10),
    selected_hotels TEXT[],
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

-- Index for loading recent messages (last 24h for a user, ordered by time)
CREATE INDEX IF NOT EXISTS idx_conversation_messages_upn_created
    ON conversation_messages (upn, created_at DESC);

-- Index for purge query (delete old messages efficiently)
CREATE INDEX IF NOT EXISTS idx_conversation_messages_created
    ON conversation_messages (created_at);

COMMENT ON TABLE conversation_messages IS
    'Individual chat messages persisted for 24h so users can resume conversations across sessions.';

GRANT SELECT, INSERT, DELETE ON conversation_messages TO revtool_ai;
GRANT USAGE, SELECT ON SEQUENCE conversation_messages_id_seq TO revtool_ai;
