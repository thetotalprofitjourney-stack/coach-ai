-- 020: Add preferred_language to users table
-- Allows users to choose their UI and AI response language (es, en).
-- Default is 'es' (Spanish) matching current behavior.

ALTER TABLE users
ADD COLUMN IF NOT EXISTS preferred_language VARCHAR(5) DEFAULT 'es';
