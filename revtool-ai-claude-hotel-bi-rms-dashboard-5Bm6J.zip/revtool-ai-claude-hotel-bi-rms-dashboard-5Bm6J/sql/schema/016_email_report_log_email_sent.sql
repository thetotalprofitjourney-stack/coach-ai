-- Track whether the email was actually delivered for each report log entry.
-- Existing rows get FALSE so they can be resent via the resend-pending-emails endpoint.

ALTER TABLE email_report_log
    ADD COLUMN IF NOT EXISTS email_sent BOOLEAN NOT NULL DEFAULT FALSE;
