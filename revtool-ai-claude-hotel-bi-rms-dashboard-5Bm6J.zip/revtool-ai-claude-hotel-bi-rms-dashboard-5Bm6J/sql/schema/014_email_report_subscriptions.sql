-- =============================================================================
-- 014_email_report_subscriptions.sql
-- User subscriptions to automated daily email reports.
--
-- Each user can enable/disable 3 report types:
--   1 = Diagnostico diario (daily OTB diagnosis, next 30 days)
--   2 = Senales de pricing (pricing signals, next 14 days)
--   3 = Vision mensual (monthly overview, current + next month)
--
-- The scheduler builds a deduplicated queue:
--   DISTINCT (hotel_name, report_type) across all enabled subscriptions
--   × user_hotel_access. Executes once per (hotel, report_type),
--   sends the result to ALL users with access, charges subscribers.
-- =============================================================================

CREATE TABLE IF NOT EXISTS email_report_subscriptions (
    upn             VARCHAR(200)    NOT NULL REFERENCES users(upn),
    report_type     SMALLINT        NOT NULL CHECK (report_type IN (1, 2, 3)),
    enabled         BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    PRIMARY KEY (upn, report_type)
);

COMMENT ON TABLE email_report_subscriptions IS
    'User preferences for automated daily email reports. 3 report types available.';

-- Log of executed reports (for auditing, cost tracking, and preventing duplicates)
CREATE TABLE IF NOT EXISTS email_report_log (
    id              BIGSERIAL       PRIMARY KEY,
    hotel_name      VARCHAR(200)    NOT NULL,
    report_type     SMALLINT        NOT NULL,
    response_text   TEXT            NOT NULL,
    tokens_input    INT             NOT NULL DEFAULT 0,
    tokens_output   INT             NOT NULL DEFAULT 0,
    cost_eur        NUMERIC(10,4)   NOT NULL DEFAULT 0,
    charged_upns    TEXT[]          NOT NULL DEFAULT '{}',
    recipient_upns  TEXT[]          NOT NULL DEFAULT '{}',
    executed_at     TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_email_report_log_executed
    ON email_report_log (executed_at DESC);

COMMENT ON TABLE email_report_log IS
    'Audit log of automated email report executions. One row per (hotel, report_type) per run.';

GRANT SELECT, INSERT, UPDATE ON email_report_subscriptions TO revtool_ai;
GRANT SELECT, INSERT ON email_report_log TO revtool_ai;
GRANT USAGE, SELECT ON SEQUENCE email_report_log_id_seq TO revtool_ai;
