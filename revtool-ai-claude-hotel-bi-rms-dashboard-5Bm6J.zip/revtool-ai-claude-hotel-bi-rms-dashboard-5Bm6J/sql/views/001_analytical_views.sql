-- ============================================================================
-- REVTOOL AI - Analytical Views
-- Description: Pre-built views the AI uses to answer common questions
-- These simplify the AI's SQL generation and reduce token consumption
--
-- NOTE: No snapshot_date filtering needed — each table has one row per
-- hotel+stay_date, refreshed daily via UPSERT from Power Automate.
--
-- All joins use TEXT natural keys (hotel_name, upn). No integer IDs.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- v_daily_summary: Daily summary enriched with hotel info
-- The AI should query this 90% of the time instead of the base table
-- ----------------------------------------------------------------------------
CREATE OR REPLACE VIEW v_daily_summary AS
SELECT dhs.*,
       h.destination,
       h.province,
       h.city,
       h.country,
       h.total_rooms,
       h.hotel_type,
       h.currency
FROM daily_hotel_summary dhs
JOIN dim_hotels h ON h.hotel_name = dhs.hotel_name;

-- ----------------------------------------------------------------------------
-- v_monthly_summary: Monthly summary enriched with hotel info
-- ----------------------------------------------------------------------------
CREATE OR REPLACE VIEW v_monthly_summary AS
SELECT mhs.*,
       -- Derived: is this month closed? (before current month = closed)
       CASE WHEN (mhs.year < EXTRACT(YEAR FROM CURRENT_DATE)::SMALLINT)
                 OR (mhs.year = EXTRACT(YEAR FROM CURRENT_DATE)::SMALLINT
                     AND mhs.month_num < EXTRACT(MONTH FROM CURRENT_DATE)::SMALLINT)
            THEN TRUE ELSE FALSE
       END AS is_closed,
       h.destination,
       h.province,
       h.city,
       h.country,
       h.total_rooms,
       h.hotel_type,
       h.currency
FROM monthly_hotel_summary mhs
JOIN dim_hotels h ON h.hotel_name = mhs.hotel_name;

-- ----------------------------------------------------------------------------
-- v_ytd_summary: Year-to-date summary per hotel
-- Combines closed months + current month partial + future forecast
-- This is the view for "How's the full year going?"
-- ----------------------------------------------------------------------------
CREATE OR REPLACE VIEW v_ytd_summary AS
WITH ytd_data AS (
    SELECT
        mhs.hotel_name,
        mhs.year,

        -- Actuals: for past years all months, for current year up to current month
        SUM(CASE WHEN mhs.year < EXTRACT(YEAR FROM CURRENT_DATE)::SMALLINT
                      OR (mhs.year = EXTRACT(YEAR FROM CURRENT_DATE)::SMALLINT
                          AND mhs.month_num <= EXTRACT(MONTH FROM CURRENT_DATE)::SMALLINT)
            THEN mhs.rn_otb ELSE 0 END) AS rn_actual_ytd,
        SUM(CASE WHEN mhs.year < EXTRACT(YEAR FROM CURRENT_DATE)::SMALLINT
                      OR (mhs.year = EXTRACT(YEAR FROM CURRENT_DATE)::SMALLINT
                          AND mhs.month_num <= EXTRACT(MONTH FROM CURRENT_DATE)::SMALLINT)
            THEN mhs.revenue_otb ELSE 0 END) AS revenue_actual_ytd,

        -- Full year forecast (actuals for closed + forecast for open)
        SUM(COALESCE(
            CASE WHEN (mhs.year < EXTRACT(YEAR FROM CURRENT_DATE)::SMALLINT)
                      OR (mhs.year = EXTRACT(YEAR FROM CURRENT_DATE)::SMALLINT
                          AND mhs.month_num < EXTRACT(MONTH FROM CURRENT_DATE)::SMALLINT)
                 THEN mhs.rn_otb ELSE mhs.rn_forecast END,
            mhs.rn_otb
        )) AS rn_forecast_year,
        SUM(COALESCE(
            CASE WHEN (mhs.year < EXTRACT(YEAR FROM CURRENT_DATE)::SMALLINT)
                      OR (mhs.year = EXTRACT(YEAR FROM CURRENT_DATE)::SMALLINT
                          AND mhs.month_num < EXTRACT(MONTH FROM CURRENT_DATE)::SMALLINT)
                 THEN mhs.revenue_otb ELSE mhs.revenue_forecast END,
            mhs.revenue_otb
        )) AS revenue_forecast_year,

        -- LY full year
        SUM(mhs.rn_ly) AS rn_ly_year,
        SUM(mhs.revenue_ly) AS revenue_ly_year,

        -- Budget full year
        SUM(mhs.rn_budget) AS rn_budget_year,
        SUM(mhs.revenue_budget) AS revenue_budget_year,

        -- Total capacity
        SUM(mhs.rooms_available) AS rooms_available_year
    FROM monthly_hotel_summary mhs
    GROUP BY mhs.hotel_name, mhs.year
)
SELECT
    ytd.*,
    h.destination,
    h.province,
    h.city,
    h.country,
    h.total_rooms,
    h.hotel_type,
    h.currency,
    CASE WHEN rn_actual_ytd > 0 THEN ROUND(revenue_actual_ytd / rn_actual_ytd, 2) END AS adr_actual_ytd,
    CASE WHEN rn_forecast_year > 0 THEN ROUND(revenue_forecast_year / rn_forecast_year, 2) END AS adr_forecast_year,
    CASE WHEN rn_ly_year > 0 THEN ROUND(revenue_ly_year / rn_ly_year, 2) END AS adr_ly_year,
    CASE WHEN rooms_available_year > 0 THEN
        ROUND(rn_actual_ytd * 100.0 / rooms_available_year, 2) END AS occ_actual_ytd,
    CASE WHEN rn_ly_year > 0 THEN
        ROUND((rn_forecast_year - rn_ly_year) * 100.0 / rn_ly_year, 2) END AS var_rn_fc_vs_ly,
    CASE WHEN rn_budget_year > 0 THEN
        ROUND((rn_forecast_year - rn_budget_year) * 100.0 / rn_budget_year, 2) END AS var_rn_fc_vs_budget
FROM ytd_data ytd
JOIN dim_hotels h ON h.hotel_name = ytd.hotel_name;

-- ----------------------------------------------------------------------------
-- v_pricing_strategy: Active pricing signals for future dates
-- Enriched with hotel info. This is what the AI shows for pricing advice.
-- Horizon: today → today + 270 days (≈9 months). Beyond that, booking
-- activity is negligible and recommendations are not actionable.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE VIEW v_pricing_strategy AS
SELECT
    ps.*,
    h.destination,
    h.city
FROM daily_pricing_strategy ps
JOIN dim_hotels h ON h.hotel_name = ps.hotel_name
WHERE ps.stay_date >= CURRENT_DATE
  AND ps.stay_date <= CURRENT_DATE + INTERVAL '270 days'
ORDER BY ps.hotel_name, ps.stay_date;

-- ----------------------------------------------------------------------------
-- v_pricing_strategy_by_roomtype: Active pricing signals by room type
-- for future dates. Enriched with hotel info.
-- For hotels that manage each room type independently (not derivation-based).
-- Horizon: today → today + 270 days (≈9 months).
-- ----------------------------------------------------------------------------
CREATE OR REPLACE VIEW v_pricing_strategy_by_roomtype AS
SELECT
    ps.*,
    h.destination,
    h.city
FROM daily_pricing_strategy_by_roomtype ps
JOIN dim_hotels h ON h.hotel_name = ps.hotel_name
WHERE ps.stay_date >= CURRENT_DATE
  AND ps.stay_date <= CURRENT_DATE + INTERVAL '270 days'
ORDER BY ps.hotel_name, ps.stay_date, ps.room_type_name;

-- ============================================================================
-- CREDIT & CONSUMPTION VIEWS
-- ============================================================================

-- ----------------------------------------------------------------------------
-- v_user_credit: Real-time credit status for each user
-- This is what the chat UI shows: balance, monthly spend, and alert status.
-- Powers the "Saldo: X.XX€" display and the low-balance warning.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE VIEW v_user_credit AS
SELECT
    u.upn,
    COALESCE(cb.balance_eur, 0) AS balance_eur,
    COALESCE(cb.total_topped_up, 0) AS total_topped_up,
    COALESCE(cb.total_consumed, 0) AS total_consumed,
    COALESCE(cb.low_balance_alert, 2.00) AS low_balance_alert,
    COALESCE(cb.balance_eur, 0) <= COALESCE(cb.low_balance_alert, 2.00) AS is_low_balance,
    COALESCE(cb.balance_eur, 0) <= 0 AS is_blocked,
    cb.last_topup_at,
    cb.last_consumption_at,
    -- Monthly consumption (current month)
    COALESCE(month_usage.requests_this_month, 0) AS requests_this_month,
    COALESCE(month_usage.cost_eur_this_month, 0) AS cost_eur_this_month,
    COALESCE(month_usage.tokens_this_month, 0) AS tokens_this_month
FROM users u
LEFT JOIN credit_balance cb ON cb.upn = u.upn
LEFT JOIN (
    SELECT
        upn,
        COUNT(*) AS requests_this_month,
        SUM(cost_eur) AS cost_eur_this_month,
        SUM(tokens_total) AS tokens_this_month
    FROM token_usage_log
    WHERE DATE_TRUNC('month', request_timestamp) = DATE_TRUNC('month', NOW())
    GROUP BY upn
) month_usage ON month_usage.upn = u.upn;

-- ----------------------------------------------------------------------------
-- v_user_hotels: Quick view of user's accessible hotels with names
-- Used by the frontend to populate the hotel selector
-- ----------------------------------------------------------------------------
CREATE OR REPLACE VIEW v_user_hotels AS
SELECT
    uha.upn,
    h.hotel_name,
    h.destination,
    h.province,
    h.city,
    h.country,
    h.total_rooms,
    h.hotel_type,
    h.target_client,
    h.currency,
    h.setup_complete
FROM user_hotel_access uha
JOIN dim_hotels h ON h.hotel_name = uha.hotel_name
WHERE h.active = TRUE
ORDER BY uha.upn, h.hotel_name;

-- ----------------------------------------------------------------------------
-- v_hotel_setup_status: Shows which hotels need onboarding configuration
-- Used by the AI at session start to detect incomplete hotel profiles
-- and redirect users to the web form (⚙️ button) for configuration.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE VIEW v_hotel_setup_status AS
SELECT
    h.hotel_name,
    h.setup_complete,
    h.setup_by,
    h.setup_at,
    -- Individual field status (TRUE = missing, needs to be filled)
    h.hotel_type IS NULL            AS missing_hotel_type,
    h.target_client IS NULL         AS missing_target_client,
    h.destination IS NULL           AS missing_destination,
    h.province IS NULL              AS missing_province,
    h.city IS NULL                  AS missing_city,
    h.country IS NULL               AS missing_country,
    h.total_rooms IS NULL           AS missing_total_rooms,
    h.currency IS NULL              AS missing_currency,
    -- Benchmark configuration status
    h.benchmark_category IS NULL    AS missing_benchmark_category,
    h.benchmark_country IS NULL     AS missing_benchmark_geo,
    h.benchmark_available               AS has_benchmark_data
FROM dim_hotels h
WHERE h.active = TRUE;

-- ============================================================================
-- BENCHMARK SECTORIAL VIEWS
-- ============================================================================

-- ----------------------------------------------------------------------------
-- v_benchmark_geo: Distinct geographic combinations from benchmark data
-- Used by the frontend/AI to populate the geographic dropdown during hotel
-- onboarding. Currently all benchmark data is for Spain (ES).
--
-- Simplified logic:
--   - Spain: ALL geographic combinations exist in benchmark_sectorial.
--     Show a single concatenated dropdown "CCAA - Provincia - Zona".
--     User MUST select from existing options. benchmark_available = TRUE.
--   - Non-Spain: No benchmark data exists. User enters country, province,
--     and zone manually. benchmark_available = FALSE always.
--
-- The display_label column provides the concatenated text for the dropdown.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE VIEW v_benchmark_geo AS
SELECT DISTINCT
    country,
    ccaa,
    province,
    zone,
    ccaa || ' - ' || province || ' - ' || zone AS display_label
FROM benchmark_sectorial
ORDER BY country, ccaa, province, zone;

-- ----------------------------------------------------------------------------
-- v_hotel_benchmark: Hotel performance vs sector benchmark
-- Joins each hotel's benchmark config with matching benchmark_sectorial data.
-- Only returns rows for hotels with benchmark_available = TRUE.
-- The AI queries this view to compare a hotel's KPIs against the sector.
--
-- Usage: SELECT * FROM v_hotel_benchmark
--        WHERE hotel_name = 'Hotel X' AND year = 2026 AND month_num = 2
-- ----------------------------------------------------------------------------
CREATE OR REPLACE VIEW v_hotel_benchmark AS
SELECT
    h.hotel_name,
    h.benchmark_category,
    h.benchmark_country,
    h.benchmark_ccaa,
    h.benchmark_province,
    h.benchmark_zone,
    bs.year,
    bs.month_num,
    bs.occ             AS sector_occ,
    bs.adr             AS sector_adr,
    bs.revpar          AS sector_revpar,
    bs.occ_ly          AS sector_occ_ly,
    bs.adr_ly          AS sector_adr_ly,
    bs.revpar_ly       AS sector_revpar_ly,
    bs.yoy_occ         AS sector_yoy_occ,
    bs.yoy_adr         AS sector_yoy_adr,
    bs.yoy_revpar      AS sector_yoy_revpar
FROM dim_hotels h
JOIN benchmark_sectorial bs
    ON bs.country   = h.benchmark_country
   AND bs.ccaa      = h.benchmark_ccaa
   AND bs.province  = h.benchmark_province
   AND bs.zone      = h.benchmark_zone
   AND bs.category  = h.benchmark_category
WHERE h.benchmark_available = TRUE
  AND h.active = TRUE;

-- ----------------------------------------------------------------------------
-- v_hotel_vs_benchmark: Hotel KPIs vs sector benchmark in a single view
-- Combines the hotel's own monthly metrics (OTB) with the sector's benchmark
-- data, and pre-calculates the differences. This is the ONE view the AI
-- should query when the user asks "how am I vs the sector?".
--
-- Usage: SELECT * FROM v_hotel_vs_benchmark
--        WHERE hotel_name = 'Hotel X' AND year = 2026 AND month_num = 2
-- ----------------------------------------------------------------------------
CREATE OR REPLACE VIEW v_hotel_vs_benchmark AS
SELECT
    vhb.hotel_name,
    vhb.benchmark_category,
    vhb.benchmark_country,
    vhb.benchmark_ccaa,
    vhb.benchmark_province,
    vhb.benchmark_zone,
    vhb.year,
    vhb.month_num,
    -- Hotel own KPIs (OTB)
    ms.rooms_available                              AS hotel_rooms_available,
    ms.rn_otb                                       AS hotel_rn,
    ms.revenue_otb                                  AS hotel_revenue,
    ms.occ_otb                                      AS hotel_occ,
    ms.adr_otb                                      AS hotel_adr,
    ROUND(ms.revenue_otb / NULLIF(ms.rooms_available, 0), 2) AS hotel_revpar,
    -- Hotel LY KPIs
    ms.occ_ly                                       AS hotel_occ_ly,
    ms.adr_ly                                       AS hotel_adr_ly,
    ROUND(ms.revenue_ly / NULLIF(ms.rooms_available, 0), 2) AS hotel_revpar_ly,
    -- Sector KPIs
    vhb.sector_occ,
    vhb.sector_adr,
    vhb.sector_revpar,
    vhb.sector_occ_ly,
    vhb.sector_adr_ly,
    vhb.sector_revpar_ly,
    vhb.sector_yoy_occ,
    vhb.sector_yoy_adr,
    vhb.sector_yoy_revpar,
    -- Differences: hotel - sector (positive = hotel outperforms)
    ROUND(ms.occ_otb - vhb.sector_occ, 2)          AS diff_occ,
    ROUND(ms.adr_otb - vhb.sector_adr, 2)          AS diff_adr,
    ROUND(ROUND(ms.revenue_otb / NULLIF(ms.rooms_available, 0), 2)
          - vhb.sector_revpar, 2)                   AS diff_revpar
FROM v_hotel_benchmark vhb
LEFT JOIN v_monthly_summary ms
    ON ms.hotel_name = vhb.hotel_name
   AND ms.year      = vhb.year
   AND ms.month_num = vhb.month_num;
