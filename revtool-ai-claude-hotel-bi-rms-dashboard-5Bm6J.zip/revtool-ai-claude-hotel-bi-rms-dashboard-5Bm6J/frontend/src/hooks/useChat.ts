import { useState, useCallback, useRef } from 'react'
import * as api from '../services/api'
import type { ChatMessage, PersistedMessage } from '../types'

let messageIdCounter = 0
function generateId() {
  return `msg-${Date.now()}-${++messageIdCounter}`
}

function restoreMessages(persisted: PersistedMessage[]): ChatMessage[] {
  return persisted.map((m) => ({
    id: generateId(),
    role: m.role,
    content: m.content,
    cost_eur: m.cost_eur,
    balance_after: m.balance_after,
    analysis_mode: m.analysis_mode,
    timestamp: new Date(m.timestamp),
  }))
}

export function useChat() {
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [statusMessage, setStatusMessage] = useState('')
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const stopPolling = useCallback(() => {
    if (pollRef.current) {
      clearInterval(pollRef.current)
      pollRef.current = null
    }
  }, [])

  /**
   * Start polling for a background task that was already running when
   * the user (re)loaded the page.  Polls every 3 seconds until the
   * task finishes, then reloads messages from DB.
   */
  const recoverPending = useCallback(
    (onBalanceUpdate?: (balance: number) => void) => {
      setIsLoading(true)
      setStatusMessage('Procesando consulta anterior...')

      stopPolling()
      pollRef.current = setInterval(async () => {
        try {
          const { pending } = await api.getChatPending()
          if (!pending) {
            stopPolling()
            // Task finished — reload messages from DB
            const data = await api.getConversationMessages()
            if (data.messages.length > 0) {
              setMessages(restoreMessages(data.messages))
              // Update balance from the last assistant message
              const lastAssistant = [...data.messages]
                .reverse()
                .find((m) => m.role === 'assistant')
              if (lastAssistant?.balance_after != null && onBalanceUpdate) {
                onBalanceUpdate(lastAssistant.balance_after)
              }
            }
            setIsLoading(false)
            setStatusMessage('')
          }
        } catch {
          // Network error during poll — keep trying
        }
      }, 3000)
    },
    [stopPolling],
  )

  const sendMessage = useCallback(
    async (
      question: string,
      selectedHotels: string[],
      onBalanceUpdate?: (balance: number) => void,
      onMaintenanceDetected?: () => void,
    ) => {
      if (!question.trim() || selectedHotels.length === 0) return

      const userMessage: ChatMessage = {
        id: generateId(),
        role: 'user',
        content: question,
        timestamp: new Date(),
      }

      const aiMessageId = generateId()
      let accumulatedContent = ''
      let aiMessageAdded = false

      setMessages((prev) => [...prev, userMessage])
      setIsLoading(true)
      setStatusMessage('Conectando...')

      try {
        await api.sendMessageStream(question, selectedHotels, {
          onStatus: (message) => {
            setStatusMessage(message)
          },

          onDelta: (text) => {
            accumulatedContent += text
            setStatusMessage('')
            const content = accumulatedContent
            if (!aiMessageAdded) {
              aiMessageAdded = true
              setMessages((prev) => [
                ...prev,
                { id: aiMessageId, role: 'assistant', content, timestamp: new Date() },
              ])
            } else {
              setMessages((prev) =>
                prev.map((m) => (m.id === aiMessageId ? { ...m, content } : m)),
              )
            }
          },

          onResult: (result) => {
            setStatusMessage('')
            const final: ChatMessage = {
              id: aiMessageId,
              role: 'assistant',
              content: result.response,
              cost_eur: result.cost_eur,
              balance_after: result.balance_after,
              analysis_mode: result.analysis_mode,
              timestamp: new Date(),
            }
            if (!aiMessageAdded) {
              setMessages((prev) => [...prev, final])
            } else {
              setMessages((prev) =>
                prev.map((m) => (m.id === aiMessageId ? final : m)),
              )
            }
            if (onBalanceUpdate) onBalanceUpdate(result.balance_after)
          },

          onError: (error) => {
            setStatusMessage('')

            // 503 = maintenance mode — activate overlay, remove the user
            // message we just added, and bail out silently
            if (error.status === 503) {
              onMaintenanceDetected?.()
              setMessages((prev) => prev.filter((m) => m.id !== userMessage.id))
              return
            }

            const errorContent =
              error.status === 402
                ? 'Saldo insuficiente. Recarga credito para continuar.'
                : error.status === 403
                  ? 'No tienes acceso a uno o mas hoteles seleccionados.'
                  : error.status === 409
                    ? 'Ya hay una consulta en proceso. Espera a que termine.'
                    : error.status === 429
                      ? 'El servicio esta temporalmente sobrecargado. Espera unos segundos y vuelve a intentarlo.'
                      : `Error: ${error.message || 'No se pudo procesar la consulta.'}`

            // If stream was interrupted (502 from premature end), the background
            // task may still be running.  Start polling so the user eventually
            // sees the response.
            if (error.status === 502 && !error.message?.includes('Inténtalo')) {
              recoverPending(onBalanceUpdate)
              return
            }

            if (!aiMessageAdded) {
              setMessages((prev) => [
                ...prev,
                { id: generateId(), role: 'assistant', content: errorContent, timestamp: new Date() },
              ])
            } else {
              setMessages((prev) =>
                prev.map((m) => (m.id === aiMessageId ? { ...m, content: errorContent } : m)),
              )
            }
          },
        })
      } catch (err: any) {
        setStatusMessage('')
        // Connection lost — check if background task is still running
        try {
          const { pending } = await api.getChatPending()
          if (pending) {
            recoverPending(onBalanceUpdate)
            return
          }
        } catch {
          // Can't reach server at all
        }

        if (!aiMessageAdded) {
          setMessages((prev) => [
            ...prev,
            {
              id: generateId(),
              role: 'assistant',
              content: `Error: ${err.message || 'No se pudo procesar la consulta.'}`,
              timestamp: new Date(),
            },
          ])
        }
      } finally {
        // Only clear loading if we're not polling for a pending task
        if (!pollRef.current) {
          setIsLoading(false)
          setStatusMessage('')
        }
      }
    },
    [recoverPending],
  )

  const clearMessages = useCallback(() => {
    stopPolling()
    setMessages([])
  }, [stopPolling])

  const setInitialMessages = useCallback((msgs: ChatMessage[]) => {
    setMessages(msgs)
  }, [])

  return {
    messages,
    isLoading,
    statusMessage,
    sendMessage,
    clearMessages,
    setInitialMessages,
    recoverPending,
  }
}
