import { useState, useRef, useCallback, useEffect } from 'react'

/**
 * Hook for voice-to-text input using the Web Speech API.
 * Uses the browser's language so it matches the user's locale automatically.
 */

interface UseVoiceInputReturn {
  isListening: boolean
  isSupported: boolean
  startListening: () => void
  stopListening: () => void
}

export default function useVoiceInput(
  onTranscript: (text: string) => void,
): UseVoiceInputReturn {
  const [isListening, setIsListening] = useState(false)
  const recognitionRef = useRef<SpeechRecognition | null>(null)
  const onTranscriptRef = useRef(onTranscript)

  // Keep callback ref in sync
  useEffect(() => {
    onTranscriptRef.current = onTranscript
  }, [onTranscript])

  const SpeechRecognitionAPI =
    typeof window !== 'undefined'
      ? window.SpeechRecognition || window.webkitSpeechRecognition
      : null

  const isSupported = !!SpeechRecognitionAPI

  const stopListening = useCallback(() => {
    if (recognitionRef.current) {
      recognitionRef.current.stop()
    }
  }, [])

  const startListening = useCallback(() => {
    if (!SpeechRecognitionAPI) return

    // Stop any existing session
    if (recognitionRef.current) {
      recognitionRef.current.stop()
    }

    const recognition = new SpeechRecognitionAPI()
    recognitionRef.current = recognition

    recognition.lang = navigator.language || 'es-ES'
    recognition.interimResults = false
    recognition.continuous = false
    recognition.maxAlternatives = 1

    recognition.onstart = () => {
      setIsListening(true)
    }

    recognition.onresult = (event) => {
      const result = event.results[event.results.length - 1]
      if (result.isFinal) {
        const transcript = result[0].transcript.trim()
        if (transcript) {
          onTranscriptRef.current(transcript)
        }
      }
    }

    recognition.onerror = (event) => {
      // 'no-speech' and 'aborted' are not real errors
      if (event.error !== 'no-speech' && event.error !== 'aborted') {
        console.error('Speech recognition error:', event.error)
      }
      setIsListening(false)
    }

    recognition.onend = () => {
      setIsListening(false)
      recognitionRef.current = null
    }

    recognition.start()
  }, [SpeechRecognitionAPI])

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop()
      }
    }
  }, [])

  return { isListening, isSupported, startListening, stopListening }
}
