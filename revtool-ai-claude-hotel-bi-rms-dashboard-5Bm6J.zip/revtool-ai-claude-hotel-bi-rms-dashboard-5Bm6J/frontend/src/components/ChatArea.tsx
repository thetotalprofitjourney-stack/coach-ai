import { useEffect, useRef } from 'react'
import { useTranslation } from 'react-i18next'
import ChatMessageComponent from './ChatMessage'
import type { ChatMessage } from '../types'

interface ChatAreaProps {
  messages: ChatMessage[]
  isLoading: boolean
  statusMessage?: string
  onSendMessage?: (message: string) => void
}

export default function ChatArea({ messages, isLoading, statusMessage, onSendMessage }: ChatAreaProps) {
  const scrollRef = useRef<HTMLDivElement>(null)
  const bottomRef = useRef<HTMLDivElement>(null)
  const { t } = useTranslation()

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, isLoading])

  if (messages.length === 0 && !isLoading) {
    return (
      <div
        ref={scrollRef}
        className="h-full overflow-y-auto scrollbar-thin flex items-start justify-center p-3 sm:p-4 pt-6 sm:pt-10"
      >
        <div className="text-center max-w-lg lg:max-w-3xl w-full my-auto">
          <div className="inline-flex items-center justify-center w-12 h-12 sm:w-16 sm:h-16 mb-4 sm:mb-6">
            <img src="/revtool-logo.png" alt="Revtool AI" className="w-12 h-12 sm:w-16 sm:h-16 rounded-2xl" />
          </div>
          <h2 className="text-lg sm:text-xl font-semibold text-gray-800 mb-1.5 sm:mb-2">
            {t('chat.greeting')}
          </h2>
          <p className="text-gray-500 text-xs sm:text-sm mb-5 sm:mb-8 leading-relaxed">
            {t('chat.greetingDesc')}
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2 sm:gap-3 text-left">
            {[
              {
                title: t('suggestions.dailyBriefing'),
                desc: t('suggestions.dailyBriefingDesc'),
              },
              {
                title: t('suggestions.monthStatus'),
                desc: t('suggestions.monthStatusDesc'),
              },
              {
                title: t('suggestions.priceRecs'),
                desc: t('suggestions.priceRecsDesc'),
              },
              {
                title: t('suggestions.channelAnalysis'),
                desc: t('suggestions.channelAnalysisDesc'),
              },
              {
                title: t('suggestions.lastMonthClose'),
                desc: t('suggestions.lastMonthCloseDesc'),
              },
              {
                title: t('suggestions.marketingCampaigns'),
                desc: t('suggestions.marketingCampaignsDesc'),
                message: t('suggestions.marketingCampaignsMessage'),
              },
            ].map((item) => (
              <button
                key={item.title}
                type="button"
                onClick={() => onSendMessage?.('message' in item && item.message ? item.message : item.title)}
                className="bg-white border border-gray-200 rounded-xl p-2.5 sm:p-3.5 hover:border-blue-300 hover:shadow-sm transition-all cursor-pointer text-left"
              >
                <p className="text-xs sm:text-sm font-medium text-gray-800">
                  {item.title}
                </p>
                <p className="text-[10px] sm:text-xs text-gray-500 mt-0.5">{item.desc}</p>
              </button>
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div
      ref={scrollRef}
      className="h-full overflow-y-auto scrollbar-thin"
    >
      <div className="max-w-4xl mx-auto px-3 sm:px-4 py-3 sm:py-6 space-y-1">
        {messages.map((msg) => (
          <ChatMessageComponent key={msg.id} message={msg} />
        ))}

        {isLoading && statusMessage && (
          <div className="flex gap-3 animate-fade-in py-3">
            <div className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0">
              <img src="/revtool-logo.png" alt="Revtool AI" className="w-8 h-8 rounded-xl" />
            </div>
            <div className="bg-white border border-gray-100 rounded-2xl rounded-tl-md px-4 py-3 shadow-sm">
              <div className="flex gap-1.5 items-center h-5">
                <span className="text-sm text-gray-500 animate-pulse">{statusMessage}</span>
              </div>
            </div>
          </div>
        )}

        <div ref={bottomRef} />
      </div>
    </div>
  )
}
