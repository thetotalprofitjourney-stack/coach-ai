import { Wallet, Plus, AlertTriangle } from 'lucide-react'
import { useTranslation } from 'react-i18next'
import { useSession } from '../contexts/SessionContext'

interface BalanceDisplayProps {
  onRecharge: () => void
}

export default function BalanceDisplay({ onRecharge }: BalanceDisplayProps) {
  const { session, credits } = useSession()
  const { t } = useTranslation()

  const balance = credits?.balance_eur ?? session?.balance_eur ?? 0
  const isLow = credits?.is_low_balance ?? balance < 2
  const isBlocked = credits?.is_blocked ?? balance <= 0

  const colorClass = isBlocked
    ? 'text-red-400'
    : isLow
      ? 'text-amber-400'
      : 'text-emerald-400'

  const bgClass = isBlocked
    ? 'bg-red-500/10 border-red-500/30'
    : isLow
      ? 'bg-amber-500/10 border-amber-500/30'
      : 'bg-slate-800 border-slate-600/50'

  return (
    <div className={`flex items-center gap-2 rounded-lg px-3 py-1.5 border ${bgClass}`}>
      {isLow ? (
        <AlertTriangle className={`w-3.5 h-3.5 ${colorClass} shrink-0`} />
      ) : (
        <Wallet className={`w-3.5 h-3.5 ${colorClass} shrink-0`} />
      )}
      <span className={`text-sm font-medium ${colorClass}`}>
        {balance.toFixed(2)}&euro;
      </span>
      <button
        onClick={onRecharge}
        className="flex items-center justify-center w-6 h-6 bg-blue-500 hover:bg-blue-400 rounded-md transition-colors"
        title={t('header.rechargeBalance')}
      >
        <Plus className="w-3.5 h-3.5 text-white" />
      </button>
    </div>
  )
}
