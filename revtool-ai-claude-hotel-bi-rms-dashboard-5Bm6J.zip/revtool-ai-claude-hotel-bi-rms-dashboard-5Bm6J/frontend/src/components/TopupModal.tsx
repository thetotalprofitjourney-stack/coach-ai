import { useState } from 'react'
import { X, CreditCard, Wallet, TrendingUp, Loader2 } from 'lucide-react'
import { useTranslation } from 'react-i18next'
import { useSession } from '../contexts/SessionContext'
import * as api from '../services/api'

interface TopupModalProps {
  isOpen: boolean
  onClose: () => void
}

const FIXED_AMOUNT = 500

export default function TopupModal({ isOpen, onClose }: TopupModalProps) {
  const { session, credits } = useSession()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const { t } = useTranslation()

  if (!isOpen) return null

  const balance = credits?.balance_eur ?? session?.balance_eur ?? 0
  const monthCost = credits?.cost_eur_this_month ?? 0
  const vatApplicable = session?.vat_applicable ?? false
  const vatRate = session?.vat_rate ?? 0

  // Calculate IVA breakdown for the fixed 500€ amount
  const baseAmount = vatApplicable
    ? Math.round((FIXED_AMOUNT / (1 + vatRate / 100)) * 100) / 100
    : FIXED_AMOUNT
  const vatAmount = vatApplicable
    ? Math.round((FIXED_AMOUNT - baseAmount) * 100) / 100
    : 0

  const handleSubmit = async () => {
    setLoading(true)
    setError('')

    try {
      const { checkout_url } = await api.createCheckout(FIXED_AMOUNT)
      window.location.href = checkout_url
    } catch (err: any) {
      setError(err.message || t('topup.errorCheckout'))
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/40 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md animate-slide-up overflow-hidden">
        {/* Header */}
        <div className="px-6 py-5" style={{ backgroundColor: '#060734' }}>
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1 text-white/70 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/10 rounded-xl">
              <CreditCard className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-white font-semibold text-lg">
                {t('topup.title')}
              </h2>
              <p className="text-slate-400 text-xs">{t('topup.stripeSecure')}</p>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 gap-3 px-6 -mt-3">
          <div className="bg-white border border-gray-200 rounded-xl p-3 shadow-sm">
            <div className="flex items-center gap-2 mb-1">
              <Wallet className="w-3.5 h-3.5 text-gray-400" />
              <span className="text-[10px] text-gray-500 uppercase tracking-wider">
                {t('topup.currentBalance')}
              </span>
            </div>
            <p
              className={`text-lg font-semibold ${
                balance <= 0
                  ? 'text-red-600'
                  : balance < 2
                    ? 'text-amber-600'
                    : 'text-gray-900'
              }`}
            >
              {balance.toFixed(2)}&euro;
            </p>
          </div>
          <div className="bg-white border border-gray-200 rounded-xl p-3 shadow-sm">
            <div className="flex items-center gap-2 mb-1">
              <TrendingUp className="w-3.5 h-3.5 text-gray-400" />
              <span className="text-[10px] text-gray-500 uppercase tracking-wider">
                {t('topup.thisMonth')}
              </span>
            </div>
            <p className="text-lg font-semibold text-gray-900">
              {monthCost.toFixed(2)}&euro;
            </p>
          </div>
        </div>

        {/* Content */}
        <div className="px-6 py-5 space-y-4">
          {/* IVA breakdown */}
          <div className="bg-gray-50 border border-gray-200 rounded-xl p-4 space-y-2">
            <div className="flex justify-between text-sm text-gray-600">
              <span>{t('topup.taxBase')}</span>
              <span className="font-medium">{baseAmount.toFixed(2)}&euro;</span>
            </div>
            <div className="flex justify-between text-sm text-gray-600">
              <span>{t('topup.vat', { rate: vatRate.toFixed(0) })}</span>
              <span className="font-medium">{vatAmount.toFixed(2)}&euro;</span>
            </div>
            <div className="border-t border-gray-200 pt-2 flex justify-between text-sm text-gray-800">
              <span className="font-medium">{t('topup.totalToPay')}</span>
              <span className="font-semibold">
                {FIXED_AMOUNT.toFixed(2)}&euro;
              </span>
            </div>
            <div className="border-t border-gray-200 pt-2 flex justify-between text-sm">
              <span className="text-blue-600 font-medium">
                {t('topup.creditsToReceive')}
              </span>
              <span className="text-blue-600 font-semibold">
                {baseAmount.toFixed(2)}&euro;
              </span>
            </div>
          </div>

          {error && (
            <p className="text-sm text-red-600 bg-red-50 px-3 py-2 rounded-lg">
              {error}
            </p>
          )}

          {/* Submit */}
          <button
            onClick={handleSubmit}
            disabled={loading}
            className={`w-full py-3.5 rounded-xl font-medium text-sm transition-all flex items-center justify-center gap-2 ${
              !loading
                ? 'text-white shadow-md hover:shadow-lg hover:opacity-90'
                : 'bg-gray-200 text-gray-400 cursor-not-allowed'
            }`}
            style={!loading ? { backgroundColor: '#060734' } : undefined}
          >
            {loading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <CreditCard className="w-4 h-4" />
            )}
            {loading
              ? t('topup.redirectingStripe')
              : t('topup.pay', { amount: FIXED_AMOUNT.toFixed(2) })}
          </button>
        </div>
      </div>
    </div>
  )
}
