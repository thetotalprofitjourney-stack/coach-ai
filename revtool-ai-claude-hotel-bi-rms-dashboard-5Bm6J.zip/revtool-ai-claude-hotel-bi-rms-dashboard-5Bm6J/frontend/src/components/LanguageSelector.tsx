import { useTranslation } from 'react-i18next'

interface LanguageSelectorProps {
  onChange?: (lang: string) => void
  variant?: 'header' | 'login'
}

export default function LanguageSelector({ onChange, variant = 'header' }: LanguageSelectorProps) {
  const { i18n } = useTranslation()
  const current = i18n.language

  const switchLang = (lang: string) => {
    if (lang === current) return
    i18n.changeLanguage(lang)
    localStorage.setItem('revtool-lang', lang)
    onChange?.(lang)
  }

  const langs = ['es', 'en'] as const

  return (
    <div className="flex items-center bg-slate-500/30 rounded-lg p-0.5 border border-slate-500/40">
      {langs.map((lang) => {
        const isActive = current === lang
        const label = lang.toUpperCase()

        const styles =
          variant === 'header'
            ? isActive
              ? 'bg-blue-500 text-white shadow-sm'
              : 'text-slate-300 hover:text-white hover:bg-slate-600'
            : isActive
              ? 'bg-white/20 text-white shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-white/10'

        return (
          <button
            key={lang}
            onClick={() => switchLang(lang)}
            className={`px-2 py-1 rounded-md text-[11px] font-bold tracking-wide transition-all ${styles}`}
            title={lang === 'es' ? 'Español' : 'English'}
          >
            {label}
          </button>
        )
      })}
    </div>
  )
}
