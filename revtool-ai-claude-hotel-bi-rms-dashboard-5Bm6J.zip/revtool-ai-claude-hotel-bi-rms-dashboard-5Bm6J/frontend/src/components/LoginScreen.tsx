import { useMsal } from '@azure/msal-react'
import { loginRequest, isEmbedded } from '../config/msal'
import { Shield, Zap, BarChart3 } from 'lucide-react'
import { useTranslation } from 'react-i18next'
import LanguageSelector from './LanguageSelector'

export default function LoginScreen() {
  const { instance } = useMsal()
  const { t } = useTranslation()

  const handleLogin = () => {
    // Use popup login when embedded in an iframe (Power BI) since
    // redirect-based login cannot navigate the parent frame.
    if (isEmbedded) {
      instance.loginPopup(loginRequest)
    } else {
      instance.loginRedirect(loginRequest)
    }
  }

  return (
    <div className="h-full w-full flex items-center justify-center px-5 py-8 sm:p-6 overflow-y-auto" style={{ backgroundColor: '#060734' }}>
      <div className="max-w-md w-full">
        {/* Language selector — top right */}
        <div className="flex justify-end mb-4">
          <LanguageSelector variant="login" />
        </div>

        {/* Logo & Title */}
        <div className="text-center mb-8 sm:mb-10">
          <div className="inline-flex items-center justify-center w-14 h-14 sm:w-16 sm:h-16 mb-4 sm:mb-6">
            <img src="/revtool-logo.png" alt="Revtool AI" className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
            Revtool <span className="text-blue-400">AI</span>
          </h1>
          <p className="text-slate-400 mt-1.5 sm:mt-2 text-sm">
            {t('login.subtitle')}
          </p>
        </div>

        {/* Login Card */}
        <div className="bg-white/5 backdrop-blur-lg rounded-2xl border border-white/10 p-5 sm:p-8">
          <div className="space-y-4 sm:space-y-6 mb-6 sm:mb-8">
            <div className="flex items-start gap-3">
              <div className="p-2 sm:p-2.5 bg-blue-500/10 rounded-lg mt-0.5 shrink-0">
                <Zap className="w-5 h-5 text-blue-400" />
              </div>
              <div>
                <h3 className="text-white text-sm font-medium">
                  {t('login.smartAnalysis')}
                </h3>
                <p className="text-slate-400 text-xs mt-0.5 leading-relaxed">
                  {t('login.smartAnalysisDesc')}
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="p-2 sm:p-2.5 bg-emerald-500/10 rounded-lg mt-0.5 shrink-0">
                <Shield className="w-5 h-5 text-emerald-400" />
              </div>
              <div>
                <h3 className="text-white text-sm font-medium">
                  {t('login.secureData')}
                </h3>
                <p className="text-slate-400 text-xs mt-0.5 leading-relaxed">
                  {t('login.secureDataDesc')}
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="p-2 sm:p-2.5 bg-amber-500/10 rounded-lg mt-0.5 shrink-0">
                <BarChart3 className="w-5 h-5 text-amber-400" />
              </div>
              <div>
                <h3 className="text-white text-sm font-medium">
                  {t('login.specificRecs')}
                </h3>
                <p className="text-slate-400 text-xs mt-0.5 leading-relaxed">
                  {t('login.specificRecsDesc')}
                </p>
              </div>
            </div>
          </div>

          <button
            onClick={handleLogin}
            className="w-full flex items-center justify-center gap-3 bg-white hover:bg-gray-50 text-gray-800 font-semibold py-4 sm:py-3.5 px-4 rounded-xl text-base transition-all duration-200 shadow-lg hover:shadow-xl active:scale-[0.98]"
          >
            <svg className="w-5 h-5" viewBox="0 0 21 21">
              <rect x="1" y="1" width="9" height="9" fill="#f25022" />
              <rect x="11" y="1" width="9" height="9" fill="#7fba00" />
              <rect x="1" y="11" width="9" height="9" fill="#00a4ef" />
              <rect x="11" y="11" width="9" height="9" fill="#ffb900" />
            </svg>
            {t('login.loginButton')}
          </button>
        </div>

        <p className="text-center text-slate-500 text-[11px] sm:text-xs mt-5 sm:mt-6">
          {t('login.poweredBy')} &middot; Revenue Management Assistant
        </p>
      </div>
    </div>
  )
}
