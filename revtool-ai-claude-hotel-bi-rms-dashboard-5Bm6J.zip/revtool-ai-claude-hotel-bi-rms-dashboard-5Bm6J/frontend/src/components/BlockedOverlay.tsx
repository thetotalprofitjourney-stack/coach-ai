import { AlertTriangle, CreditCard } from 'lucide-react'
import { useTranslation } from 'react-i18next'

interface BlockedOverlayProps {
  onRecharge: () => void
}

export default function BlockedOverlay({ onRecharge }: BlockedOverlayProps) {
  const { t } = useTranslation()

  return (
    <div className="absolute inset-0 bg-white/80 backdrop-blur-sm flex items-center justify-center z-20 animate-fade-in">
      <div className="text-center max-w-sm px-6">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-red-50 rounded-2xl mb-4">
          <AlertTriangle className="w-8 h-8 text-red-500" />
        </div>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">
          {t('balance.noBalance')}
        </h3>
        <p className="text-sm text-gray-500 mb-6 leading-relaxed">
          {t('balance.noBalanceDesc')}
        </p>
        <button
          onClick={onRecharge}
          className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 px-6 rounded-xl transition-all shadow-md hover:shadow-lg"
        >
          <CreditCard className="w-4 h-4" />
          {t('balance.recharge')}
        </button>
      </div>
    </div>
  )
}
