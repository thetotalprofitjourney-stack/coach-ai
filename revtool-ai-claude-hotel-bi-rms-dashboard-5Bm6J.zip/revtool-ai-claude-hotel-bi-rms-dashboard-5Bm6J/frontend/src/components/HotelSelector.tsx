import { useState, useRef, useEffect, useMemo } from 'react'
import { Building2, ChevronDown, Check, X, Filter } from 'lucide-react'
import { useTranslation } from 'react-i18next'
import { useSession } from '../contexts/SessionContext'
import type { HotelConfig } from '../types'

type FilterKey = 'hotel_type' | 'target_client' | 'destination'

export default function HotelSelector() {
  const { session, hotelsData, selectedHotels, setSelectedHotels } =
    useSession()
  const { t } = useTranslation()

  const TYPE_LABELS: Record<string, string> = {
    vacation: t('hotelSelector.vacation'),
    urban: t('hotelSelector.urban'),
    mixed: t('hotelSelector.mixed'),
  }

  const CLIENT_LABELS: Record<string, string> = {
    family: t('hotelSelector.family'),
    adults_only: t('hotelSelector.adultsOnly'),
    mixed: t('hotelSelector.mixed'),
  }
  const [isOpen, setIsOpen] = useState(false)
  const [filters, setFilters] = useState<Record<FilterKey, string | null>>({
    hotel_type: null,
    target_client: null,
    destination: null,
  })
  const dropdownRef = useRef<HTMLDivElement>(null)

  const pendingSetup = new Set(session?.hotels_pending_setup || [])

  // Close on click outside
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(e.target as Node)
      ) {
        setIsOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  // Derive unique filter options from hotel metadata
  const filterOptions = useMemo(() => {
    const types = new Set<string>()
    const clients = new Set<string>()
    const destinations = new Set<string>()

    for (const h of hotelsData) {
      if (h.hotel_type) types.add(h.hotel_type)
      if (h.target_client) clients.add(h.target_client)
      if (h.destination) destinations.add(h.destination)
    }

    return {
      hotel_type: [...types].sort(),
      target_client: [...clients].sort(),
      destination: [...destinations].sort(),
    }
  }, [hotelsData])

  // Apply filters to hotel list
  const filteredHotels = useMemo(() => {
    return hotelsData.filter((h) => {
      if (filters.hotel_type && h.hotel_type !== filters.hotel_type)
        return false
      if (filters.target_client && h.target_client !== filters.target_client)
        return false
      if (filters.destination && h.destination !== filters.destination)
        return false
      return true
    })
  }, [hotelsData, filters])

  const activeFilterCount = Object.values(filters).filter(Boolean).length

  // Check if any filter has more than 1 option (worth showing)
  const hasUsefulFilters =
    filterOptions.hotel_type.length > 1 ||
    filterOptions.target_client.length > 1 ||
    filterOptions.destination.length > 1

  const toggleHotel = (hotel: string) => {
    if (selectedHotels.includes(hotel)) {
      if (selectedHotels.length > 1) {
        setSelectedHotels(selectedHotels.filter((h) => h !== hotel))
      }
    } else {
      setSelectedHotels([...selectedHotels, hotel])
    }
  }

  const selectAllFiltered = () => {
    setSelectedHotels(filteredHotels.map((h) => h.hotel_name))
  }

  const selectOne = (hotel: string) => setSelectedHotels([hotel])

  const toggleFilter = (key: FilterKey, value: string) => {
    setFilters((prev) => ({
      ...prev,
      [key]: prev[key] === value ? null : value,
    }))
  }

  const clearFilters = () => {
    setFilters({ hotel_type: null, target_client: null, destination: null })
  }

  const totalHotels = hotelsData.length
  const mode =
    selectedHotels.length === 1
      ? t('hotelSelector.hotel')
      : selectedHotels.length > 1
        ? t('hotelSelector.grupo')
        : null

  const label =
    selectedHotels.length === 0
      ? t('hotelSelector.selectHotels')
      : selectedHotels.length === 1
        ? selectedHotels[0]
        : t('hotelSelector.hotelsOf', { count: selectedHotels.length, total: totalHotels })

  const hotelMeta = (hotel: HotelConfig) => {
    const parts: string[] = []
    if (hotel.hotel_type && TYPE_LABELS[hotel.hotel_type])
      parts.push(TYPE_LABELS[hotel.hotel_type])
    if (hotel.destination) parts.push(hotel.destination)
    return parts.join(' · ')
  }

  return (
    <div ref={dropdownRef} className="relative w-full max-w-md">
      {/* Trigger button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 w-full text-white rounded-lg px-3 py-2 transition-colors border border-slate-600/50 hover:opacity-90"
        style={{ backgroundColor: '#060734' }}
      >
        <Building2 className="w-4 h-4 text-slate-400 shrink-0" />
        <span className="truncate text-sm flex-1 text-left">{label}</span>
        {mode && (
          <span
            className={`text-[10px] font-medium px-1.5 py-0.5 rounded-full shrink-0 ${
              mode === 'hotel'
                ? 'bg-blue-500/20 text-blue-300'
                : 'bg-purple-500/20 text-purple-300'
            }`}
          >
            {mode}
          </span>
        )}
        <ChevronDown
          className={`w-3.5 h-3.5 text-slate-400 transition-transform shrink-0 ${
            isOpen ? 'rotate-180' : ''
          }`}
        />
      </button>

      {/* Dropdown panel */}
      {isOpen && (
        <div className="absolute top-full left-0 right-0 mt-1 border border-slate-600/50 rounded-lg shadow-xl overflow-hidden animate-fade-in z-50 min-w-[320px]" style={{ backgroundColor: '#060734' }}>
          {/* Filter section */}
          {hasUsefulFilters && (
            <div className="px-3 py-2.5 border-b border-slate-700/50 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-[11px] text-slate-400 font-medium uppercase tracking-wide">
                  <Filter className="w-3 h-3" />
                  {t('hotelSelector.filters')}
                </div>
                {activeFilterCount > 0 && (
                  <button
                    onClick={clearFilters}
                    className="flex items-center gap-1 text-[10px] text-slate-500 hover:text-slate-300 transition-colors"
                  >
                    <X className="w-3 h-3" />
                    {t('hotelSelector.clean')}
                  </button>
                )}
              </div>

              {/* Hotel type chips */}
              {filterOptions.hotel_type.length > 1 && (
                <div className="flex flex-wrap gap-1.5">
                  {filterOptions.hotel_type.map((type) => (
                    <button
                      key={type}
                      onClick={() => toggleFilter('hotel_type', type)}
                      className={`text-[11px] px-2 py-0.5 rounded-full transition-colors ${
                        filters.hotel_type === type
                          ? 'bg-blue-500/30 text-blue-200 ring-1 ring-blue-500/50'
                          : 'bg-slate-700/50 text-slate-400 hover:bg-slate-700 hover:text-slate-300'
                      }`}
                    >
                      {TYPE_LABELS[type] || type}
                    </button>
                  ))}
                </div>
              )}

              {/* Target client chips */}
              {filterOptions.target_client.length > 1 && (
                <div className="flex flex-wrap gap-1.5">
                  {filterOptions.target_client.map((client) => (
                    <button
                      key={client}
                      onClick={() => toggleFilter('target_client', client)}
                      className={`text-[11px] px-2 py-0.5 rounded-full transition-colors ${
                        filters.target_client === client
                          ? 'bg-purple-500/30 text-purple-200 ring-1 ring-purple-500/50'
                          : 'bg-slate-700/50 text-slate-400 hover:bg-slate-700 hover:text-slate-300'
                      }`}
                    >
                      {CLIENT_LABELS[client] || client}
                    </button>
                  ))}
                </div>
              )}

              {/* Destination chips */}
              {filterOptions.destination.length > 1 && (
                <div className="flex flex-wrap gap-1.5">
                  {filterOptions.destination.map((dest) => (
                    <button
                      key={dest}
                      onClick={() => toggleFilter('destination', dest)}
                      className={`text-[11px] px-2 py-0.5 rounded-full transition-colors ${
                        filters.destination === dest
                          ? 'bg-emerald-500/30 text-emerald-200 ring-1 ring-emerald-500/50'
                          : 'bg-slate-700/50 text-slate-400 hover:bg-slate-700 hover:text-slate-300'
                      }`}
                    >
                      {dest}
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Action bar */}
          <div className="flex items-center justify-between px-3 py-1.5 border-b border-slate-700/50 bg-slate-900/30">
            <span className="text-[11px] text-slate-500">
              {filteredHotels.length === totalHotels
                ? `${totalHotels} hoteles`
                : `${filteredHotels.length} de ${totalHotels} hoteles`}
            </span>
            {filteredHotels.length > 1 && (
              <button
                onClick={selectAllFiltered}
                className="text-[11px] text-blue-400 hover:text-blue-300 transition-colors"
              >
                {t('hotelSelector.selectAll')}
              </button>
            )}
          </div>

          {/* Hotel list */}
          <div className="max-h-56 overflow-y-auto scrollbar-thin">
            {filteredHotels.length === 0 ? (
              <div className="px-3 py-4 text-center text-xs text-slate-500">
                {t('hotelSelector.noMatch')}
              </div>
            ) : (
              filteredHotels.map((hotel) => {
                const isSelected = selectedHotels.includes(hotel.hotel_name)
                const isPending = pendingSetup.has(hotel.hotel_name)
                const meta = hotelMeta(hotel)
                return (
                  <button
                    key={hotel.hotel_name}
                    onClick={() => toggleHotel(hotel.hotel_name)}
                    onDoubleClick={() => selectOne(hotel.hotel_name)}
                    className={`flex items-center gap-2 w-full px-3 py-2 text-left transition-colors ${
                      isSelected
                        ? 'bg-blue-500/10 text-white'
                        : 'text-slate-300 hover:bg-slate-700/50'
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded border flex items-center justify-center shrink-0 transition-colors ${
                        isSelected
                          ? 'bg-blue-500 border-blue-500'
                          : 'border-slate-500'
                      }`}
                    >
                      {isSelected && <Check className="w-3 h-3 text-white" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <span className="text-sm truncate block">
                        {hotel.hotel_name}
                      </span>
                      {meta && (
                        <span className="text-[10px] text-slate-500 truncate block">
                          {meta}
                        </span>
                      )}
                    </div>
                    {isPending && (
                      <span className="text-[10px] text-amber-400 bg-amber-500/10 px-1.5 py-0.5 rounded-full shrink-0">
                        {t('hotelSelector.pending')}
                      </span>
                    )}
                  </button>
                )
              })
            )}
          </div>

          {/* Mode explanation footer */}
          <div className="px-3 py-2 border-t border-slate-700/50 bg-slate-900/50">
            {selectedHotels.length <= 1 ? (
              <p className="text-[10px] text-slate-500">
                <span className="inline-block w-1.5 h-1.5 rounded-full bg-blue-400 mr-1 align-middle" />
                {t('hotelSelector.hotelMode')}
              </p>
            ) : (
              <p className="text-[10px] text-slate-500">
                <span className="inline-block w-1.5 h-1.5 rounded-full bg-purple-400 mr-1 align-middle" />
                {t('hotelSelector.groupMode', { count: selectedHotels.length })}
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
