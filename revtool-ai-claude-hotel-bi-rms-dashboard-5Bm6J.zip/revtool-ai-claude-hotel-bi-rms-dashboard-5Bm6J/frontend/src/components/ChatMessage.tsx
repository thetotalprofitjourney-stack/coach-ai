import ReactMarkdown from 'react-markdown'
import remarkGfm from 'remark-gfm'
import { Copy, Check } from 'lucide-react'
import { useState } from 'react'
import type { ChatMessage } from '../types'

interface ChatMessageProps {
  message: ChatMessage
}

export default function ChatMessageComponent({ message }: ChatMessageProps) {
  const [copied, setCopied] = useState(false)
  const isUser = message.role === 'user'

  const handleCopy = async () => {
    await navigator.clipboard.writeText(message.content)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  if (isUser) {
    return (
      <div className="flex justify-end py-2 animate-slide-up">
        <div className="max-w-[80%] lg:max-w-[60%]">
          <div className="bg-blue-600 text-white rounded-2xl rounded-br-md px-4 py-2.5 shadow-sm">
            <p className="text-sm whitespace-pre-wrap leading-relaxed">
              {message.content}
            </p>
          </div>
          <p className="text-[10px] text-gray-400 mt-1 text-right">
            {message.timestamp.toLocaleTimeString('es-ES', {
              hour: '2-digit',
              minute: '2-digit',
            })}
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="flex gap-3 py-3 animate-slide-up group">
      <div className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0 mt-0.5">
        <img src="/revtool-logo.png" alt="Revtool AI" className="w-8 h-8 rounded-xl" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="bg-white border border-gray-100 rounded-2xl rounded-tl-md px-5 py-4 shadow-sm relative">
          {/* Copy button */}
          <button
            onClick={handleCopy}
            className="absolute top-3 right-3 p-1.5 text-gray-300 hover:text-gray-500 hover:bg-gray-100 rounded-md transition-colors opacity-0 group-hover:opacity-100"
            title="Copiar respuesta"
          >
            {copied ? (
              <Check className="w-3.5 h-3.5 text-green-500" />
            ) : (
              <Copy className="w-3.5 h-3.5" />
            )}
          </button>

          <div className="prose text-sm text-gray-700 max-w-none pr-8">
            <ReactMarkdown remarkPlugins={[remarkGfm]}>
              {message.content}
            </ReactMarkdown>
          </div>
        </div>

        {/* Cost footer */}
        <div className="flex items-center gap-3 mt-1.5 px-1">
          <p className="text-[10px] text-gray-400">
            {message.timestamp.toLocaleTimeString('es-ES', {
              hour: '2-digit',
              minute: '2-digit',
            })}
          </p>
          {message.cost_eur !== undefined && (
            <p className="text-[10px] text-gray-400">
              Consulta: {message.cost_eur.toFixed(4)}&euro;
              {message.balance_after !== undefined &&
                ` · Saldo: ${message.balance_after.toFixed(2)}\u20AC`}
            </p>
          )}
          {message.analysis_mode && (
            <span
              className={`text-[10px] font-medium px-1.5 py-0.5 rounded-full ${
                message.analysis_mode === 'hotel'
                  ? 'bg-blue-50 text-blue-600'
                  : 'bg-purple-50 text-purple-600'
              }`}
            >
              {message.analysis_mode}
            </span>
          )}
        </div>
      </div>
    </div>
  )
}
