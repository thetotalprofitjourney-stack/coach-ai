import { useState, useEffect, useCallback } from 'react'
import {
  X,
  Settings,
  Check,
  AlertCircle,
  ChevronDown,
  Loader2,
  Save,
} from 'lucide-react'
import { useTranslation } from 'react-i18next'
import * as api from '../services/api'
import type { HotelConfig, BenchmarkGeo } from '../types'

interface HotelConfigModalProps {
  isOpen: boolean
  onClose: () => void
}

const CURRENCIES = ['EUR', 'USD', 'GBP', 'CHF', 'MXN']

export default function HotelConfigModal({
  isOpen,
  onClose,
}: HotelConfigModalProps) {
  const { t } = useTranslation()
  const [hotels, setHotels] = useState<HotelConfig[]>([])
  const [benchmarkGeo, setBenchmarkGeo] = useState<BenchmarkGeo[]>([])
  const [benchmarkCategories, setBenchmarkCategories] = useState<string[]>([])
  const [selectedHotel, setSelectedHotel] = useState<string | null>(null)
  const [form, setForm] = useState<Partial<HotelConfig>>({})
  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [success, setSuccess] = useState('')
  const [error, setError] = useState('')

  const HOTEL_TYPES = [
    { value: 'vacation', label: t('hotelConfig.typeVacation') },
    { value: 'urban', label: t('hotelConfig.typeUrban') },
    { value: 'mixed', label: t('hotelConfig.typeMixed') },
  ]

  const TARGET_CLIENTS = [
    { value: 'family', label: t('hotelConfig.clientFamily') },
    { value: 'adults_only', label: t('hotelConfig.clientAdultsOnly') },
    { value: 'mixed', label: t('hotelConfig.clientMixed') },
  ]

  const COUNTRIES = [
    { value: 'ES', label: t('hotelConfig.countryES') },
    { value: 'PT', label: t('hotelConfig.countryPT') },
    { value: 'MX', label: t('hotelConfig.countryMX') },
    { value: 'DO', label: t('hotelConfig.countryDO') },
    { value: 'IT', label: t('hotelConfig.countryIT') },
    { value: 'FR', label: t('hotelConfig.countryFR') },
    { value: 'DE', label: t('hotelConfig.countryDE') },
    { value: 'GB', label: t('hotelConfig.countryGB') },
    { value: 'US', label: t('hotelConfig.countryUS') },
  ]

  const loadData = useCallback(async () => {
    setLoading(true)
    try {
      const [hotelData, geoData, catData] = await Promise.all([
        api.getHotelsConfig(),
        api.getBenchmarkGeo(),
        api.getBenchmarkCategories(),
      ])
      setHotels(hotelData)
      setBenchmarkGeo(geoData)
      setBenchmarkCategories(catData)

      if (hotelData.length > 0 && !selectedHotel) {
        setSelectedHotel(hotelData[0].hotel_name)
        setForm(hotelData[0])
      }
    } catch {
      setError(t('hotelConfig.errorLoading'))
    } finally {
      setLoading(false)
    }
  }, [selectedHotel])

  useEffect(() => {
    if (isOpen) loadData()
  }, [isOpen, loadData])

  const handleSelectHotel = (name: string) => {
    const hotel = hotels.find((h) => h.hotel_name === name)
    if (hotel) {
      setSelectedHotel(name)
      setForm({ ...hotel })
      setSuccess('')
      setError('')
    }
  }

  const handleFieldChange = (field: string, value: string | number | boolean | null) => {
    setForm((prev) => ({ ...prev, [field]: value }))
    setSuccess('')
  }

  const handleBenchmarkGeoSelect = (displayLabel: string) => {
    const geo = benchmarkGeo.find((g) => g.display_label === displayLabel)
    if (geo) {
      setForm((prev) => ({
        ...prev,
        benchmark_country: geo.country,
        benchmark_ccaa: geo.ccaa,
        benchmark_province: geo.province,
        benchmark_zone: geo.zone,
        benchmark_available: true,
      }))
      setSuccess('')
    }
  }

  const handleSave = async () => {
    if (!selectedHotel) return
    setSaving(true)
    setError('')
    setSuccess('')

    try {
      await api.updateHotelConfig(selectedHotel, form)
      setSuccess(t('hotelConfig.savedOk'))

      // Refresh hotels list
      const hotelData = await api.getHotelsConfig()
      setHotels(hotelData)
    } catch (err: any) {
      setError(err.message || t('hotelConfig.errorSave'))
    } finally {
      setSaving(false)
    }
  }

  if (!isOpen) return null

  const isSpain = form.country === 'ES'

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-black/40 backdrop-blur-sm"
        onClick={onClose}
      />

      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col animate-slide-up overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 flex items-center justify-between shrink-0" style={{ backgroundColor: '#060734' }}>
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/10 rounded-xl">
              <Settings className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-white font-semibold">
                {t('hotelConfig.title')}
              </h2>
              <p className="text-slate-400 text-xs">
                {t('hotelConfig.subtitle')}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
          </div>
        ) : (
          <div className="flex flex-1 overflow-hidden">
            {/* Hotel list sidebar */}
            <div className="w-56 border-r border-gray-200 bg-gray-50 overflow-y-auto scrollbar-thin shrink-0">
              {hotels.map((hotel) => (
                <button
                  key={hotel.hotel_name}
                  onClick={() => handleSelectHotel(hotel.hotel_name)}
                  className={`w-full px-4 py-3 text-left border-b border-gray-100 transition-colors ${
                    selectedHotel === hotel.hotel_name
                      ? 'bg-white border-l-2 border-l-blue-500'
                      : 'hover:bg-gray-100'
                  }`}
                >
                  <p className="text-sm font-medium text-gray-800 truncate">
                    {hotel.hotel_name}
                  </p>
                  <div className="flex items-center gap-1.5 mt-1">
                    {hotel.setup_complete ? (
                      <>
                        <Check className="w-3 h-3 text-green-500" />
                        <span className="text-[10px] text-green-600">
                          {t('hotelConfig.configured')}
                        </span>
                      </>
                    ) : (
                      <>
                        <AlertCircle className="w-3 h-3 text-amber-500" />
                        <span className="text-[10px] text-amber-600">
                          {t('hotelConfig.pending')}
                        </span>
                      </>
                    )}
                  </div>
                </button>
              ))}
            </div>

            {/* Form */}
            <div className="flex-1 overflow-y-auto scrollbar-thin p-6 space-y-5">
              {selectedHotel && (
                <>
                  <h3 className="text-base font-semibold text-gray-800">
                    {selectedHotel}
                  </h3>

                  {/* Location */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
                      {t('hotelConfig.location')}
                    </h4>
                    <div className="grid grid-cols-2 gap-3">
                      <Field
                        label={t('hotelConfig.destination')}
                        value={form.destination || ''}
                        onChange={(v) => handleFieldChange('destination', v)}
                        placeholder={t('hotelConfig.destinationPlaceholder')}
                      />
                      <Field
                        label={t('hotelConfig.province')}
                        value={form.province || ''}
                        onChange={(v) => handleFieldChange('province', v)}
                        placeholder={t('hotelConfig.provincePlaceholder')}
                      />
                      <Field
                        label={t('hotelConfig.city')}
                        value={form.city || ''}
                        onChange={(v) => handleFieldChange('city', v)}
                        placeholder={t('hotelConfig.cityPlaceholder')}
                      />
                      <SelectField
                        label={t('hotelConfig.country')}
                        value={form.country || 'ES'}
                        onChange={(v) => handleFieldChange('country', v)}
                        options={COUNTRIES}
                      />
                    </div>
                  </div>

                  {/* Hotel type */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
                      {t('hotelConfig.typology')}
                    </h4>
                    <div className="grid grid-cols-2 gap-3">
                      <SelectField
                        label={t('hotelConfig.type')}
                        value={form.hotel_type || ''}
                        onChange={(v) => handleFieldChange('hotel_type', v)}
                        options={HOTEL_TYPES}
                        placeholder={t('hotelConfig.select')}
                      />
                      <SelectField
                        label={t('hotelConfig.targetClient')}
                        value={form.target_client || ''}
                        onChange={(v) => handleFieldChange('target_client', v)}
                        options={TARGET_CLIENTS}
                        placeholder={t('hotelConfig.select')}
                      />
                      <Field
                        label={t('hotelConfig.rooms')}
                        value={form.total_rooms?.toString() || ''}
                        onChange={(v) =>
                          handleFieldChange(
                            'total_rooms',
                            v ? parseInt(v) : null,
                          )
                        }
                        placeholder={t('hotelConfig.roomsPlaceholder')}
                        type="number"
                      />
                      <SelectField
                        label={t('hotelConfig.currency')}
                        value={form.currency || 'EUR'}
                        onChange={(v) => handleFieldChange('currency', v)}
                        options={CURRENCIES.map((c) => ({
                          value: c,
                          label: c,
                        }))}
                      />
                    </div>
                  </div>

                  {/* Benchmark */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
                      {t('hotelConfig.benchmark')}
                    </h4>
                    <SelectField
                      label={t('hotelConfig.category')}
                      value={form.benchmark_category || ''}
                      onChange={(v) =>
                        handleFieldChange('benchmark_category', v)
                      }
                      options={benchmarkCategories.map((c) => ({
                        value: c,
                        label: c,
                      }))}
                      placeholder={t('hotelConfig.categoryPlaceholder')}
                    />
                    {isSpain ? (
                      <SelectField
                        label={t('hotelConfig.geoZone')}
                        value={
                          form.benchmark_ccaa && form.benchmark_province && form.benchmark_zone
                            ? `${form.benchmark_ccaa} - ${form.benchmark_province} - ${form.benchmark_zone}`
                            : ''
                        }
                        onChange={(v) => handleBenchmarkGeoSelect(v)}
                        options={benchmarkGeo.map((g) => ({
                          value: g.display_label,
                          label: g.display_label,
                        }))}
                        placeholder={t('hotelConfig.geoZonePlaceholder')}
                      />
                    ) : (
                      <div className="grid grid-cols-3 gap-3">
                        <Field
                          label={t('hotelConfig.benchmarkCountry')}
                          value={form.benchmark_country || ''}
                          onChange={(v) =>
                            handleFieldChange('benchmark_country', v)
                          }
                          placeholder={t('hotelConfig.benchmarkCountryPlaceholder')}
                        />
                        <Field
                          label={t('hotelConfig.region')}
                          value={form.benchmark_province || ''}
                          onChange={(v) =>
                            handleFieldChange('benchmark_province', v)
                          }
                          placeholder={t('hotelConfig.regionPlaceholder')}
                        />
                        <Field
                          label={t('hotelConfig.zone')}
                          value={form.benchmark_zone || ''}
                          onChange={(v) =>
                            handleFieldChange('benchmark_zone', v)
                          }
                          placeholder={t('hotelConfig.zonePlaceholder')}
                        />
                      </div>
                    )}
                  </div>

                  {/* Marketing highlights */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">
                      {t('hotelConfig.marketingTitle')}
                    </h4>
                    <div>
                      <label className="text-xs font-medium text-gray-600 block mb-1">
                        {t('hotelConfig.marketingLabel')}
                      </label>
                      <textarea
                        value={form.marketing_highlights || ''}
                        onChange={(e) => handleFieldChange('marketing_highlights', e.target.value)}
                        placeholder={t('hotelConfig.marketingPlaceholder')}
                        rows={3}
                        className="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-400 focus:ring-1 focus:ring-blue-100 transition-colors resize-none"
                      />
                      <p className="text-[10px] text-gray-400 mt-1">
                        {t('hotelConfig.marketingHelp')}
                      </p>
                    </div>
                  </div>

                  {/* Messages */}
                  {success && (
                    <div className="flex items-center gap-2 bg-green-50 text-green-700 text-sm px-4 py-2.5 rounded-xl">
                      <Check className="w-4 h-4 shrink-0" />
                      {success}
                    </div>
                  )}
                  {error && (
                    <div className="flex items-center gap-2 bg-red-50 text-red-700 text-sm px-4 py-2.5 rounded-xl">
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      {error}
                    </div>
                  )}

                  {/* Save button */}
                  <button
                    onClick={handleSave}
                    disabled={saving}
                    className="w-full flex items-center justify-center gap-2 text-white font-medium py-3 rounded-xl transition-all shadow-sm disabled:opacity-50 hover:opacity-90"
                    style={{ backgroundColor: '#060734' }}
                  >
                    {saving ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Save className="w-4 h-4" />
                    )}
                    {saving ? t('hotelConfig.savingBtn') : t('hotelConfig.saveBtn')}
                  </button>
                </>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

/* ---- Reusable field components ---- */

function Field({
  label,
  value,
  onChange,
  placeholder,
  type = 'text',
}: {
  label: string
  value: string
  onChange: (v: string) => void
  placeholder?: string
  type?: string
}) {
  return (
    <div>
      <label className="text-xs font-medium text-gray-600 block mb-1">
        {label}
      </label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-400 focus:ring-1 focus:ring-blue-100 transition-colors"
      />
    </div>
  )
}

function SelectField({
  label,
  value,
  onChange,
  options,
  placeholder,
}: {
  label: string
  value: string
  onChange: (v: string) => void
  options: { value: string; label: string }[]
  placeholder?: string
}) {
  return (
    <div>
      <label className="text-xs font-medium text-gray-600 block mb-1">
        {label}
      </label>
      <div className="relative">
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-400 focus:ring-1 focus:ring-blue-100 appearance-none transition-colors"
        >
          {placeholder && (
            <option value="" disabled>
              {placeholder}
            </option>
          )}
          {options.map((opt) => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </select>
        <ChevronDown className="w-3.5 h-3.5 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
      </div>
    </div>
  )
}
