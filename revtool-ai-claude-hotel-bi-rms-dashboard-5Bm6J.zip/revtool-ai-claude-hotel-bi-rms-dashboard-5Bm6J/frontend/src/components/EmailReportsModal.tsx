import { useState, useEffect } from 'react'
import {
  X, Mail, Loader2, Check, AlertCircle, Building2, Calendar,
  ChevronDown, ChevronUp, Plus, Pencil, Trash2, Send,
} from 'lucide-react'
import { useTranslation } from 'react-i18next'
import * as api from '../services/api'
import type { CustomEmailReport } from '../types'

interface EmailReportsModalProps {
  isOpen: boolean
  onClose: () => void
}

function WeekdaySelector({
  weekdays,
  onToggle,
}: {
  weekdays: number
  onToggle: (dayIndex: number) => void
}) {
  const { t } = useTranslation()
  const labels = t('weekdays.short', { returnObjects: true }) as string[]
  const fullLabels = t('weekdays.long', { returnObjects: true }) as string[]

  return (
    <div className="flex gap-1">
      {labels.map((label: string, i: number) => {
        const active = (weekdays & (1 << i)) !== 0
        return (
          <button
            key={i}
            type="button"
            title={fullLabels[i]}
            onClick={() => onToggle(i)}
            className={`w-7 h-7 rounded-md text-[10px] font-semibold transition-all ${
              active
                ? 'bg-blue-500 text-white shadow-sm'
                : 'bg-slate-100 text-slate-400 hover:bg-slate-200'
            }`}
          >
            {label}
          </button>
        )
      })}
    </div>
  )
}

export default function EmailReportsModal({ isOpen, onClose }: EmailReportsModalProps) {
  const { t } = useTranslation()
  const [reportTypes, setReportTypes] = useState<{ report_type: number; title: string }[]>([])
  const [accessibleHotels, setAccessibleHotels] = useState<string[]>([])
  const [selectedHotels, setSelectedHotels] = useState<Record<string, number[]>>({})
  const [weekdaysPerReport, setWeekdaysPerReport] = useState<Record<string, number>>({})
  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState('')

  // Accordion state
  const [scheduleOpen, setScheduleOpen] = useState(false)

  // Custom reports
  const [customReports, setCustomReports] = useState<CustomEmailReport[]>([])
  const [showCustomForm, setShowCustomForm] = useState(false)
  const [editingCustom, setEditingCustom] = useState<CustomEmailReport | null>(null)
  const [customTitle, setCustomTitle] = useState('')
  const [customPrompt, setCustomPrompt] = useState('')
  const [customWeekdays, setCustomWeekdays] = useState(62)
  const [customHotels, setCustomHotels] = useState<string[]>([])
  const [savingCustom, setSavingCustom] = useState(false)
  const [deletingId, setDeletingId] = useState<number | null>(null)

  // Send now
  const [sendingKey, setSendingKey] = useState<string | null>(null)  // "hotel::rt" or "custom::id::hotel"
  const [sendSuccess, setSendSuccess] = useState<string | null>(null)

  // Use translated titles for preconfigured report types, fall back to backend title
  const getReportTitle = (rt: { report_type: number; title: string }) => {
    const key = `emailReports.reportTitle${rt.report_type}`
    const translated = t(key)
    return translated !== key ? translated : rt.title
  }

  const handleSendNow = async (hotelName: string, reportType?: number, customReportId?: number) => {
    const key = customReportId
      ? `custom::${customReportId}::${hotelName}`
      : `${hotelName}::${reportType}`
    setSendingKey(key)
    setSendSuccess(null)
    setError('')
    try {
      await api.sendReportNow({
        hotel_name: hotelName,
        report_type: reportType,
        custom_report_id: customReportId,
      })
      setSendSuccess(key)
      setTimeout(() => setSendSuccess((prev) => (prev === key ? null : prev)), 4000)
    } catch {
      setError(t('emailReports.errorSendNow'))
    } finally {
      setSendingKey(null)
    }
  }

  useEffect(() => {
    if (!isOpen) return
    setLoading(true)
    setSuccess(false)
    setError('')
    Promise.all([api.getEmailReports(), api.getCustomReports()])
      .then(([data, customData]) => {
        setReportTypes(data.report_types)
        setAccessibleHotels(data.accessible_hotels)
        setSelectedHotels(data.subscribed_hotels)
        setWeekdaysPerReport(data.weekdays_per_report || {})
        setCustomReports(customData.custom_reports)
      })
      .catch(() => setError(t('emailReports.errorLoad')))
      .finally(() => setLoading(false))
  }, [isOpen])

  if (!isOpen) return null

  const toggleHotel = (hotel: string) => {
    setSuccess(false)
    setSelectedHotels((prev) => {
      const copy = { ...prev }
      if (copy[hotel]) {
        delete copy[hotel]
      } else {
        copy[hotel] = reportTypes.map((r) => r.report_type)
      }
      return copy
    })
  }

  const toggleReportType = (hotel: string, rt: number) => {
    setSuccess(false)
    setSelectedHotels((prev) => {
      const copy = { ...prev }
      const current = copy[hotel] || []
      if (current.includes(rt)) {
        const filtered = current.filter((r) => r !== rt)
        if (filtered.length === 0) {
          delete copy[hotel]
        } else {
          copy[hotel] = filtered
        }
      } else {
        copy[hotel] = [...current, rt]
      }
      return copy
    })
  }

  const toggleWeekday = (reportType: number, dayIndex: number) => {
    setSuccess(false)
    const key = String(reportType)
    setWeekdaysPerReport((prev) => ({
      ...prev,
      [key]: (prev[key] ?? 62) ^ (1 << dayIndex),
    }))
  }

  const getReportWeekdays = (rt: number): number => {
    return weekdaysPerReport[String(rt)] ?? 62
  }

  const handleSave = async () => {
    setSaving(true)
    setError('')
    setSuccess(false)
    try {
      const hotels = Object.entries(selectedHotels).map(([hotel_name, report_types]) => ({
        hotel_name,
        report_types,
      }))
      await api.saveEmailReports(hotels, weekdaysPerReport)
      setSuccess(true)
    } catch {
      setError(t('emailReports.errorSave'))
    } finally {
      setSaving(false)
    }
  }

  // Custom report handlers
  const resetCustomForm = () => {
    setShowCustomForm(false)
    setEditingCustom(null)
    setCustomTitle('')
    setCustomPrompt('')
    setCustomWeekdays(62)
    setCustomHotels([])
  }

  const openEditCustom = (cr: CustomEmailReport) => {
    setEditingCustom(cr)
    setCustomTitle(cr.title)
    setCustomPrompt(cr.prompt)
    setCustomWeekdays(cr.weekdays)
    setCustomHotels(cr.hotel_names)
    setShowCustomForm(true)
  }

  const toggleCustomHotel = (hotel: string) => {
    setCustomHotels((prev) =>
      prev.includes(hotel) ? prev.filter((h) => h !== hotel) : [...prev, hotel],
    )
  }

  const handleSaveCustom = async () => {
    if (!customTitle.trim() || !customPrompt.trim()) return
    setSavingCustom(true)
    setError('')
    try {
      const data = {
        title: customTitle.trim(),
        prompt: customPrompt.trim(),
        weekdays: customWeekdays,
        hotel_names: customHotels,
      }
      if (editingCustom) {
        await api.updateCustomReport(editingCustom.id, data)
      } else {
        await api.createCustomReport(data)
      }
      // Reload custom reports
      const customData = await api.getCustomReports()
      setCustomReports(customData.custom_reports)
      resetCustomForm()
    } catch {
      setError(t('emailReports.errorSaveCustom'))
    } finally {
      setSavingCustom(false)
    }
  }

  const handleDeleteCustom = async (id: number) => {
    setDeletingId(id)
    setError('')
    try {
      await api.deleteCustomReport(id)
      setCustomReports((prev) => prev.filter((cr) => cr.id !== id))
    } catch {
      setError(t('emailReports.errorDelete'))
    } finally {
      setDeletingId(null)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/40 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg animate-slide-up overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 flex items-center justify-between shrink-0" style={{ backgroundColor: '#060734' }}>
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-blue-500/20 rounded-lg flex items-center justify-center">
              <Mail className="w-4 h-4 text-blue-400" />
            </div>
            <h2 className="text-white font-semibold text-sm">
              {t('emailReports.title')}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto flex-1">
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
            </div>
          ) : (
            <>
              {/* Collapsible: Días de envío por informe */}
              <div className="mb-6">
                <button
                  type="button"
                  onClick={() => setScheduleOpen(!scheduleOpen)}
                  className="w-full flex items-center justify-between gap-2 mb-1 group"
                >
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-slate-500" />
                    <h3 className="text-sm font-semibold text-slate-700">{t('emailReports.scheduleTitle')}</h3>
                  </div>
                  {scheduleOpen
                    ? <ChevronUp className="w-4 h-4 text-slate-400 group-hover:text-slate-600" />
                    : <ChevronDown className="w-4 h-4 text-slate-400 group-hover:text-slate-600" />
                  }
                </button>
                <p className="text-xs text-slate-500 mb-3">
                  {t('emailReports.scheduleDesc')}
                </p>

                {scheduleOpen && (
                  <div className="space-y-3">
                    {/* Fixed report types */}
                    {reportTypes.map((rt) => {
                      const wd = getReportWeekdays(rt.report_type)
                      return (
                        <div
                          key={rt.report_type}
                          className="border border-slate-200 rounded-lg p-3"
                        >
                          <p className="text-xs font-semibold text-slate-700 mb-1.5">{getReportTitle(rt)}</p>
                          <WeekdaySelector
                            weekdays={wd}
                            onToggle={(i) => toggleWeekday(rt.report_type, i)}
                          />
                          {wd === 0 && (
                            <p className="text-[10px] text-amber-600 mt-1">{t('emailReports.reportNotSent')}</p>
                          )}
                        </div>
                      )
                    })}

                    {/* Custom reports */}
                    {customReports.map((cr) => (
                      <div
                        key={`custom-${cr.id}`}
                        className="border border-emerald-200 bg-emerald-50/30 rounded-lg p-3"
                      >
                        <div className="flex items-center justify-between mb-1.5">
                          <p className="text-xs font-semibold text-slate-700">{cr.title}</p>
                          <div className="flex items-center gap-1">
                            {cr.hotel_names.length > 0 && (() => {
                              const isSending = cr.hotel_names.some((h) => sendingKey === `custom::${cr.id}::${h}`)
                              const isSent = cr.hotel_names.some((h) => sendSuccess === `custom::${cr.id}::${h}`)
                              return (
                                <button
                                  type="button"
                                  onClick={() => {
                                    cr.hotel_names.forEach((h) => handleSendNow(h, undefined, cr.id))
                                  }}
                                  disabled={isSending}
                                  className="p-1 text-slate-400 hover:text-blue-500 transition-colors disabled:opacity-50"
                                  title={t('emailReports.sendNow')}
                                >
                                  {isSending
                                    ? <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                    : isSent
                                      ? <Check className="w-3.5 h-3.5 text-green-500" />
                                      : <Send className="w-3.5 h-3.5" />
                                  }
                                </button>
                              )
                            })()}
                            <button
                              type="button"
                              onClick={() => openEditCustom(cr)}
                              className="p-1 text-slate-400 hover:text-blue-500 transition-colors"
                              title={t('emailReports.edit')}
                            >
                              <Pencil className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleDeleteCustom(cr.id)}
                              disabled={deletingId === cr.id}
                              className="p-1 text-slate-400 hover:text-red-500 transition-colors disabled:opacity-50"
                              title={t('emailReports.delete')}
                            >
                              {deletingId === cr.id
                                ? <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                : <Trash2 className="w-3.5 h-3.5" />
                              }
                            </button>
                          </div>
                        </div>
                        <p className="text-[10px] text-slate-500 mb-1.5 line-clamp-2">{cr.prompt}</p>
                        <WeekdaySelector
                          weekdays={cr.weekdays}
                          onToggle={() => openEditCustom(cr)}
                        />
                        {cr.hotel_names.length > 0 && (
                          <p className="text-[10px] text-slate-400 mt-1.5">
                            {t('emailReports.hotels')}: {cr.hotel_names.join(', ')}
                          </p>
                        )}
                      </div>
                    ))}

                    {/* Create custom report button / form */}
                    {!showCustomForm ? (
                      <button
                        type="button"
                        onClick={() => {
                          resetCustomForm()
                          setShowCustomForm(true)
                        }}
                        className="w-full border border-dashed border-slate-300 rounded-lg p-3 flex items-center justify-center gap-2 text-xs text-slate-500 hover:border-blue-400 hover:text-blue-500 transition-colors"
                      >
                        <Plus className="w-4 h-4" />
                        {t('emailReports.createCustom')}
                      </button>
                    ) : (
                      <div className="border border-blue-300 bg-blue-50/30 rounded-lg p-3 space-y-3">
                        <div className="flex items-center justify-between">
                          <p className="text-xs font-semibold text-slate-700">
                            {editingCustom ? t('emailReports.editReport') : t('emailReports.newCustomReport')}
                          </p>
                          <button
                            type="button"
                            onClick={resetCustomForm}
                            className="text-slate-400 hover:text-slate-600 transition-colors"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>

                        <div>
                          <label className="text-[10px] font-medium text-slate-600 mb-1 block">
                            {t('emailReports.titleLabel')}
                          </label>
                          <input
                            type="text"
                            maxLength={100}
                            value={customTitle}
                            onChange={(e) => setCustomTitle(e.target.value)}
                            placeholder={t('emailReports.titlePlaceholder')}
                            className="w-full border border-slate-300 rounded-md px-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] font-medium text-slate-600 mb-1 block">
                            {t('emailReports.promptLabel')}
                          </label>
                          <textarea
                            maxLength={4000}
                            value={customPrompt}
                            onChange={(e) => setCustomPrompt(e.target.value)}
                            placeholder={t('emailReports.promptPlaceholder')}
                            rows={3}
                            className="w-full border border-slate-300 rounded-md px-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent resize-none"
                          />
                          <p className="text-[10px] text-slate-400 mt-0.5 text-right">
                            {customPrompt.length}/4000
                          </p>
                        </div>

                        <div>
                          <label className="text-[10px] font-medium text-slate-600 mb-1 block">
                            {t('emailReports.sendDays')}
                          </label>
                          <WeekdaySelector
                            weekdays={customWeekdays}
                            onToggle={(i) => setCustomWeekdays((prev) => prev ^ (1 << i))}
                          />
                        </div>

                        <div>
                          <label className="text-[10px] font-medium text-slate-600 mb-1 block">
                            {t('emailReports.hotels')}
                          </label>
                          <div className="flex flex-wrap gap-1.5">
                            {accessibleHotels.map((hotel) => {
                              const selected = customHotels.includes(hotel)
                              return (
                                <button
                                  key={hotel}
                                  type="button"
                                  onClick={() => toggleCustomHotel(hotel)}
                                  className={`px-2.5 py-1 rounded-full text-[10px] font-medium transition-all ${
                                    selected
                                      ? 'bg-blue-500 text-white'
                                      : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                                  }`}
                                >
                                  {hotel}
                                </button>
                              )
                            })}
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={handleSaveCustom}
                          disabled={savingCustom || !customTitle.trim() || !customPrompt.trim() || customHotels.length === 0}
                          className="w-full py-2 bg-blue-600 text-white text-xs font-medium rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
                        >
                          {savingCustom ? (
                            <>
                              <Loader2 className="w-3.5 h-3.5 animate-spin" />
                              {t('emailReports.saving')}
                            </>
                          ) : (
                            editingCustom ? t('emailReports.saveChanges') : t('emailReports.createReport')
                          )}
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Hotel selector */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <Building2 className="w-4 h-4 text-slate-500" />
                  <h3 className="text-sm font-semibold text-slate-700">{t('emailReports.hotelsAndReports')}</h3>
                </div>
                <p className="text-xs text-slate-500 mb-3">
                  {t('emailReports.hotelsAndReportsDesc')}
                </p>

                <div className="space-y-2">
                  {accessibleHotels.map((hotel) => {
                    const isSelected = !!selectedHotels[hotel]
                    const hotelReports = selectedHotels[hotel] || []

                    return (
                      <div
                        key={hotel}
                        className={`border rounded-xl transition-colors ${
                          isSelected
                            ? 'border-blue-300 bg-blue-50/50'
                            : 'border-slate-200 bg-white'
                        }`}
                      >
                        {/* Hotel toggle */}
                        <div
                          className="flex items-center justify-between p-3 cursor-pointer"
                          onClick={() => toggleHotel(hotel)}
                        >
                          <span className={`text-sm font-medium ${
                            isSelected ? 'text-slate-900' : 'text-slate-600'
                          }`}>
                            {hotel}
                          </span>
                          <div
                            className={`relative w-10 h-6 rounded-full transition-colors shrink-0 ${
                              isSelected ? 'bg-blue-500' : 'bg-slate-300'
                            }`}
                          >
                            <div
                              className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-transform ${
                                isSelected ? 'translate-x-5' : 'translate-x-1'
                              }`}
                            />
                          </div>
                        </div>

                        {/* Report type toggles (expanded when hotel is selected) */}
                        {isSelected && (
                          <div className="px-3 pb-3 space-y-1.5 border-t border-blue-200/60 pt-2">
                            {reportTypes.map((rt) => {
                              const rtActive = hotelReports.includes(rt.report_type)
                              const sendKey = `${hotel}::${rt.report_type}`
                              return (
                                <div
                                  key={rt.report_type}
                                  className={`flex items-center gap-3 p-2 rounded-lg transition-colors ${
                                    rtActive ? 'bg-blue-100/60' : 'hover:bg-slate-50'
                                  }`}
                                >
                                  <div
                                    className="flex items-center gap-3 flex-1 min-w-0 cursor-pointer"
                                    onClick={() => toggleReportType(hotel, rt.report_type)}
                                  >
                                    <div className={`w-4 h-4 rounded border-2 flex items-center justify-center shrink-0 transition-colors ${
                                      rtActive
                                        ? 'bg-blue-500 border-blue-500'
                                        : 'border-slate-300 bg-white'
                                    }`}>
                                      {rtActive && <Check className="w-3 h-3 text-white" />}
                                    </div>
                                    <div className="min-w-0">
                                      <p className="text-xs font-medium text-slate-800">{getReportTitle(rt)}</p>
                                      <p className="text-[10px] text-slate-500 leading-tight">
                                        {t(`emailReports.reportDesc${rt.report_type}`)}
                                      </p>
                                    </div>
                                  </div>
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation()
                                      handleSendNow(hotel, rt.report_type)
                                    }}
                                    disabled={sendingKey === sendKey}
                                    className="p-1.5 rounded-md text-slate-400 hover:text-blue-500 hover:bg-blue-50 transition-colors disabled:opacity-50 shrink-0"
                                    title={`${t('emailReports.sendNow')}: ${getReportTitle(rt)}`}
                                  >
                                    {sendingKey === sendKey
                                      ? <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                      : sendSuccess === sendKey
                                        ? <Check className="w-3.5 h-3.5 text-green-500" />
                                        : <Send className="w-3.5 h-3.5" />
                                    }
                                  </button>
                                </div>
                              )
                            })}
                          </div>
                        )}
                      </div>
                    )
                  })}
                </div>

                {accessibleHotels.length === 0 && (
                  <p className="text-xs text-slate-400 text-center py-4">
                    {t('emailReports.noHotels')}
                  </p>
                )}
              </div>
            </>
          )}

          {/* Success/Error */}
          {sendSuccess && (
            <div className="mt-4 flex items-center gap-2 text-blue-600 text-xs">
              <Send className="w-4 h-4" />
              {t('emailReports.sendQueued')}
            </div>
          )}
          {success && (
            <div className="mt-4 flex items-center gap-2 text-green-600 text-xs">
              <Check className="w-4 h-4" />
              {t('emailReports.preferencesSaved')}
            </div>
          )}
          {error && (
            <div className="mt-4 flex items-center gap-2 text-red-600 text-xs">
              <AlertCircle className="w-4 h-4" />
              {error}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-slate-200 px-6 py-4 shrink-0">
          <button
            onClick={handleSave}
            disabled={saving || loading}
            className="w-full py-2.5 text-white text-sm font-medium rounded-lg
              disabled:opacity-50 disabled:cursor-not-allowed
              transition-colors flex items-center justify-center gap-2"
            style={{ backgroundColor: '#060734' }}
          >
            {saving ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                {t('emailReports.saving')}
              </>
            ) : (
              t('emailReports.savePreferences')
            )}
          </button>
        </div>
      </div>
    </div>
  )
}
