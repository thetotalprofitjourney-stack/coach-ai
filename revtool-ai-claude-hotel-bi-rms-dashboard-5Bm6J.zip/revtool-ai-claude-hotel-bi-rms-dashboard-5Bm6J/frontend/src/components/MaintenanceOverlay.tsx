import { RefreshCw } from 'lucide-react'
import { useTranslation } from 'react-i18next'

export default function MaintenanceOverlay() {
  const { t } = useTranslation()

  return (
    <div className="absolute inset-0 bg-white/80 backdrop-blur-sm flex items-center justify-center z-30 animate-fade-in">
      <div className="text-center max-w-sm px-6">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-50 rounded-2xl mb-4">
          <RefreshCw className="w-8 h-8 text-blue-500 animate-spin" />
        </div>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">
          {t('maintenance.title')}
        </h3>
        <p className="text-sm text-gray-500 leading-relaxed">
          {t('maintenance.desc')}
        </p>
      </div>
    </div>
  )
}
