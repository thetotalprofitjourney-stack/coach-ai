import { useState, useEffect } from 'react'
import {
  X,
  Building2,
  Check,
  AlertCircle,
  ChevronDown,
  Loader2,
  Save,
} from 'lucide-react'
import { useTranslation } from 'react-i18next'
import { useSession } from '../contexts/SessionContext'
import * as api from '../services/api'
import type { BillingProfileForm } from '../types'

interface BillingProfileModalProps {
  isOpen: boolean
  onClose: () => void
  isOnboarding?: boolean
}

const COUNTRIES = [
  'España',
  'Portugal',
  'Francia',
  'Italia',
  'Alemania',
  'Reino Unido',
  'Irlanda',
  'Países Bajos',
  'Bélgica',
  'Suiza',
  'Austria',
  'Grecia',
  'Estados Unidos',
  'México',
  'República Dominicana',
  'Colombia',
  'Argentina',
  'Chile',
]

const SPAIN_PROVINCES = [
  'A Coruña',
  'Álava',
  'Albacete',
  'Alicante',
  'Almería',
  'Asturias',
  'Ávila',
  'Badajoz',
  'Barcelona',
  'Bizkaia',
  'Burgos',
  'Cáceres',
  'Cádiz',
  'Cantabria',
  'Castellón',
  'Ceuta',
  'Ciudad Real',
  'Córdoba',
  'Cuenca',
  'Gipuzkoa',
  'Girona',
  'Granada',
  'Guadalajara',
  'Huelva',
  'Huesca',
  'Illes Balears',
  'Jaén',
  'La Rioja',
  'Las Palmas',
  'León',
  'Lleida',
  'Lugo',
  'Madrid',
  'Málaga',
  'Melilla',
  'Murcia',
  'Navarra',
  'Ourense',
  'Palencia',
  'Pontevedra',
  'Salamanca',
  'Santa Cruz de Tenerife',
  'Segovia',
  'Sevilla',
  'Soria',
  'Tarragona',
  'Teruel',
  'Toledo',
  'Valencia',
  'Valladolid',
  'Zamora',
  'Zaragoza',
]

const IVA_EXEMPT_PROVINCES = [
  'Las Palmas',
  'Santa Cruz de Tenerife',
  'Ceuta',
  'Melilla',
]

const EMPTY_FORM: BillingProfileForm = {
  company_name: '',
  tax_id: '',
  notification_email: '',
  address_line: '',
  city: '',
  province: '',
  postal_code: '',
  country: 'España',
}

export default function BillingProfileModal({
  isOpen,
  onClose,
  isOnboarding = false,
}: BillingProfileModalProps) {
  const { session, refreshSession } = useSession()
  const { t } = useTranslation()
  const [form, setForm] = useState<BillingProfileForm>(EMPTY_FORM)
  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [success, setSuccess] = useState('')
  const [error, setError] = useState('')

  useEffect(() => {
    if (!isOpen) return

    const loadProfile = async () => {
      setLoading(true)
      try {
        const profile = await api.getBillingProfile()
        setForm({
          company_name: profile.company_name,
          tax_id: profile.tax_id,
          notification_email: profile.notification_email,
          address_line: profile.address_line,
          city: profile.city,
          province: profile.province,
          postal_code: profile.postal_code || '',
          country: profile.country,
        })
      } catch {
        // 404 = no profile yet, use empty form
        setForm(EMPTY_FORM)
      } finally {
        setLoading(false)
      }
    }

    loadProfile()
  }, [isOpen])

  if (!isOpen) return null

  const isSpain = form.country === 'España'
  const vatApplies =
    isSpain && !IVA_EXEMPT_PROVINCES.includes(form.province)

  const handleFieldChange = (field: keyof BillingProfileForm, value: string) => {
    setForm((prev) => {
      const updated = { ...prev, [field]: value }
      // Reset province when country changes
      if (field === 'country') {
        updated.province = ''
      }
      return updated
    })
    setSuccess('')
    setError('')
  }

  const handleSave = async () => {
    // Validate required fields
    if (
      !form.company_name.trim() ||
      !form.tax_id.trim() ||
      !form.notification_email.trim() ||
      !form.address_line.trim() ||
      !form.city.trim() ||
      !form.province.trim() ||
      !form.country.trim()
    ) {
      setError(t('billing.requiredFields'))
      return
    }

    setSaving(true)
    setError('')
    setSuccess('')

    try {
      await api.saveBillingProfile(form)
      setSuccess(t('billing.savedOk'))
      await refreshSession()
      if (isOnboarding) {
        setTimeout(onClose, 1000)
      }
    } catch (err: any) {
      setError(err.message || t('billing.errorSave'))
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-black/40 backdrop-blur-sm"
        onClick={isOnboarding ? undefined : onClose}
      />

      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] flex flex-col animate-slide-up overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 flex items-center justify-between shrink-0" style={{ backgroundColor: '#060734' }}>
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/10 rounded-xl">
              <Building2 className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-white font-semibold">
                {isOnboarding
                  ? t('billing.setupTitle')
                  : t('billing.title')}
              </h2>
              <p className="text-slate-400 text-xs">
                {isOnboarding
                  ? t('billing.setupSubtitle')
                  : t('billing.subtitle')}
              </p>
            </div>
          </div>
          {!isOnboarding && (
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto scrollbar-thin p-6 space-y-4">
            {/* UPN (read-only) */}
            <div>
              <label className="text-xs font-medium text-gray-600 block mb-1">
                {t('billing.userLabel')}
              </label>
              <input
                type="text"
                value={session?.upn || ''}
                disabled
                className="w-full bg-gray-100 border border-gray-200 rounded-lg px-3 py-2 text-sm text-gray-500 cursor-not-allowed"
              />
            </div>

            {/* Company name */}
            <div>
              <label className="text-xs font-medium text-gray-600 block mb-1">
                {t('billing.companyName')}
              </label>
              <input
                type="text"
                value={form.company_name}
                onChange={(e) =>
                  handleFieldChange('company_name', e.target.value)
                }
                placeholder={t('billing.companyPlaceholder')}
                className="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-400 focus:ring-1 focus:ring-blue-100 transition-colors"
              />
            </div>

            {/* Tax ID */}
            <div>
              <label className="text-xs font-medium text-gray-600 block mb-1">
                {t('billing.taxId')}
              </label>
              <input
                type="text"
                value={form.tax_id}
                onChange={(e) => handleFieldChange('tax_id', e.target.value)}
                placeholder={t('billing.taxIdPlaceholder')}
                className="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-400 focus:ring-1 focus:ring-blue-100 transition-colors"
              />
            </div>

            {/* Notification email */}
            <div>
              <label className="text-xs font-medium text-gray-600 block mb-1">
                {t('billing.notificationEmail')}
              </label>
              <input
                type="email"
                value={form.notification_email}
                onChange={(e) =>
                  handleFieldChange('notification_email', e.target.value)
                }
                placeholder={t('billing.notificationEmailPlaceholder')}
                className="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-400 focus:ring-1 focus:ring-blue-100 transition-colors"
              />
              <p className="text-[10px] text-gray-400 mt-1">
                {t('billing.notificationEmailHelp')}
              </p>
            </div>

            {/* Address */}
            <div>
              <label className="text-xs font-medium text-gray-600 block mb-1">
                {t('billing.address')}
              </label>
              <input
                type="text"
                value={form.address_line}
                onChange={(e) =>
                  handleFieldChange('address_line', e.target.value)
                }
                placeholder={t('billing.addressPlaceholder')}
                className="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-400 focus:ring-1 focus:ring-blue-100 transition-colors"
              />
            </div>

            {/* Country + Province */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-medium text-gray-600 block mb-1">
                  {t('billing.country')}
                </label>
                <div className="relative">
                  <select
                    value={form.country}
                    onChange={(e) =>
                      handleFieldChange('country', e.target.value)
                    }
                    className="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-400 focus:ring-1 focus:ring-blue-100 appearance-none transition-colors"
                  >
                    <option value="" disabled>
                      {t('billing.select')}
                    </option>
                    {COUNTRIES.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="w-3.5 h-3.5 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                </div>
              </div>

              <div>
                <label className="text-xs font-medium text-gray-600 block mb-1">
                  {t('billing.province')}
                </label>
                {isSpain ? (
                  <div className="relative">
                    <select
                      value={form.province}
                      onChange={(e) =>
                        handleFieldChange('province', e.target.value)
                      }
                      className="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-400 focus:ring-1 focus:ring-blue-100 appearance-none transition-colors"
                    >
                      <option value="" disabled>
                        {t('billing.select')}
                      </option>
                      {SPAIN_PROVINCES.map((p) => (
                        <option key={p} value={p}>
                          {p}
                        </option>
                      ))}
                    </select>
                    <ChevronDown className="w-3.5 h-3.5 text-gray-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  </div>
                ) : (
                  <input
                    type="text"
                    value={form.province}
                    onChange={(e) =>
                      handleFieldChange('province', e.target.value)
                    }
                    placeholder="Ej: Lisboa"
                    className="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-400 focus:ring-1 focus:ring-blue-100 transition-colors"
                  />
                )}
              </div>
            </div>

            {/* City + Postal code */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-medium text-gray-600 block mb-1">
                  {t('billing.city')}
                </label>
                <input
                  type="text"
                  value={form.city}
                  onChange={(e) => handleFieldChange('city', e.target.value)}
                  placeholder="Ej: Madrid"
                  className="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-400 focus:ring-1 focus:ring-blue-100 transition-colors"
                />
              </div>
              <div>
                <label className="text-xs font-medium text-gray-600 block mb-1">
                  {t('billing.postalCode')}
                </label>
                <input
                  type="text"
                  value={form.postal_code}
                  onChange={(e) =>
                    handleFieldChange('postal_code', e.target.value)
                  }
                  placeholder="Ej: 28001"
                  className="w-full bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 text-sm text-gray-800 outline-none focus:border-blue-400 focus:ring-1 focus:ring-blue-100 transition-colors"
                />
              </div>
            </div>

            {/* VAT info box */}
            <div
              className={`rounded-xl px-4 py-3 text-sm ${
                vatApplies
                  ? 'bg-blue-50 text-blue-700 border border-blue-200'
                  : 'bg-green-50 text-green-700 border border-green-200'
              }`}
            >
              {vatApplies ? (
                <p dangerouslySetInnerHTML={{ __html: t('billing.vatApplies') }} />
              ) : form.country ? (
                <p dangerouslySetInnerHTML={{ __html: t('billing.vatExempt') }} />
              ) : null}
            </div>

            {/* Messages */}
            {success && (
              <div className="flex items-center gap-2 bg-green-50 text-green-700 text-sm px-4 py-2.5 rounded-xl">
                <Check className="w-4 h-4 shrink-0" />
                {success}
              </div>
            )}
            {error && (
              <div className="flex items-center gap-2 bg-red-50 text-red-700 text-sm px-4 py-2.5 rounded-xl">
                <AlertCircle className="w-4 h-4 shrink-0" />
                {error}
              </div>
            )}

            {/* Save button */}
            <button
              onClick={handleSave}
              disabled={saving}
              className="w-full flex items-center justify-center gap-2 text-white font-medium py-3 rounded-xl transition-all shadow-sm disabled:opacity-50 hover:opacity-90"
              style={{ backgroundColor: '#060734' }}
            >
              {saving ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Save className="w-4 h-4" />
              )}
              {saving ? t('billing.savingBtn') : t('billing.saveBtn')}
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
