import { useState, useRef, useEffect } from 'react'
import { Send, Mic, Square } from 'lucide-react'
import { useTranslation } from 'react-i18next'
import useVoiceInput from '../hooks/useVoiceInput'

interface ChatInputProps {
  onSend: (message: string) => void
  disabled: boolean
  isLoading: boolean
}

export default function ChatInput({
  onSend,
  disabled,
  isLoading,
}: ChatInputProps) {
  const [message, setMessage] = useState('')
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const { t } = useTranslation()

  const { isListening, isSupported, startListening, stopListening } =
    useVoiceInput((transcript) => {
      // When transcription is ready, put it in the input
      setMessage((prev: string) => {
        const combined = prev ? `${prev} ${transcript}` : transcript
        return combined
      })
      // Focus the textarea so the user can review/edit before sending
      setTimeout(() => textareaRef.current?.focus(), 50)
    })

  // Auto-resize textarea
  useEffect(() => {
    const el = textareaRef.current
    if (!el) return
    el.style.height = 'auto'
    el.style.height = Math.min(el.scrollHeight, 160) + 'px'
  }, [message])

  const handleSubmit = () => {
    const trimmed = message.trim()
    if (!trimmed || disabled || isLoading) return
    onSend(trimmed)
    setMessage('')
    // Reset height
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto'
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      handleSubmit()
    }
  }

  const handleMicClick = () => {
    if (isListening) {
      stopListening()
    } else {
      startListening()
    }
  }

  return (
    <div className="border-t border-gray-200 bg-white px-3 sm:px-4 py-2 sm:py-3 shrink-0">
      <div className="max-w-4xl mx-auto">
        <div
          className={`flex items-end gap-2 bg-gray-50 border rounded-xl sm:rounded-2xl px-2 sm:px-3 py-1.5 sm:py-2 transition-colors ${
            isListening
              ? 'border-red-400 ring-2 ring-red-100'
              : disabled
                ? 'border-gray-200 opacity-60'
                : 'border-gray-300 focus-within:border-blue-400 focus-within:ring-2 focus-within:ring-blue-100'
          }`}
        >
          {/* Mic button — only shown if browser supports Web Speech API */}
          {isSupported && (
            <button
              onClick={handleMicClick}
              disabled={disabled}
              className={`p-1.5 rounded-lg transition-all shrink-0 mb-0.5 ${
                isListening
                  ? 'bg-red-100 text-red-600 hover:bg-red-200 animate-pulse'
                  : 'text-gray-400 hover:text-gray-600 hover:bg-gray-200'
              }`}
              title={isListening ? t('chat.stopRecording') : t('chat.voiceMessage')}
            >
              {isListening ? (
                <Square className="w-4 h-4" />
              ) : (
                <Mic className="w-4 h-4" />
              )}
            </button>
          )}

          {/* Text input */}
          <textarea
            ref={textareaRef}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={
              isListening
                ? t('chat.placeholderListening')
                : disabled
                  ? t('chat.placeholderDisabled')
                  : t('chat.placeholder')
            }
            disabled={disabled}
            rows={1}
            className="flex-1 bg-transparent border-none outline-none resize-none text-sm text-gray-800 placeholder-gray-400 py-1 max-h-40 scrollbar-thin"
          />

          {/* Send button */}
          <button
            onClick={handleSubmit}
            disabled={!message.trim() || disabled || isLoading}
            className={`p-2 rounded-xl shrink-0 mb-0.5 transition-all ${
              message.trim() && !disabled && !isLoading
                ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-sm'
                : 'bg-gray-200 text-gray-400 cursor-not-allowed'
            }`}
          >
            <Send className="w-4 h-4" />
          </button>
        </div>

        <p className="text-[10px] text-gray-400 text-center mt-2">
          {t('chat.disclaimer')}
        </p>
      </div>
    </div>
  )
}
