import { useMsal } from '@azure/msal-react'
import { Building2, Mail, Settings, LogOut } from 'lucide-react'
import { useTranslation } from 'react-i18next'
import { useSession } from '../contexts/SessionContext'
import HotelSelector from './HotelSelector'
import BalanceDisplay from './BalanceDisplay'
import LanguageSelector from './LanguageSelector'

interface HeaderProps {
  onOpenConfig: () => void
  onOpenTopup: () => void
  onOpenBillingProfile: () => void
  onOpenEmailReports: () => void
}

export default function Header({ onOpenConfig, onOpenTopup, onOpenBillingProfile, onOpenEmailReports }: HeaderProps) {
  const { instance } = useMsal()
  const { session, changeLanguage } = useSession()
  const { t } = useTranslation()

  const handleLogout = () => {
    instance.logoutRedirect()
  }

  const upnDisplay = session?.upn?.split('@')[0] || ''

  return (
    <header className="border-b border-slate-700/50 shadow-lg relative z-30 shrink-0" style={{ backgroundColor: '#060734' }}>
      {/* Main header bar */}
      <div className="px-3 sm:px-4 lg:px-6">
        <div className="flex items-center justify-between h-12 sm:h-14 lg:h-16 gap-2 sm:gap-4">
          {/* Logo */}
          <div className="flex items-center gap-3 shrink-0">
            <img src="/revtool-logo.png" alt="Revtool AI" className="w-8 h-8 rounded-lg" />
            <div className="hidden sm:block">
              <h1 className="text-white font-semibold text-sm leading-none">
                Revtool <span className="text-blue-400">AI</span>
              </h1>
              <p className="text-slate-500 text-[10px] mt-0.5">{upnDisplay}</p>
            </div>
          </div>

          {/* Hotel Selector — desktop inline */}
          <div className="hidden lg:flex flex-1 min-w-0 justify-center px-4">
            <HotelSelector />
          </div>

          {/* Right side */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Email reports button */}
            <button
              onClick={onOpenEmailReports}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
              title={t('header.emailReports')}
            >
              <Mail className="w-4 h-4" />
            </button>

            {/* Billing profile button */}
            <button
              onClick={onOpenBillingProfile}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
              title={t('header.billingProfile')}
            >
              <Settings className="w-4 h-4" />
            </button>

            {/* Config button */}
            <button
              onClick={onOpenConfig}
              className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
              title={t('header.configHotels')}
            >
              <Building2 className="w-4 h-4" />
            </button>

            {/* Balance — desktop inline */}
            <div className="hidden lg:block">
              <BalanceDisplay onRecharge={onOpenTopup} />
            </div>

            {/* Language selector */}
            <LanguageSelector onChange={changeLanguage} />

            {/* Logout */}
            <button
              onClick={handleLogout}
              className="p-2 text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded-lg transition-colors"
              title={t('header.logout')}
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Mobile/tablet bar — always visible below lg */}
      <div className="lg:hidden border-t border-slate-700/50 px-3 sm:px-4 py-2 flex items-center gap-3">
        <div className="flex-1 min-w-0">
          <HotelSelector />
        </div>
        <div className="shrink-0">
          <BalanceDisplay onRecharge={onOpenTopup} />
        </div>
      </div>
    </header>
  )
}
