import { IPublicClientApplication } from '@azure/msal-browser'
import { API_BASE_URL } from '../config/api'
import type {
  SessionInfo,
  ChatResponse,
  CreditBalance,
  HotelConfig,
  BenchmarkGeo,
  BillingProfile,
  BillingProfileForm,
  EmailReportsConfig,
  CustomEmailReport,
  PersistedMessage,
} from '../types'

let msalInstance: IPublicClientApplication | null = null

export function setMsalInstance(instance: IPublicClientApplication) {
  msalInstance = instance
}

async function getToken(): Promise<string> {
  if (!msalInstance) throw new Error('MSAL not initialized')

  const accounts = msalInstance.getAllAccounts()
  if (accounts.length === 0) throw new Error('No authenticated account')

  try {
    const result = await msalInstance.acquireTokenSilent({
      scopes: ['openid', 'profile', 'email'],
      account: accounts[0],
    })
    return result.idToken
  } catch {
    const result = await msalInstance.acquireTokenPopup({
      scopes: ['openid', 'profile', 'email'],
    })
    return result.idToken
  }
}

async function request<T>(
  path: string,
  options: RequestInit = {},
): Promise<T> {
  const token = await getToken()

  const response = await fetch(`${API_BASE_URL}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
      ...options.headers,
    },
  })

  if (!response.ok) {
    const body = await response.json().catch(() => ({}))
    const error = new Error(body.detail || `HTTP ${response.status}`) as Error & {
      status: number
    }
    error.status = response.status
    throw error
  }

  return response.json()
}

// --- Session ---
export async function getSession(): Promise<SessionInfo> {
  return request('/api/session')
}

// --- Language preference ---
export async function updateLanguage(language: string): Promise<{ status: string; language: string }> {
  return request('/api/user/language', {
    method: 'PATCH',
    body: JSON.stringify({ language }),
  })
}

// --- Chat (streaming ndjson) ---
export interface StreamCallbacks {
  onStatus: (message: string) => void
  onDelta: (text: string) => void
  onResult: (result: ChatResponse) => void
  onError: (error: { status?: number; message: string }) => void
}

export async function sendMessageStream(
  question: string,
  selectedHotels: string[],
  callbacks: StreamCallbacks,
): Promise<void> {
  const token = await getToken()

  const response = await fetch(`${API_BASE_URL}/api/chat`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({
      question,
      selected_hotel_names: selectedHotels,
    }),
  })

  // Pre-flight errors (401, 402, 403) come as regular HTTP responses
  if (!response.ok) {
    const body = await response.json().catch(() => ({}))
    callbacks.onError({
      status: response.status,
      message: body.detail || `HTTP ${response.status}`,
    })
    return
  }

  // Stream ndjson events
  const reader = response.body!.getReader()
  const decoder = new TextDecoder()
  let buffer = ''
  let receivedResult = false
  let receivedError = false

  while (true) {
    const { done, value } = await reader.read()
    if (done) break

    buffer += decoder.decode(value, { stream: true })
    const lines = buffer.split('\n')
    buffer = lines.pop()! // Keep incomplete line in buffer

    for (const line of lines) {
      if (!line.trim()) continue
      try {
        const event = JSON.parse(line)
        switch (event.type) {
          case 'status':
            callbacks.onStatus(event.message)
            break
          case 'delta':
            callbacks.onDelta(event.text)
            break
          case 'result':
            receivedResult = true
            callbacks.onResult(event)
            break
          case 'error':
            receivedError = true
            callbacks.onError(event)
            break
        }
      } catch {
        // Skip malformed lines
      }
    }
  }

  // Process any remaining buffer
  if (buffer.trim()) {
    try {
      const event = JSON.parse(buffer)
      switch (event.type) {
        case 'status':
          callbacks.onStatus(event.message)
          break
        case 'delta':
          callbacks.onDelta(event.text)
          break
        case 'result':
          receivedResult = true
          callbacks.onResult(event)
          break
        case 'error':
          receivedError = true
          callbacks.onError(event)
          break
      }
    } catch {
      // Skip malformed trailing data
    }
  }

  // Detect premature stream end (server disconnected without sending result or error)
  if (!receivedResult && !receivedError) {
    callbacks.onError({
      status: 502,
      message: 'Connection lost. Please try again.',
    })
  }
}

// --- Credits ---
export async function getCreditBalance(): Promise<CreditBalance> {
  return request('/api/credits/balance')
}

export async function createCheckout(
  amountEur: number,
): Promise<{ checkout_url: string }> {
  return request('/api/stripe/create-checkout', {
    method: 'POST',
    body: JSON.stringify({ amount_eur: amountEur }),
  })
}

// --- Hotels ---
export async function getHotelsConfig(): Promise<HotelConfig[]> {
  return request('/api/hotels')
}

export async function updateHotelConfig(
  hotelName: string,
  config: Partial<HotelConfig>,
): Promise<{ status: string }> {
  return request(`/api/hotels/${encodeURIComponent(hotelName)}/config`, {
    method: 'PUT',
    body: JSON.stringify(config),
  })
}

export async function getBenchmarkGeo(): Promise<BenchmarkGeo[]> {
  return request('/api/hotels/benchmark-geo')
}

export async function getBenchmarkCategories(): Promise<string[]> {
  return request('/api/hotels/benchmark-categories')
}

// --- Billing Profile ---
export async function getBillingProfile(): Promise<BillingProfile> {
  return request('/api/user/billing-profile')
}

export async function saveBillingProfile(
  profile: BillingProfileForm,
): Promise<BillingProfile> {
  return request('/api/user/billing-profile', {
    method: 'PUT',
    body: JSON.stringify(profile),
  })
}

// --- Conversation Messages ---
export async function getConversationMessages(): Promise<{ messages: PersistedMessage[] }> {
  return request('/api/conversations/messages')
}

// --- Chat Pending (background task still running?) ---
export async function getChatPending(): Promise<{ pending: boolean }> {
  return request('/api/chat/pending')
}

// --- Maintenance status (public, no auth) ---
export async function getMaintenanceStatus(): Promise<{ maintenance: boolean }> {
  const response = await fetch(`${API_BASE_URL}/api/jobs/maintenance-status`)
  if (!response.ok) return { maintenance: false }
  return response.json()
}

// --- Email Report Subscriptions ---
export async function getEmailReports(): Promise<EmailReportsConfig> {
  return request('/api/email-reports')
}

export async function saveEmailReports(
  hotels: { hotel_name: string; report_types: number[] }[],
  weekdaysPerReport: Record<string, number>,
): Promise<{ status: string }> {
  return request('/api/email-reports', {
    method: 'PUT',
    body: JSON.stringify({ hotels, weekdays_per_report: weekdaysPerReport }),
  })
}

export async function sendReportNow(data: {
  hotel_name: string
  report_type?: number
  custom_report_id?: number
}): Promise<{ status: string; message: string }> {
  return request('/api/email-reports/send-now', {
    method: 'POST',
    body: JSON.stringify(data),
  })
}

// --- Custom Email Reports ---
export async function getCustomReports(): Promise<{ custom_reports: CustomEmailReport[] }> {
  return request('/api/email-reports/custom')
}

export async function createCustomReport(data: {
  title: string
  prompt: string
  weekdays: number
  hotel_names: string[]
}): Promise<{ id: number; status: string }> {
  return request('/api/email-reports/custom', {
    method: 'POST',
    body: JSON.stringify(data),
  })
}

export async function updateCustomReport(
  id: number,
  data: { title: string; prompt: string; weekdays: number; hotel_names: string[] },
): Promise<{ status: string }> {
  return request(`/api/email-reports/custom/${id}`, {
    method: 'PUT',
    body: JSON.stringify(data),
  })
}

export async function deleteCustomReport(id: number): Promise<{ status: string }> {
  return request(`/api/email-reports/custom/${id}`, {
    method: 'DELETE',
  })
}
