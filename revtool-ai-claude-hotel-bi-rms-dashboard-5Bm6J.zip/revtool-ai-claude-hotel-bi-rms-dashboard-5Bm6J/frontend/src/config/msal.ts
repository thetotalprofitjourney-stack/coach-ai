import { Configuration, LogLevel } from '@azure/msal-browser'

const clientId = import.meta.env.VITE_AZURE_CLIENT_ID

/** Detect if we are running inside an iframe (e.g. Power BI embed). */
export const isEmbedded = window.self !== window.top

export const msalConfig: Configuration = {
  auth: {
    clientId,
    // Multi-tenant: "organizations" allows any Azure AD work account to authenticate.
    // Authorization is controlled server-side via the users + user_hotel_access tables.
    authority: 'https://login.microsoftonline.com/organizations',
    redirectUri: window.location.origin,
    postLogoutRedirectUri: window.location.origin,
  },
  cache: {
    cacheLocation: 'sessionStorage',
    storeAuthStateInCookie: false,
  },
  system: {
    loggerOptions: {
      loggerCallback: (level, message, containsPii) => {
        if (containsPii) return
        if (level === LogLevel.Error) console.error(message)
      },
      logLevel: LogLevel.Error,
      piiLoggingEnabled: false,
    },
    // When inside an iframe, allow navigation to Azure AD login
    allowNativeBroker: false,
  },
}

export const loginRequest = {
  scopes: ['openid', 'profile', 'email', 'User.Read'],
}
