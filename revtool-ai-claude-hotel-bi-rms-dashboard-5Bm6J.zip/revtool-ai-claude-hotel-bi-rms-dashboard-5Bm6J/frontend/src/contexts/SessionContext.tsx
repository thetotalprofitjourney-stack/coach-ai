import {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  useRef,
  type ReactNode,
} from 'react'
import { useIsAuthenticated } from '@azure/msal-react'
import { useTranslation } from 'react-i18next'
import * as api from '../services/api'
import type { SessionInfo, CreditBalance, HotelConfig } from '../types'

const MAINTENANCE_POLL_ACTIVE_MS = 10_000 // poll every 10s while in maintenance

interface SessionState {
  session: SessionInfo | null
  credits: CreditBalance | null
  hotelsData: HotelConfig[]
  selectedHotels: string[]
  loading: boolean
  error: string | null
  maintenanceActive: boolean
  setMaintenanceActive: (active: boolean) => void
  setSelectedHotels: (hotels: string[]) => void
  refreshSession: () => Promise<void>
  refreshCredits: () => Promise<void>
  updateBalance: (newBalance: number) => void
  changeLanguage: (lang: string) => Promise<void>
}

const SessionContext = createContext<SessionState | null>(null)

export function SessionProvider({ children }: { children: ReactNode }) {
  const isAuthenticated = useIsAuthenticated()
  const { i18n } = useTranslation()
  const [session, setSession] = useState<SessionInfo | null>(null)
  const [credits, setCredits] = useState<CreditBalance | null>(null)
  const [hotelsData, setHotelsData] = useState<HotelConfig[]>([])
  const [selectedHotels, setSelectedHotels] = useState<string[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [maintenanceActive, setMaintenanceActive] = useState(false)
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const refreshSession = useCallback(async () => {
    try {
      setLoading(true)
      setError(null)
      const [data, hotels] = await Promise.all([
        api.getSession(),
        api.getHotelsConfig(),
      ])
      setSession(data)
      setHotelsData(hotels)
      setMaintenanceActive(data.maintenance_active)

      // Sync language from server preference
      if (data.preferred_language && data.preferred_language !== i18n.language) {
        i18n.changeLanguage(data.preferred_language)
        localStorage.setItem('revtool-lang', data.preferred_language)
      }

      // Auto-select first hotel if none selected
      if (selectedHotels.length === 0 && data.accessible_hotels.length > 0) {
        setSelectedHotels([data.accessible_hotels[0]])
      }
    } catch (err: any) {
      setError(err.message || 'Error loading session')
    } finally {
      setLoading(false)
    }
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  const refreshCredits = useCallback(async () => {
    try {
      const data = await api.getCreditBalance()
      setCredits(data)
    } catch {
      // Silent fail for credit refresh
    }
  }, [])

  const changeLanguage = useCallback(async (lang: string) => {
    i18n.changeLanguage(lang)
    localStorage.setItem('revtool-lang', lang)
    setSession((prev) => prev ? { ...prev, preferred_language: lang } : prev)
    try {
      await api.updateLanguage(lang)
    } catch {
      // Silent fail — language already changed locally
    }
  }, [i18n])

  const updateBalance = useCallback((newBalance: number) => {
    setSession((prev) =>
      prev ? { ...prev, balance_eur: newBalance } : prev,
    )
    setCredits((prev) =>
      prev
        ? {
            ...prev,
            balance_eur: newBalance,
            is_blocked: newBalance <= 0,
            is_low_balance: newBalance <= (prev.low_balance_alert ?? 2),
          }
        : prev,
    )
  }, [])

  useEffect(() => {
    if (isAuthenticated) {
      refreshSession()
      refreshCredits()
    }
  }, [isAuthenticated, refreshSession, refreshCredits])

  // Poll maintenance status only while active (to detect when it ends).
  // Maintenance is detected when:
  //   - Session load returns maintenance_active: true, OR
  //   - POST /api/chat returns 503 → useChat calls setMaintenanceActive(true)
  useEffect(() => {
    if (!maintenanceActive) return

    pollRef.current = setInterval(async () => {
      try {
        const { maintenance } = await api.getMaintenanceStatus()
        if (!maintenance) {
          setMaintenanceActive(false)
          // Refresh session to get fresh data after sync
          refreshSession()
          refreshCredits()
        }
      } catch {
        // Silent fail — will retry next interval
      }
    }, MAINTENANCE_POLL_ACTIVE_MS)

    return () => {
      if (pollRef.current) {
        clearInterval(pollRef.current)
        pollRef.current = null
      }
    }
  }, [maintenanceActive, refreshSession, refreshCredits])

  return (
    <SessionContext.Provider
      value={{
        session,
        credits,
        hotelsData,
        selectedHotels,
        loading,
        error,
        maintenanceActive,
        setMaintenanceActive,
        setSelectedHotels,
        refreshSession,
        refreshCredits,
        updateBalance,
        changeLanguage,
      }}
    >
      {children}
    </SessionContext.Provider>
  )
}

export function useSession() {
  const ctx = useContext(SessionContext)
  if (!ctx) throw new Error('useSession must be used within SessionProvider')
  return ctx
}
