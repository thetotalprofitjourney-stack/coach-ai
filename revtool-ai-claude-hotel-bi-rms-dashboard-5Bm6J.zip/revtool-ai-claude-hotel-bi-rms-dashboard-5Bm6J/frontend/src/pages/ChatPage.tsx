import { useState, useEffect, useRef } from 'react'
import { useSession } from '../contexts/SessionContext'
import { useChat } from '../hooks/useChat'
import { useTranslation } from 'react-i18next'
import * as api from '../services/api'
import Header from '../components/Header'
import ChatArea from '../components/ChatArea'
import ChatInput from '../components/ChatInput'
import TopupModal from '../components/TopupModal'
import HotelConfigModal from '../components/HotelConfigModal'
import BillingProfileModal from '../components/BillingProfileModal'
import EmailReportsModal from '../components/EmailReportsModal'
import BlockedOverlay from '../components/BlockedOverlay'
import MaintenanceOverlay from '../components/MaintenanceOverlay'
import { Loader2 } from 'lucide-react'
import type { ChatMessage } from '../types'

let restoreIdCounter = 0

export default function ChatPage() {
  const {
    session,
    credits,
    selectedHotels,
    loading: sessionLoading,
    updateBalance,
    refreshCredits,
    maintenanceActive,
    setMaintenanceActive,
  } = useSession()
  const { messages, isLoading, statusMessage, sendMessage, setInitialMessages, recoverPending } = useChat()
  const { t } = useTranslation()
  const [topupOpen, setTopupOpen] = useState(false)
  const [configOpen, setConfigOpen] = useState(false)
  const [billingProfileOpen, setBillingProfileOpen] = useState(false)
  const [emailReportsOpen, setEmailReportsOpen] = useState(false)
  const [topupSuccess, setTopupSuccess] = useState(false)
  const messagesLoaded = useRef(false)

  // Show onboarding modal if billing profile not complete
  const needsOnboarding =
    session && !sessionLoading && !session.billing_profile_complete

  // Load persisted messages on session init (once) + check for pending background task
  useEffect(() => {
    if (session && !messagesLoaded.current) {
      messagesLoaded.current = true
      Promise.all([
        api.getConversationMessages(),
        api.getChatPending(),
      ]).then(([data, { pending }]) => {
        if (data.messages.length > 0) {
          const restored: ChatMessage[] = data.messages.map((m) => ({
            id: `restored-${++restoreIdCounter}`,
            role: m.role,
            content: m.content,
            cost_eur: m.cost_eur,
            balance_after: m.balance_after,
            analysis_mode: m.analysis_mode,
            timestamp: new Date(m.timestamp),
          }))
          setInitialMessages(restored)
        }
        if (pending) {
          recoverPending(updateBalance)
        }
      }).catch(() => {
        // Silent fail — no persisted messages available
      })
    }
  }, [session, setInitialMessages, recoverPending, updateBalance])

  // Check for Stripe return
  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    if (params.get('topup') === 'success') {
      setTopupSuccess(true)
      // Poll for balance update
      const poll = setInterval(refreshCredits, 2000)
      setTimeout(() => clearInterval(poll), 20000)
      // Clean URL
      window.history.replaceState({}, '', window.location.pathname)
      // Auto-hide success after 5s
      setTimeout(() => setTopupSuccess(false), 5000)
    }
    if (params.get('topup') === 'cancelled') {
      window.history.replaceState({}, '', window.location.pathname)
    }
  }, [refreshCredits])

  const isBlocked = credits?.is_blocked ?? (session?.balance_eur ?? 0) <= 0

  const handleSend = (message: string) => {
    sendMessage(message, selectedHotels, updateBalance, () => setMaintenanceActive(true))
  }

  if (sessionLoading && !session) {
    return (
      <div className="h-full flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-blue-500 mx-auto mb-3" />
          <p className="text-sm text-gray-500">{t('chat.loadingSession')}</p>
        </div>
      </div>
    )
  }

  return (
    <div className="h-full w-full flex flex-col bg-gray-50 overflow-hidden">
      <Header
        onOpenConfig={() => setConfigOpen(true)}
        onOpenTopup={() => setTopupOpen(true)}
        onOpenBillingProfile={() => setBillingProfileOpen(true)}
        onOpenEmailReports={() => setEmailReportsOpen(true)}
      />

      {/* Topup success banner */}
      {topupSuccess && (
        <div className="bg-green-50 border-b border-green-200 px-4 py-2.5 text-center animate-slide-up">
          <p className="text-sm text-green-700 font-medium">
            {t('balance.topupSuccess', { balance: (credits?.balance_eur ?? session?.balance_eur ?? 0).toFixed(2) })}
          </p>
        </div>
      )}

      {/* Low balance warning */}
      {credits?.is_low_balance && !isBlocked && (
        <div className="bg-amber-50 border-b border-amber-200 px-4 py-2 text-center">
          <p className="text-xs text-amber-700">
            {t('balance.lowBalanceMsg', { balance: (credits?.balance_eur ?? 0).toFixed(2) })}{' '}
            <button
              onClick={() => setTopupOpen(true)}
              className="text-amber-800 font-medium underline hover:no-underline"
            >
              {t('balance.rechargeNow')}
            </button>
          </p>
        </div>
      )}

      {/* Chat area */}
      <div className="flex-1 min-h-0 relative overflow-hidden">
        <ChatArea
          messages={messages}
          isLoading={isLoading}
          statusMessage={statusMessage}
          onSendMessage={handleSend}
        />

        {/* Maintenance overlay takes highest priority */}
        {maintenanceActive && <MaintenanceOverlay />}

        {/* Only show blocked overlay if billing is configured — otherwise
            the billing onboarding modal takes priority */}
        {!maintenanceActive && isBlocked && !sessionLoading && !needsOnboarding && (
          <BlockedOverlay onRecharge={() => setTopupOpen(true)} />
        )}
      </div>

      {/* Input */}
      <ChatInput
        onSend={handleSend}
        disabled={!!needsOnboarding || isBlocked || maintenanceActive || selectedHotels.length === 0}
        isLoading={isLoading}
      />

      {/* Modals */}
      <TopupModal isOpen={topupOpen} onClose={() => setTopupOpen(false)} />
      <HotelConfigModal
        isOpen={configOpen}
        onClose={() => setConfigOpen(false)}
      />

      {/* Billing profile: onboarding (mandatory) or manual open */}
      <BillingProfileModal
        isOpen={needsOnboarding || billingProfileOpen}
        onClose={() => setBillingProfileOpen(false)}
        isOnboarding={!!needsOnboarding}
      />

      {/* Email reports subscriptions */}
      <EmailReportsModal
        isOpen={emailReportsOpen}
        onClose={() => setEmailReportsOpen(false)}
      />
    </div>
  )
}
