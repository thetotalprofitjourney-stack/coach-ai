import {
  AuthenticatedTemplate,
  UnauthenticatedTemplate,
} from '@azure/msal-react'
import { SessionProvider } from './contexts/SessionContext'
import LoginScreen from './components/LoginScreen'
import ChatPage from './pages/ChatPage'

export default function App() {
  return (
    <>
      <UnauthenticatedTemplate>
        <LoginScreen />
      </UnauthenticatedTemplate>
      <AuthenticatedTemplate>
        <SessionProvider>
          <ChatPage />
        </SessionProvider>
      </AuthenticatedTemplate>
    </>
  )
}
