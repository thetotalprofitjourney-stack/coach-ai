export interface SessionInfo {
  upn: string
  accessible_hotels: string[]
  hotels_pending_setup: string[]
  balance_eur: number
  conversation_summary: string
  billing_profile_complete: boolean
  vat_applicable: boolean | null
  vat_rate: number
  maintenance_active: boolean
  preferred_language: string
}

export interface BillingProfile {
  upn: string
  company_name: string
  tax_id: string
  notification_email: string
  address_line: string
  city: string
  province: string
  postal_code: string | null
  country: string
  vat_applicable: boolean
}

export interface BillingProfileForm {
  company_name: string
  tax_id: string
  notification_email: string
  address_line: string
  city: string
  province: string
  postal_code: string
  country: string
}

export interface ChatMessage {
  id: string
  role: 'user' | 'assistant'
  content: string
  cost_eur?: number
  balance_after?: number
  analysis_mode?: string
  timestamp: Date
}

export interface ChatResponse {
  response: string
  analysis_mode: string
  cost_eur: number
  balance_after: number
}

export interface CreditBalance {
  balance_eur: number
  is_low_balance: boolean
  is_blocked: boolean
  total_topped_up: number
  total_consumed: number
  low_balance_alert?: number
  requests_this_month?: number
  cost_eur_this_month?: number
  tokens_this_month?: number
}

export interface HotelConfig {
  hotel_name: string
  destination: string | null
  province: string | null
  city: string | null
  country: string | null
  hotel_type: string | null
  target_client: string | null
  total_rooms: number | null
  currency: string | null
  marketing_highlights: string | null
  benchmark_category: string | null
  benchmark_country: string | null
  benchmark_ccaa: string | null
  benchmark_province: string | null
  benchmark_zone: string | null
  benchmark_available: boolean
  setup_complete: boolean
  setup_by: string | null
  setup_at: string | null
}

export interface BenchmarkGeo {
  country: string
  ccaa: string
  province: string
  zone: string
  display_label: string
}

export interface EmailReportSubscription {
  report_type: number
  title: string
  enabled: boolean
}

export interface EmailReportsConfig {
  report_types: { report_type: number; title: string }[]
  accessible_hotels: string[]
  subscribed_hotels: Record<string, number[]>  // hotel_name -> [report_type, ...]
  weekdays: number  // DEPRECATED — backwards compat
  weekdays_per_report: Record<string, number>  // report_type -> bitmask
}

export interface CustomEmailReport {
  id: number
  title: string
  prompt: string
  weekdays: number
  active: boolean
  created_at: string | null
  hotel_names: string[]
}

export interface PersistedMessage {
  role: 'user' | 'assistant'
  content: string
  cost_eur?: number
  balance_after?: number
  analysis_mode?: string
  timestamp: string
}
