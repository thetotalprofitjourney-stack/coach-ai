# Revtool AI — Guia de Despliegue Paso a Paso

Este documento cubre TODO lo que el desarrollador necesita hacer para poner
Revtool AI en produccion. Incluye backend, frontend y servicios externos.

---

## Requisitos previos

- Servidor **Ubuntu 24.04 LTS**
- Docker y Docker Compose instalados (solo para backend y frontend)
- Dominio con SSL (para HTTPS — requerido por Stripe y Microsoft)
- Acceso a una cuenta de Microsoft Azure (para Entra ID)
- Acceso a una cuenta de Stripe
- Clave API de Anthropic (Claude)

---

## Paso 1: Clonar el repositorio

```bash
git clone https://github.com/thetotalprofitjourney-stack/revtool-ai.git
cd revtool-ai
```

---

## Paso 2: Instalar y configurar PostgreSQL en el host

PostgreSQL 16 se instala directamente desde los paquetes de Ubuntu 24.04.
**No se usa Docker para la base de datos.**

### 2.1 Instalar PostgreSQL

```bash
sudo apt update
sudo apt install -y postgresql postgresql-contrib
```

Esto instala PostgreSQL 16 y lo habilita como servicio systemd.

```bash
# Verificar que esta corriendo
sudo systemctl status postgresql
```

### 2.2 Crear usuario y base de datos

```bash
sudo -u postgres psql <<'SQL'
CREATE USER revtool WITH PASSWORD 'tu_password_segura';
CREATE DATABASE revtool_ai OWNER revtool;
GRANT ALL PRIVILEGES ON DATABASE revtool_ai TO revtool;
\c revtool_ai
GRANT ALL ON SCHEMA public TO revtool;
SQL
```

### 2.3 Configurar acceso desde Docker

Los contenedores Docker acceden a PostgreSQL del host via la red bridge de
Docker (subred `172.17.0.0/16`). Hay que permitir estas conexiones.

**Editar `postgresql.conf`:**

```bash
sudo nano /etc/postgresql/16/main/postgresql.conf
```

Busca la linea `listen_addresses` y cambia a:

```
listen_addresses = 'localhost, 172.17.0.1'
```

> `172.17.0.1` es la IP del host en la red bridge de Docker (docker0).
> Esto permite conexiones desde los contenedores sin exponer PostgreSQL
> a todas las interfaces.

**Editar `pg_hba.conf`:**

```bash
sudo nano /etc/postgresql/16/main/pg_hba.conf
```

Anade esta linea al final del fichero:

```
# Permitir conexiones desde contenedores Docker (red bridge)
host    revtool_ai    revtool    172.17.0.0/16    scram-sha-256
```

**Reiniciar PostgreSQL:**

```bash
sudo systemctl restart postgresql
```

### 2.4 Ejecutar los esquemas

```bash
cd /ruta/a/revtool-ai

for f in sql/schema/001_dimensions.sql \
         sql/schema/002_daily_facts.sql \
         sql/schema/003_monthly_facts.sql \
         sql/schema/004_pricing_strategy.sql \
         sql/schema/005_access_and_billing.sql \
         sql/schema/006_benchmark_sectorial.sql \
         sql/schema/007_pricing_strategy_by_roomtype.sql \
         sql/schema/008_conversation_summaries.sql \
         sql/schema/009_billing_profile.sql; do
  psql -U revtool -d revtool_ai -f "$f"
done

# Crear las vistas analiticas
psql -U revtool -d revtool_ai -f sql/views/001_analytical_views.sql

# (Opcional) Cargar datos de prueba
psql -U revtool -d revtool_ai -f sql/seeds/002_sample_data.sql
```

> **Nota**: Si ejecutas `psql` desde el propio servidor, puedes conectar por
> socket Unix sin password. Si necesitas password, usa
> `PGPASSWORD=tu_password psql -U revtool -h localhost -d revtool_ai -f "$f"`

**Verificar:**
```bash
psql -U revtool -d revtool_ai -c "\dt"
# Deberias ver todas las tablas (dim_hotels, daily_hotel_summary, users, etc.)
```

---

## Paso 3: Registrar aplicacion en Microsoft Entra ID (Azure AD) — Multi-tenant

Esto es necesario para que los usuarios se autentiquen con su cuenta Microsoft.
La app se registra como **multi-tenant**: cualquier usuario con cuenta de trabajo
de Microsoft (Azure AD) de cualquier organizacion puede autenticarse.

La autorizacion (quien puede usar la app) se controla en la base de datos via
las tablas `users` y `user_hotel_access`, no en Entra ID.

### 3.1 Crear el App Registration

1. Ve a [Azure Portal](https://portal.azure.com) > Microsoft Entra ID > App registrations
2. Click "New registration"
3. Configurar:
   - **Name**: `Revtool AI`
   - **Supported account types**: **"Accounts in any organizational directory (Any Microsoft Entra ID tenant — Multitenant)"**
   - **Redirect URI**: Tipo **SPA** (Single-page application), URL: `https://revtool.thetotalprofitjourney.com`
4. Click "Register"

> **IMPORTANTE**: Selecciona "Multitenant", NO "single tenant". Esto permite que
> usuarios de cualquier organizacion (hotel.com, resort.es, etc.) puedan hacer login.
> Cada tenant de Microsoft tiene su propio directorio; con multi-tenant, todos son
> bienvenidos a autenticarse. Despues, tu base de datos decide si el usuario tiene
> acceso (tabla `users`) y a que hoteles (tabla `user_hotel_access`).

### 3.2 Copiar los valores necesarios

De la pagina del App Registration, copia:
- **Application (client) ID** > sera `AZURE_CLIENT_ID` / `VITE_AZURE_CLIENT_ID`

> **Nota**: No necesitas copiar el Directory (tenant) ID. La app es multi-tenant
> y usa el endpoint `https://login.microsoftonline.com/organizations` que acepta
> tokens de cualquier tenant de Azure AD.

### 3.3 Configurar permisos

1. Ve a "API permissions" > "Add a permission"
2. Selecciona "Microsoft Graph" > "Delegated permissions"
3. Anade: `openid`, `profile`, `email`, `User.Read`
4. Click "Grant admin consent for [tu organizacion]"

> **Nota sobre consent en multi-tenant**: El admin consent que das aqui aplica
> solo a los usuarios de TU tenant. Cuando un usuario de OTRO tenant intente
> hacer login por primera vez, su propio administrador de Azure AD debera aprobar
> los permisos, o el usuario los aceptara individualmente (user consent) si su
> tenant lo permite. Los permisos solicitados son basicos (openid, profile, email,
> User.Read) y la mayoria de organizaciones los aprueban automaticamente.

### 3.4 Configurar token

1. Ve a "Token configuration" > "Add optional claim"
2. Token type: "ID"
3. Anade los claims: `upn`, `email`, `preferred_username`

### 3.5 Configurar redirect URIs

1. Ve a "Authentication" > "Platform configurations"
2. En "Single-page application", anade:
   - `https://revtool.thetotalprofitjourney.com` (produccion)
   - `http://localhost:3000` (desarrollo)
3. Marca: "ID tokens (used for implicit and hybrid flows)"

**Nota**: El frontend usa MSAL.js (SPA). No necesitas client secret.
El backend solo valida tokens JWT — no hace el flujo OAuth directamente.

### 3.6 Verificar que es multi-tenant

1. Ve a "Authentication" en el App Registration
2. En "Supported account types" debe decir:
   **"Accounts in any organizational directory (Any Microsoft Entra ID tenant — Multitenant)"**
3. Si dice "Accounts in this organizational directory only", cambialo a Multitenant

---

## Paso 4: Configurar Stripe

### 4.1 Crear cuenta y obtener API keys

1. Ve a [Stripe Dashboard](https://dashboard.stripe.com)
2. Settings > API keys
3. Copia:
   - **Publishable key** (`pk_live_...`) > `STRIPE_PUBLISHABLE_KEY` / `VITE_STRIPE_PUBLISHABLE_KEY`
   - **Secret key** (`sk_live_...`) > `STRIPE_SECRET_KEY`

**Para desarrollo**, usa las keys de test (`pk_test_...`, `sk_test_...`).

### 4.2 Configurar Webhooks

1. Stripe Dashboard > Developers > Webhooks > "Add endpoint"
2. Configurar:
   - **Endpoint URL**: `https://revtool.thetotalprofitjourney.com/api/stripe/webhook`
   - **Events to listen**: selecciona:
     - `checkout.session.completed`
     - `charge.refunded`
3. Una vez creado, copia el **Signing secret** (`whsec_...`) > `STRIPE_WEBHOOK_SECRET`

### 4.3 Configurar metodos de pago

1. Settings > Payment methods
2. Habilita: Card, Google Pay, Apple Pay
3. (Opcional) SEPA Direct Debit, iDEAL para clientes EU

---

## Paso 5: Obtener API key de Anthropic

1. Ve a [Anthropic Console](https://console.anthropic.com)
2. Settings > API keys > "Create Key"
3. Copia la key (`sk-ant-api03-...`) > `ANTHROPIC_API_KEY`

**Nota sobre modelos**:
- Sonnet (interaccion principal): `claude-sonnet-4-5-20250929`
- Haiku (resumenes en background): `claude-haiku-4-5-20251001`

Estos ya estan configurados por defecto en el `.env.example`.

---

## Paso 6: Crear los ficheros .env

### 6.1 Backend

```bash
cd backend
cp .env.example .env
nano .env  # Editar con los valores reales
```

Rellena TODAS las variables con los valores obtenidos en los pasos anteriores:

```
DATABASE_URL=postgresql+asyncpg://revtool:tu_password_real@host.docker.internal:5432/revtool_ai
AZURE_CLIENT_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
ANTHROPIC_API_KEY=sk-ant-api03-xxxxx
STRIPE_SECRET_KEY=sk_live_xxxxx
STRIPE_PUBLISHABLE_KEY=pk_live_xxxxx
STRIPE_WEBHOOK_SECRET=whsec_xxxxx
VAT_RATE=21.0
CORS_ORIGINS=["https://revtool.thetotalprofitjourney.com"]
```

**IMPORTANTE**: El `DATABASE_URL` usa `host.docker.internal` como host.
Esta direccion especial permite al contenedor Docker conectar con el PostgreSQL
nativo del host. Se configura via `extra_hosts` en `docker-compose.yml`.

Si ejecutas el backend **sin Docker** (desarrollo local), usa `localhost`:
```
DATABASE_URL=postgresql+asyncpg://revtool:tu_password@localhost:5432/revtool_ai
```

### 6.2 Frontend

Las variables del frontend se pasan como build args en `docker-compose.yml`.
Crea un fichero `.env` en la raiz del proyecto (junto a `docker-compose.yml`):

```bash
cd ..  # Raiz del proyecto
nano .env
```

```
VITE_AZURE_CLIENT_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
VITE_API_BASE_URL=
VITE_STRIPE_PUBLISHABLE_KEY=pk_live_xxxxx
```

**Nota**: `VITE_API_BASE_URL` se deja vacio en produccion porque el frontend
nginx hace proxy al backend directamente. Solo se necesita en desarrollo local
(ej: `http://localhost:8000`).

---

## Paso 7: Levantar los servicios

```bash
docker compose up -d
```

Esto levanta dos contenedores:
- `backend` — FastAPI en puerto 8000
- `frontend` — nginx + React SPA en puerto 3000

PostgreSQL corre directamente en el host (systemd).

**Verificar:**
```bash
# Health check del backend
curl http://localhost:8000/health
# Respuesta: {"status":"ok"}

# Frontend servido correctamente
curl -s http://localhost:3000 | head -5
# Deberia devolver HTML con el tag <div id="root">

# PostgreSQL accesible desde el host
psql -U revtool -d revtool_ai -c "SELECT 1"

# API docs automaticas (Swagger)
# Abre en navegador: http://localhost:8000/docs
```

---

## Paso 8: Configurar HTTPS (produccion)

En produccion necesitas HTTPS. El frontend (nginx) actua como proxy al backend,
asi que solo necesitas exponer el frontend al exterior.

### Opcion A: Nginx reverse proxy + Let's Encrypt (en el host)

```nginx
server {
    listen 443 ssl;
    server_name revtool.thetotalprofitjourney.com;

    ssl_certificate /etc/letsencrypt/live/revtool.thetotalprofitjourney.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/revtool.thetotalprofitjourney.com/privkey.pem;

    # Todo pasa por el frontend nginx (que ya hace proxy al backend)
    location / {
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;

        # WebSocket support (si se anade en el futuro)
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";

        # Timeout para respuestas de IA (pueden tardar)
        proxy_read_timeout 120s;
    }
}

server {
    listen 80;
    server_name revtool.thetotalprofitjourney.com;
    return 301 https://$server_name$request_uri;
}
```

### Opcion B: Cloud provider (AWS ALB, GCP Load Balancer, etc.)

La mayoria de cloud providers gestionan SSL automaticamente en el load balancer.

---

## Paso 9: Crear el primer usuario

Para que un usuario pueda usar Revtool AI, necesitas:

### 9.1 Crear el usuario en la tabla `users`

```sql
INSERT INTO users (upn, created_at)
VALUES ('rm.mallorca@hotel.com', NOW());
```

### 9.2 Asignar hoteles

```sql
-- Primero el hotel debe existir en dim_hotels
INSERT INTO dim_hotels (hotel_name)
VALUES ('Hotel Playa Dorada')
ON CONFLICT DO NOTHING;

-- Luego asignar acceso
INSERT INTO user_hotel_access (upn, hotel_name)
VALUES ('rm.mallorca@hotel.com', 'Hotel Playa Dorada');
```

### 9.3 Dar saldo inicial

```sql
INSERT INTO credit_balance (upn, balance_eur, total_topped_up, total_consumed)
VALUES ('rm.mallorca@hotel.com', 10.00, 10.00, 0);

INSERT INTO credit_transactions (upn, transaction_type, amount_eur, balance_after,
                                  description, created_by)
VALUES ('rm.mallorca@hotel.com', 'topup', 10.00, 10.00,
        'Saldo inicial de cortesia', 'admin');
```

---

## Paso 10: Configurar Power Automate (carga de datos)

Los datos de los hoteles llegan desde PowerBI via Power Automate.
Ver `docs/power_automate_load.md` para la especificacion completa del ETL.

**Resumen**: Power Automate ejecuta un flujo diario que:
1. Extrae datos de PowerBI (tablas de Revtool)
2. Transforma al formato de las tablas PostgreSQL
3. UPSERT via API o conexion directa a PostgreSQL

---

## Arquitectura del despliegue

```
                    INTERNET
                       |
              [Nginx host / LB]
                   (HTTPS:443)
                       |
          +------------+------------+
          |                         |
    [frontend:3000]           (proxy /api/)
     nginx + React SPA              |
          |                   [backend:8000]
          |                    FastAPI + Python
          |                         |
          |               host.docker.internal
          |                         |
          |                [PostgreSQL :5432]
          |                 (nativo en el host)
          +-------------------------+
```

- PostgreSQL corre como servicio systemd en el host (Ubuntu 24.04, paquete apt)
- Los contenedores Docker acceden a PostgreSQL via `host.docker.internal`
- Solo los puertos 3000 (o 443 via reverse proxy) necesitan estar expuestos
- El backend no necesita estar accesible directamente desde internet

---

## Resumen de endpoints

| Endpoint | Metodo | Auth | Descripcion |
|----------|--------|------|-------------|
| `/health` | GET | No | Health check |
| `/api/session` | GET | Bearer | Init sesion (hoteles, balance, summary) |
| `/api/chat` | POST | Bearer | Conversacion con la IA |
| `/api/credits/balance` | GET | Bearer | Consultar saldo |
| `/api/stripe/create-checkout` | POST | Bearer | Crear sesion de pago (requiere perfil facturacion) |
| `/api/stripe/webhook` | POST | Stripe Signature | Webhook de Stripe (calcula IVA, registra en sales_ledger) |
| `/api/user/billing-profile` | GET | Bearer | Obtener perfil de facturacion |
| `/api/user/billing-profile` | PUT | Bearer | Crear/actualizar perfil de facturacion |
| `/api/hotels` | GET | Bearer | Listar hoteles con config |
| `/api/hotels/{name}/config` | PUT | Bearer | Actualizar config del hotel |
| `/api/hotels/benchmark-geo` | GET | No | Opciones geograficas de benchmark |
| `/api/hotels/benchmark-categories` | GET | No | Categorias de benchmark |
| `/docs` | GET | No | Swagger UI (documentacion API automatica) |

---

## Frontend — Estructura y componentes

```
frontend/
+-- Dockerfile              # Multi-stage: build con Node, servir con nginx
+-- nginx.conf              # Proxy al backend + SPA fallback
+-- package.json
+-- vite.config.ts
+-- tailwind.config.js
+-- src/
    +-- main.tsx            # Entry point + MSAL init
    +-- App.tsx             # Auth gate (Login vs Chat)
    +-- config/
    |   +-- msal.ts         # MSAL configuration
    |   +-- api.ts          # API base URL
    +-- services/
    |   +-- api.ts          # API client con auth headers
    +-- contexts/
    |   +-- SessionContext   # Session state (hotels, balance)
    +-- hooks/
    |   +-- useChat.ts      # Chat state management
    +-- pages/
    |   +-- ChatPage.tsx    # Main page (orchestrates all)
    +-- components/
        +-- LoginScreen      # Microsoft login
        +-- Header           # Logo + hotel selector + config + balance
        +-- HotelSelector    # Dropdown con checkboxes
        +-- BalanceDisplay   # Saldo + boton recargar
        +-- ChatArea         # Area de mensajes scrollable
        +-- ChatMessage      # Mensaje individual (markdown)
        +-- ChatInput        # Input con attach y send
        +-- TopupModal           # Modal de recarga Stripe (con desglose IVA)
        +-- HotelConfigModal     # Formulario de config de hoteles
        +-- BillingProfileModal  # Perfil de empresa para facturacion (onboarding + edicion)
        +-- BlockedOverlay       # Overlay sin saldo
```

### Stack tecnologico frontend

| Tecnologia | Version | Proposito |
|-----------|---------|-----------|
| React | 18 | UI framework |
| TypeScript | 5.6 | Type safety |
| Vite | 6 | Build tool |
| Tailwind CSS | 3.4 | Styling |
| MSAL React | 2.1 | Azure AD auth |
| react-markdown | 9.0 | Render markdown de la IA |
| lucide-react | 0.468 | Iconos |

---

## Checklist de despliegue

### Infraestructura
- [ ] Servidor Ubuntu 24.04 LTS
- [ ] PostgreSQL 16 instalado via apt y corriendo (systemd)
- [ ] Docker y Docker Compose instalados
- [ ] Dominio configurado con DNS apuntando al servidor
- [ ] HTTPS configurado (Nginx + Let's Encrypt o cloud LB)

### Base de datos
- [ ] Usuario `revtool` creado en PostgreSQL
- [ ] Base de datos `revtool_ai` creada
- [ ] `pg_hba.conf` permite conexiones desde red Docker (172.17.0.0/16)
- [ ] `postgresql.conf` escucha en `localhost, 172.17.0.1`
- [ ] Esquemas SQL ejecutados en orden (001 a 009)
- [ ] Vistas analiticas creadas

### Servicios externos
- [ ] App Registration creada en Azure AD como **multi-tenant** (client ID)
- [ ] Redirect URI configurado como SPA: `https://revtool.thetotalprofitjourney.com`
- [ ] Permisos de Microsoft Graph concedidos (openid, profile, email)
- [ ] Supported account types = "Accounts in any organizational directory (Multitenant)"
- [ ] Cuenta Stripe configurada (API keys + webhook endpoint)
- [ ] Webhook de Stripe apuntando a `https://revtool.thetotalprofitjourney.com/api/stripe/webhook`
- [ ] API key de Anthropic obtenida

### Configuracion
- [ ] Fichero `backend/.env` creado con todos los valores reales
- [ ] `DATABASE_URL` apunta a `host.docker.internal` (Docker) o `localhost` (sin Docker)
- [ ] Fichero `.env` en raiz con variables VITE_* para el frontend
- [ ] `CORS_ORIGINS` en backend apuntando al dominio del frontend

### Despliegue
- [ ] `docker compose up -d` ejecutado correctamente
- [ ] Health check respondiendo: `curl https://revtool.thetotalprofitjourney.com/health`
- [ ] Frontend cargando: `https://revtool.thetotalprofitjourney.com`
- [ ] Login con Microsoft funciona
- [ ] Al menos un usuario creado con hotel asignado y saldo
- [ ] Power Automate configurado para carga diaria de datos

---

## Troubleshooting

### El backend no conecta a PostgreSQL

- Verifica que PostgreSQL escucha en la interfaz Docker:
  ```bash
  ss -tlnp | grep 5432
  # Debe mostrar 127.0.0.1:5432 y 172.17.0.1:5432
  ```
- Verifica que `pg_hba.conf` permite la subred Docker:
  ```bash
  sudo grep docker /etc/postgresql/16/main/pg_hba.conf
  ```
- Prueba la conexion desde un contenedor:
  ```bash
  docker run --rm --add-host=host.docker.internal:host-gateway postgres:16-alpine \
    psql postgresql://revtool:tu_password@host.docker.internal:5432/revtool_ai -c "SELECT 1"
  ```
- Verifica que `extra_hosts` esta en `docker-compose.yml` (servicio backend)

### "401 Unauthorized" en /api/session
- Verifica que `AZURE_CLIENT_ID` es correcto en ambos `.env`
  (backend y frontend deben usar el mismo client ID)
- Verifica que el App Registration esta configurado como **multi-tenant**
  ("Accounts in any organizational directory")
- Verifica que el Redirect URI en Azure esta configurado como SPA
- Verifica que el token incluye el claim `preferred_username` o `upn`
- Comprueba en DevTools > Network que el header `Authorization: Bearer <token>`
  se envia con cada request
- Si el usuario es de otro tenant: verificar que su admin ha dado consent
  (o que user consent esta permitido en su organizacion)

### "402 Payment Required" en /api/chat
- El usuario no tiene saldo. Inserta un registro en `credit_balance`
- O el usuario debe recargar via Stripe

### "403 Forbidden" en /api/chat
- El usuario selecciono un hotel al que no tiene acceso en `user_hotel_access`
- Verifica: `SELECT * FROM user_hotel_access WHERE upn = 'usuario@...'`

### Frontend muestra pantalla en blanco
- Revisa DevTools > Console para errores de JavaScript
- Verifica que las variables VITE_* se pasaron correctamente al build
- En el contenedor: `docker compose exec frontend cat /usr/share/nginx/html/index.html`

### Stripe webhook no llega
- Verifica que la URL del webhook es accesible desde internet (HTTPS)
- En Stripe Dashboard > Webhooks > verifica el log de intentos
- Verifica que `STRIPE_WEBHOOK_SECRET` coincide con el del endpoint
- Asegura que `proxy_request_buffering off` esta configurado para `/api/stripe/webhook`

### La IA no responde
- Verifica que `ANTHROPIC_API_KEY` es valida
- Verifica en logs: `docker compose logs backend`
- Verifica que hay datos en las vistas: `SELECT COUNT(*) FROM v_daily_summary`
- La respuesta puede tardar hasta 60s — verifica que el timeout del proxy es suficiente

### CORS errors
- Verifica que `CORS_ORIGINS` en el backend incluye la URL exacta del frontend
  (con protocolo, sin trailing slash): `["https://revtool.thetotalprofitjourney.com"]`
- En produccion, el frontend nginx hace proxy, asi que CORS no aplica
  (mismo origen). Solo relevante en desarrollo local.

### Backups de PostgreSQL
- Al correr PostgreSQL nativo en el host, los backups se gestionan con
  herramientas estandar:
  ```bash
  # Backup completo
  pg_dump -U revtool revtool_ai > backup_$(date +%Y%m%d).sql

  # Restaurar
  psql -U revtool -d revtool_ai < backup_20260223.sql

  # Backup automatico con cron (ejemplo: diario a las 3am)
  # 0 3 * * * pg_dump -U revtool revtool_ai | gzip > /backups/revtool_$(date +\%Y\%m\%d).sql.gz
  ```
