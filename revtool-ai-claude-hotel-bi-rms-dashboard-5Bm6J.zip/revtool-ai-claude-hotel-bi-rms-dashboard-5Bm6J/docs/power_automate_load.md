# Guía de carga diaria desde Power Automate

Este documento define **exactamente** cómo Power Automate debe insertar/actualizar datos en PostgreSQL cada mañana. Cada tabla tiene una **clave única compuesta** que permite:

- **INSERT** si la combinación de campos clave no existe
- **UPDATE** (sobrescribir) si la combinación ya existe

Esto se consigue con `INSERT ... ON CONFLICT ... DO UPDATE` (UPSERT nativo de PostgreSQL).

---

## Principios

### Orden de carga

La única dimensión es `dim_hotels`, que debe cargarse **antes** que los hechos. Todas las demás dimensiones (segmentos, canales, tipos de habitación, planes de comida, países) se almacenan como **texto embebido** directamente en las tablas de hechos. No existen tablas de dimensiones separadas para ellas.

```
-- Dimensión (primero)
1.  dim_hotels                  (hotel_name)

-- Daily facts
2.  daily_hotel_summary         (hotel_name + stay_date)
3.  daily_hotel_segment         (hotel_name + stay_date + segment_name)
4.  daily_hotel_channel         (hotel_name + stay_date + channel_name)
5.  daily_hotel_roomtype        (hotel_name + stay_date + room_type_name)
6.  daily_hotel_mealplan        (hotel_name + stay_date + meal_plan_name)
7.  daily_pricing_strategy      (hotel_name + stay_date)
7b. daily_pricing_strategy_by_roomtype (hotel_name + stay_date + room_type_name)

-- Monthly facts
8.  monthly_hotel_summary       (hotel_name + year + month_num)
9.  monthly_hotel_segment       (hotel_name + year + month_num + segment_name)
10. monthly_hotel_channel       (hotel_name + year + month_num + channel_name)
11. monthly_hotel_roomtype      (hotel_name + year + month_num + room_type_name)
12. monthly_hotel_mealplan      (hotel_name + year + month_num + meal_plan_name)
13. monthly_hotel_guest_country (hotel_name + year + month_num + country_name)

-- Benchmark sectorial (independiente de hotel, carga separada)
14. benchmark_sectorial          (country + ccaa + province + zone + category + year + month_num)
```

### Multi-tenant

Cada hotel viene de un tenant distinto de PowerBI. El `hotel_name` es el identificador que conecta el tenant con la base de datos. Power Automate debe:

1. Antes de cargar facts, asegurar que `dim_hotels` tiene el hotel (UPSERT por `hotel_name`)
2. Usar ese mismo `hotel_name` (texto) en todas las cargas de facts

No se necesita resolución de IDs numéricos. Todas las claves son texto.

### LY y SDLY son relativos al año de la stay_date

**Esto es crítico**: el año de referencia para LY y SDLY **siempre** es el año anterior al de la `stay_date` que se está analizando. No es fijo.

```
Si stay_date = 2026-07-15:
  → SDLY Gross/Net = foto del mismo día de la semana de julio 2025
  → LY = dato final cristalizado de 2025-07-15

Si stay_date = 2027-03-10:
  → SDLY Gross/Net = foto del mismo día de la semana de marzo 2026
  → LY = dato final cristalizado de 2026-03-10

Si stay_date = 2025-12-20 (año anterior en la ventana):
  → SDLY Gross/Net = foto del mismo día de la semana de diciembre 2024
  → LY = dato final cristalizado de 2024-12-20
```

PowerBI calcula estos campos mirando siempre al año anterior de cada `stay_date`. La base de datos no necesita saber "qué año es el actual" — cada fila lleva su propia comparativa embebida.

### Ventana de 3 años

La base de datos mantiene siempre **año anterior + año actual + año siguiente**. En 2026:
- 2025 (cerrado, con LY referenciando 2024)
- 2026 (actual, con SDLY/LY referenciando 2025)
- 2027 (futuro, reservas OTB + forecast)

Al cambiar de año (1 de enero), Power Automate debe:
1. DELETE datos donde `stay_date` pertenece al año que sale de la ventana (ej: 2024 al entrar en 2027)
2. Continuar cargando normalmente los 3 años activos

---

## UPSERT por tabla

### 1. `dim_hotels`

**Clave UPSERT**: `hotel_name` (PRIMARY KEY)

> `hotel_name VARCHAR(200)` es la clave primaria. No existe `hotel_id` ni `hotel_code`.
> Solo se cargan `hotel_name` y `active` desde PowerBI.
> Los campos descriptivos se configuran desde el formulario ⚙️ en la cabecera (no desde el chat).

```sql
INSERT INTO dim_hotels (hotel_name, active)
VALUES ($1, $2)
ON CONFLICT (hotel_name) DO UPDATE SET
    active     = EXCLUDED.active,
    updated_at = NOW();
-- NO sobrescribir campos de onboarding (hotel_type, benchmark_category, etc.)
```

**Importante**: El UPSERT solo actualiza `active`. Los campos descriptivos configurados por el usuario desde el formulario ⚙️ **nunca se sobrescriben** por la carga de PowerBI.

---

### 2. `daily_hotel_summary`

**Clave UPSERT**: `hotel_name` + `stay_date`

```sql
INSERT INTO daily_hotel_summary (
    hotel_name, stay_date,
    -- OTB
    rn_otb, revenue_otb, adr_otb,
    -- OTB Projected
    rn_otb_proj, revenue_otb_proj, adr_otb_proj,
    -- SDLY Gross
    rn_sdly_gross, revenue_sdly_gross, adr_sdly_gross,
    -- SDLY Net
    rn_sdly_net, revenue_sdly_net, adr_sdly_net,
    -- LY
    rn_ly, revenue_ly, adr_ly,
    -- Forecast
    rn_forecast, revenue_forecast, adr_forecast,
    -- Budget
    rn_budget, revenue_budget, adr_budget,
    -- Capacity
    rooms_available,
    -- Occupancies
    occ_otb, occ_otb_proj, occ_sdly_gross, occ_sdly_net, occ_ly, occ_forecast, occ_budget,
    -- Pickup 7d
    pickup_rn_7d, pickup_rev_7d, pickup_rn_7d_sdly, pickup_rev_7d_sdly,
    -- Pickup 1d
    pickup_rn_1d, pickup_rev_1d, pickup_rn_1d_sdly, pickup_rev_1d_sdly,
    -- Cancel window
    cancel_rn_7d, cancel_rev_7d, cancel_rn_1d, cancel_rev_1d,
    -- Cancel cumulative rates
    cancel_rate_otb,
    cancel_rate_sdly,
    cancel_rate_ly
)
VALUES ($1, $2, $3, ... )
ON CONFLICT (hotel_name, stay_date) DO UPDATE SET
    rn_otb              = EXCLUDED.rn_otb,
    revenue_otb         = EXCLUDED.revenue_otb,
    adr_otb             = EXCLUDED.adr_otb,
    rn_otb_proj         = EXCLUDED.rn_otb_proj,
    revenue_otb_proj    = EXCLUDED.revenue_otb_proj,
    adr_otb_proj        = EXCLUDED.adr_otb_proj,
    rn_sdly_gross       = EXCLUDED.rn_sdly_gross,
    revenue_sdly_gross  = EXCLUDED.revenue_sdly_gross,
    adr_sdly_gross      = EXCLUDED.adr_sdly_gross,
    rn_sdly_net         = EXCLUDED.rn_sdly_net,
    revenue_sdly_net    = EXCLUDED.revenue_sdly_net,
    adr_sdly_net        = EXCLUDED.adr_sdly_net,
    rn_ly               = EXCLUDED.rn_ly,
    revenue_ly          = EXCLUDED.revenue_ly,
    adr_ly              = EXCLUDED.adr_ly,
    rn_forecast         = EXCLUDED.rn_forecast,
    revenue_forecast    = EXCLUDED.revenue_forecast,
    adr_forecast        = EXCLUDED.adr_forecast,
    rn_budget           = EXCLUDED.rn_budget,
    revenue_budget      = EXCLUDED.revenue_budget,
    adr_budget          = EXCLUDED.adr_budget,
    rooms_available     = EXCLUDED.rooms_available,
    occ_otb             = EXCLUDED.occ_otb,
    occ_otb_proj        = EXCLUDED.occ_otb_proj,
    occ_sdly_gross      = EXCLUDED.occ_sdly_gross,
    occ_sdly_net        = EXCLUDED.occ_sdly_net,
    occ_ly              = EXCLUDED.occ_ly,
    occ_forecast        = EXCLUDED.occ_forecast,
    occ_budget          = EXCLUDED.occ_budget,
    pickup_rn_7d        = EXCLUDED.pickup_rn_7d,
    pickup_rev_7d       = EXCLUDED.pickup_rev_7d,
    pickup_rn_7d_sdly   = EXCLUDED.pickup_rn_7d_sdly,
    pickup_rev_7d_sdly  = EXCLUDED.pickup_rev_7d_sdly,
    pickup_rn_1d        = EXCLUDED.pickup_rn_1d,
    pickup_rev_1d       = EXCLUDED.pickup_rev_1d,
    pickup_rn_1d_sdly   = EXCLUDED.pickup_rn_1d_sdly,
    pickup_rev_1d_sdly  = EXCLUDED.pickup_rev_1d_sdly,
    cancel_rn_7d        = EXCLUDED.cancel_rn_7d,
    cancel_rev_7d       = EXCLUDED.cancel_rev_7d,
    cancel_rn_1d        = EXCLUDED.cancel_rn_1d,
    cancel_rev_1d       = EXCLUDED.cancel_rev_1d,
    cancel_rate_otb     = EXCLUDED.cancel_rate_otb,
    cancel_rate_sdly    = EXCLUDED.cancel_rate_sdly,
    cancel_rate_ly      = EXCLUDED.cancel_rate_ly,
    updated_at          = NOW();
```

---

### 3-6. Dimensionales diarias: `daily_hotel_segment` / `channel` / `roomtype` / `mealplan`

Todas las tablas dimensionales diarias llevan el **mismo set completo de métricas** que
`daily_hotel_summary`. Se muestra `daily_hotel_segment` como ejemplo:

**Clave UPSERT**: `hotel_name` + `stay_date` + `segment_name` (o `channel_name` / `room_type_name` / `meal_plan_name`)

```sql
INSERT INTO daily_hotel_segment (
    hotel_name, stay_date, segment_name,
    -- OTB
    rn_otb, revenue_otb, adr_otb,
    -- OTB Projected
    rn_otb_proj, revenue_otb_proj, adr_otb_proj,
    -- SDLY Gross
    rn_sdly_gross, revenue_sdly_gross, adr_sdly_gross,
    -- SDLY Net
    rn_sdly_net, revenue_sdly_net, adr_sdly_net,
    -- LY
    rn_ly, revenue_ly, adr_ly,
    -- Forecast
    rn_forecast, revenue_forecast, adr_forecast,
    -- Budget
    rn_budget, revenue_budget, adr_budget,
    -- Occupancy (vs hotel total rooms_available, except roomtype which uses its own)
    occ_otb, occ_otb_proj, occ_sdly_gross, occ_sdly_net, occ_ly, occ_forecast, occ_budget,
    -- Pickup 7d
    pickup_rn_7d, pickup_rev_7d, pickup_rn_7d_sdly, pickup_rev_7d_sdly,
    -- Pickup 1d
    pickup_rn_1d, pickup_rev_1d, pickup_rn_1d_sdly, pickup_rev_1d_sdly,
    -- Cancel window
    cancel_rn_7d, cancel_rev_7d, cancel_rn_1d, cancel_rev_1d,
    -- Cancel cumulative rates
    cancel_rate_otb,
    cancel_rate_sdly,
    cancel_rate_ly
)
VALUES ($1, $2, $3, ...)
ON CONFLICT (hotel_name, stay_date, segment_name) DO UPDATE SET
    rn_otb             = EXCLUDED.rn_otb,
    revenue_otb        = EXCLUDED.revenue_otb,
    adr_otb            = EXCLUDED.adr_otb,
    rn_otb_proj        = EXCLUDED.rn_otb_proj,
    revenue_otb_proj   = EXCLUDED.revenue_otb_proj,
    adr_otb_proj       = EXCLUDED.adr_otb_proj,
    rn_sdly_gross      = EXCLUDED.rn_sdly_gross,
    revenue_sdly_gross = EXCLUDED.revenue_sdly_gross,
    adr_sdly_gross     = EXCLUDED.adr_sdly_gross,
    rn_sdly_net        = EXCLUDED.rn_sdly_net,
    revenue_sdly_net   = EXCLUDED.revenue_sdly_net,
    adr_sdly_net       = EXCLUDED.adr_sdly_net,
    rn_ly              = EXCLUDED.rn_ly,
    revenue_ly         = EXCLUDED.revenue_ly,
    adr_ly             = EXCLUDED.adr_ly,
    rn_forecast        = EXCLUDED.rn_forecast,
    revenue_forecast   = EXCLUDED.revenue_forecast,
    adr_forecast       = EXCLUDED.adr_forecast,
    rn_budget          = EXCLUDED.rn_budget,
    revenue_budget     = EXCLUDED.revenue_budget,
    adr_budget         = EXCLUDED.adr_budget,
    occ_otb            = EXCLUDED.occ_otb,
    occ_otb_proj       = EXCLUDED.occ_otb_proj,
    occ_sdly_gross     = EXCLUDED.occ_sdly_gross,
    occ_sdly_net       = EXCLUDED.occ_sdly_net,
    occ_ly             = EXCLUDED.occ_ly,
    occ_forecast       = EXCLUDED.occ_forecast,
    occ_budget         = EXCLUDED.occ_budget,
    pickup_rn_7d       = EXCLUDED.pickup_rn_7d,
    pickup_rev_7d      = EXCLUDED.pickup_rev_7d,
    pickup_rn_7d_sdly  = EXCLUDED.pickup_rn_7d_sdly,
    pickup_rev_7d_sdly = EXCLUDED.pickup_rev_7d_sdly,
    pickup_rn_1d       = EXCLUDED.pickup_rn_1d,
    pickup_rev_1d      = EXCLUDED.pickup_rev_1d,
    pickup_rn_1d_sdly  = EXCLUDED.pickup_rn_1d_sdly,
    pickup_rev_1d_sdly = EXCLUDED.pickup_rev_1d_sdly,
    cancel_rn_7d       = EXCLUDED.cancel_rn_7d,
    cancel_rev_7d      = EXCLUDED.cancel_rev_7d,
    cancel_rn_1d       = EXCLUDED.cancel_rn_1d,
    cancel_rev_1d      = EXCLUDED.cancel_rev_1d,
    cancel_rate_otb    = EXCLUDED.cancel_rate_otb,
    cancel_rate_sdly   = EXCLUDED.cancel_rate_sdly,
    cancel_rate_ly     = EXCLUDED.cancel_rate_ly,
    updated_at         = NOW();

-- Para daily_hotel_channel:  reemplazar segment_name por channel_name en clave e INSERT
-- Para daily_hotel_roomtype: reemplazar segment_name por room_type_name + añadir rooms_available
-- Para daily_hotel_mealplan: reemplazar segment_name por meal_plan_name
```

---

### 7. `daily_pricing_strategy`

**Clave UPSERT**: `hotel_name` + `stay_date`

```sql
INSERT INTO daily_pricing_strategy (
    hotel_name, stay_date,
    close_intermediaries,
    price_delta,
    rooms_remaining, rooms_remaining_diff_prev, rooms_remaining_diff_next
)
VALUES ($1, $2, $3, $4, $5, $6, $7)
ON CONFLICT (hotel_name, stay_date) DO UPDATE SET
    close_intermediaries      = EXCLUDED.close_intermediaries,
    price_delta               = EXCLUDED.price_delta,
    rooms_remaining           = EXCLUDED.rooms_remaining,
    rooms_remaining_diff_prev = EXCLUDED.rooms_remaining_diff_prev,
    rooms_remaining_diff_next = EXCLUDED.rooms_remaining_diff_next,
    updated_at                = NOW();
```

---

### 7b. `daily_pricing_strategy_by_roomtype`

**Clave UPSERT**: `hotel_name` + `stay_date` + `room_type_name`

> Mismas 3 palancas que `daily_pricing_strategy`, pero desglosadas por **tipo de habitación**.
> Para hoteles que gestionan cada tipo de habitación como un "sub-hotel" independiente,
> con sus propios precios, estancias mínimas y cierres parciales.
>
> `room_type_name` es texto libre embebido directamente (misma nomenclatura que `daily_hotel_roomtype`).
> No todos los hoteles tendrán datos en esta tabla — solo los que gestionan pricing por tipología.

```sql
INSERT INTO daily_pricing_strategy_by_roomtype (
    hotel_name, stay_date, room_type_name,
    close_intermediaries,
    price_delta,
    rooms_remaining, rooms_remaining_diff_prev, rooms_remaining_diff_next
)
VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
ON CONFLICT (hotel_name, stay_date, room_type_name) DO UPDATE SET
    close_intermediaries      = EXCLUDED.close_intermediaries,
    price_delta               = EXCLUDED.price_delta,
    rooms_remaining           = EXCLUDED.rooms_remaining,
    rooms_remaining_diff_prev = EXCLUDED.rooms_remaining_diff_prev,
    rooms_remaining_diff_next = EXCLUDED.rooms_remaining_diff_next,
    updated_at                = NOW();
```

---

### 8. `monthly_hotel_summary`

**Clave UPSERT**: `hotel_name` + `year` + `month_num`

```sql
INSERT INTO monthly_hotel_summary (
    hotel_name, year, month_num,
    rooms_available,
    -- OTB
    rn_otb, revenue_otb, adr_otb, occ_otb,
    -- OTB Proj
    rn_otb_proj, revenue_otb_proj, adr_otb_proj, occ_otb_proj,
    -- SDLY Gross
    rn_sdly_gross, revenue_sdly_gross, adr_sdly_gross, occ_sdly_gross,
    -- SDLY Net
    rn_sdly_net, revenue_sdly_net, adr_sdly_net, occ_sdly_net,
    -- LY
    rn_ly, revenue_ly, adr_ly, occ_ly,
    -- Forecast
    rn_forecast, revenue_forecast, adr_forecast, occ_forecast,
    -- Budget
    rn_budget, revenue_budget, adr_budget, occ_budget,
    -- Pickup
    pickup_rn_7d, pickup_rev_7d, pickup_rn_7d_sdly, pickup_rev_7d_sdly,
    pickup_rn_1d, pickup_rev_1d, pickup_rn_1d_sdly, pickup_rev_1d_sdly,
    -- Cancel window
    cancel_rn_7d, cancel_rev_7d, cancel_rn_1d, cancel_rev_1d,
    -- Cancel cumulative rates
    cancel_rate_otb,
    cancel_rate_sdly,
    cancel_rate_ly
)
VALUES ($1, $2, $3, ...)
ON CONFLICT (hotel_name, year, month_num) DO UPDATE SET
    rooms_available    = EXCLUDED.rooms_available,
    rn_otb             = EXCLUDED.rn_otb,
    revenue_otb        = EXCLUDED.revenue_otb,
    adr_otb            = EXCLUDED.adr_otb,
    occ_otb            = EXCLUDED.occ_otb,
    -- ... (todos los campos, mismo patrón)
    updated_at         = NOW();
```

> Para brevedad no se listan todos los campos del SET, pero el patrón es `campo = EXCLUDED.campo` para **todos** los campos excepto `hotel_name`, `year`, `month_num` (que son la clave) y `created_at` (que se mantiene original).

---

### 9-12. Mensuales dimensionales: `monthly_hotel_segment` / `channel` / `roomtype` / `mealplan`

Mismo patrón para las 4 tablas. Se muestra `monthly_hotel_segment` como ejemplo:

**Clave UPSERT**: `hotel_name` + `year` + `month_num` + `segment_name` (o `channel_name` / `room_type_name` / `meal_plan_name`)

```sql
INSERT INTO monthly_hotel_segment (
    hotel_name, year, month_num, segment_name,
    -- OTB
    rn_otb, revenue_otb, adr_otb,
    -- OTB Projected
    rn_otb_proj, revenue_otb_proj, adr_otb_proj,
    -- SDLY Gross
    rn_sdly_gross, revenue_sdly_gross, adr_sdly_gross,
    -- SDLY Net
    rn_sdly_net, revenue_sdly_net, adr_sdly_net,
    -- LY
    rn_ly, revenue_ly, adr_ly,
    -- Forecast
    rn_forecast, revenue_forecast, adr_forecast,
    -- Budget
    rn_budget, revenue_budget, adr_budget,
    -- Occupancy (vs hotel rooms_available, except roomtype which uses its own)
    occ_otb, occ_otb_proj, occ_sdly_gross, occ_sdly_net, occ_ly, occ_forecast, occ_budget,
    -- Pickup 7d
    pickup_rn_7d, pickup_rev_7d, pickup_rn_7d_sdly, pickup_rev_7d_sdly,
    -- Pickup 1d
    pickup_rn_1d, pickup_rev_1d, pickup_rn_1d_sdly, pickup_rev_1d_sdly,
    -- Cancel window
    cancel_rn_7d, cancel_rev_7d, cancel_rn_1d, cancel_rev_1d,
    -- Cancel cumulative rates
    cancel_rate_otb,
    cancel_rate_sdly,
    cancel_rate_ly,
    -- Shares
    share_rn_otb, share_revenue_otb
)
VALUES ($1, $2, $3, $4, ...)
ON CONFLICT (hotel_name, year, month_num, segment_name) DO UPDATE SET
    rn_otb             = EXCLUDED.rn_otb,
    revenue_otb        = EXCLUDED.revenue_otb,
    adr_otb            = EXCLUDED.adr_otb,
    rn_otb_proj        = EXCLUDED.rn_otb_proj,
    revenue_otb_proj   = EXCLUDED.revenue_otb_proj,
    adr_otb_proj       = EXCLUDED.adr_otb_proj,
    -- ... (todos los campos, mismo patrón campo = EXCLUDED.campo)
    share_rn_otb       = EXCLUDED.share_rn_otb,
    share_revenue_otb  = EXCLUDED.share_revenue_otb,
    updated_at         = NOW();

-- Para monthly_hotel_channel:  reemplazar segment_name por channel_name
-- Para monthly_hotel_roomtype: reemplazar segment_name por room_type_name + añadir rooms_available
-- Para monthly_hotel_mealplan: reemplazar segment_name por meal_plan_name
```

---

### 13. `monthly_hotel_guest_country`

**Clave UPSERT**: `hotel_name` + `year` + `month_num` + `country_name`

> Dato solo fiable para meses cerrados. Para meses abiertos/futuros, muchas reservas no tendrán país asignado (se asigna en el check-in). La tabla puede tener filas para meses futuros, pero los datos serán incompletos.
>
> `country_name` es texto libre embebido directamente (no FK a dimensión). Cada hotel puede usar su propia nomenclatura.

Mismo set completo de métricas que las tablas 9-12 (ver sección anterior).

```sql
INSERT INTO monthly_hotel_guest_country (
    hotel_name, year, month_num, country_name,
    -- Mismo set completo que monthly_hotel_segment (todos los grupos 1-12 + shares)
    rn_otb, revenue_otb, adr_otb,
    rn_otb_proj, revenue_otb_proj, adr_otb_proj,
    rn_sdly_gross, revenue_sdly_gross, adr_sdly_gross,
    rn_sdly_net, revenue_sdly_net, adr_sdly_net,
    rn_ly, revenue_ly, adr_ly,
    rn_forecast, revenue_forecast, adr_forecast,
    rn_budget, revenue_budget, adr_budget,
    occ_otb, occ_otb_proj, occ_sdly_gross, occ_sdly_net, occ_ly, occ_forecast, occ_budget,
    pickup_rn_7d, pickup_rev_7d, pickup_rn_7d_sdly, pickup_rev_7d_sdly,
    pickup_rn_1d, pickup_rev_1d, pickup_rn_1d_sdly, pickup_rev_1d_sdly,
    cancel_rn_7d, cancel_rev_7d, cancel_rn_1d, cancel_rev_1d,
    cancel_rate_otb,
    cancel_rate_sdly,
    cancel_rate_ly,
    share_rn_otb, share_revenue_otb
)
VALUES ($1, $2, $3, $4, ...)
ON CONFLICT (hotel_name, year, month_num, country_name) DO UPDATE SET
    rn_otb             = EXCLUDED.rn_otb,
    -- ... (todos los campos, mismo patrón campo = EXCLUDED.campo)
    share_revenue_otb  = EXCLUDED.share_revenue_otb,
    updated_at         = NOW();
```

---

### 14. `benchmark_sectorial`

**Clave UPSERT**: `country` + `ccaa` + `province` + `zone` + `category` + `year` + `month_num`

> Datos del sector (INE/fuentes del sector) por zona geográfica, categoría de hotel, mes y año.
> Incluye datos cristalizados para meses pasados y datos proyectados para meses futuros.
> No está vinculada a un hotel específico — es información del sector compartida.
>
> `category` debe ser uno de los valores de `benchmark_categories`: Economy, Midscale,
> Upper Midscale, Upscale, Upper Upscale, Luxury.
>
> **COBERTURA**: Actualmente solo España. Todas las combinaciones CCAA/Provincia/Zona de España
> están cubiertas. Para hoteles fuera de España no hay datos de benchmark — la IA busca en la web.
>
> **IMPORTANTE**: Esta tabla NO se carga por hotel/tenant. Se carga una vez con los datos del sector
> para todas las combinaciones geográficas disponibles. Puede cargarse desde un Power Automate
> dedicado o desde cualquier flujo que tenga acceso a los datos del sector.

```sql
INSERT INTO benchmark_sectorial (
    country, ccaa, province, zone, category,
    year, month_num,
    occ, adr, revpar,
    occ_ly, adr_ly, revpar_ly,
    yoy_occ, yoy_adr, yoy_revpar
)
VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16)
ON CONFLICT (country, ccaa, province, zone, category, year, month_num) DO UPDATE SET
    occ             = EXCLUDED.occ,
    adr             = EXCLUDED.adr,
    revpar          = EXCLUDED.revpar,
    occ_ly          = EXCLUDED.occ_ly,
    adr_ly          = EXCLUDED.adr_ly,
    revpar_ly       = EXCLUDED.revpar_ly,
    yoy_occ         = EXCLUDED.yoy_occ,
    yoy_adr         = EXCLUDED.yoy_adr,
    yoy_revpar      = EXCLUDED.yoy_revpar,
    updated_at      = NOW();
```

---

## Resumen de claves UPSERT

| Tabla | Clave UPSERT | Campos clave |
|-------|-------------|--------------|
| `dim_hotels` | `hotel_name` | hotel_name |
| `daily_hotel_summary` | `hotel_name, stay_date` | hotel_name + stay_date |
| `daily_hotel_segment` | `hotel_name, stay_date, segment_name` | hotel_name + stay_date + segment_name |
| `daily_hotel_channel` | `hotel_name, stay_date, channel_name` | hotel_name + stay_date + channel_name |
| `daily_hotel_roomtype` | `hotel_name, stay_date, room_type_name` | hotel_name + stay_date + room_type_name |
| `daily_hotel_mealplan` | `hotel_name, stay_date, meal_plan_name` | hotel_name + stay_date + meal_plan_name |
| `daily_pricing_strategy` | `hotel_name, stay_date` | hotel_name + stay_date |
| `daily_pricing_strategy_by_roomtype` | `hotel_name, stay_date, room_type_name` | hotel_name + stay_date + room_type_name |
| `monthly_hotel_summary` | `hotel_name, year, month_num` | hotel_name + year + month_num |
| `monthly_hotel_segment` | `hotel_name, year, month_num, segment_name` | hotel_name + year + month_num + segment_name |
| `monthly_hotel_channel` | `hotel_name, year, month_num, channel_name` | hotel_name + year + month_num + channel_name |
| `monthly_hotel_roomtype` | `hotel_name, year, month_num, room_type_name` | hotel_name + year + month_num + room_type_name |
| `monthly_hotel_mealplan` | `hotel_name, year, month_num, meal_plan_name` | hotel_name + year + month_num + meal_plan_name |
| `monthly_hotel_guest_country` | `hotel_name, year, month_num, country_name` | hotel_name + year + month_num + country_name |
| `benchmark_sectorial` | `country, ccaa, province, zone, category, year, month_num` | country + ccaa + province + zone + category + year + month_num |

---

## Carga de un tenant nuevo

Cuando Power Automate carga datos de un tenant nuevo, el proceso es simple porque todas las claves son texto:

### Paso 1: Asegurar hotel existe

```sql
INSERT INTO dim_hotels (hotel_name, active)
VALUES ('Hotel Nuevo Ejemplo', TRUE)
ON CONFLICT (hotel_name) DO UPDATE SET
    active     = EXCLUDED.active,
    updated_at = NOW();
```

### Paso 2: Cargar facts directamente con texto

No se necesita resolución de IDs numéricos. Todos los campos dimensionales (segmentos, canales, tipos de habitación, planes de comida, países) se envían como texto directamente en cada fila de facts.

```sql
-- Ejemplo: cargar un hecho diario por segmento
INSERT INTO daily_hotel_segment (
    hotel_name, stay_date, segment_name,
    rn_otb, revenue_otb, adr_otb, ...
)
VALUES ('Hotel Nuevo Ejemplo', '2026-07-15', 'Individual', 42, 8400.00, 200.00, ...);

-- Ejemplo: cargar un hecho diario por canal
INSERT INTO daily_hotel_channel (
    hotel_name, stay_date, channel_name,
    rn_otb, revenue_otb, adr_otb, ...
)
VALUES ('Hotel Nuevo Ejemplo', '2026-07-15', 'Booking.com', 30, 6000.00, 200.00, ...);

-- Ejemplo: cargar un hecho mensual por tipo de habitación
INSERT INTO monthly_hotel_roomtype (
    hotel_name, year, month_num, room_type_name,
    rn_otb, revenue_otb, adr_otb, ...
)
VALUES ('Hotel Nuevo Ejemplo', 2026, 7, 'Doble Estándar', 500, 100000.00, 200.00, ...);
```

> **Ventaja clave**: Power Automate no necesita hacer SELECTs previos para obtener IDs numéricos. Simplemente envía los nombres de texto tal como vienen de PowerBI, y el UPSERT se encarga de insertar o actualizar.

---

## Notas para Power Automate

1. **Sin resolución de IDs**: Todas las claves son texto (`hotel_name`, `segment_name`, `channel_name`, `room_type_name`, `meal_plan_name`, `country_name`). Power Automate envía los nombres tal como vienen de PowerBI, sin necesidad de consultas previas para obtener IDs numéricos
2. **Solo una dimensión**: La única tabla de dimensiones es `dim_hotels`. Debe existir el hotel antes de cargar facts. Las demás dimensiones (segmentos, canales, etc.) se almacenan como texto embebido en las tablas de hechos
3. **Batch**: Enviar las filas en lotes (ej: 100-500 filas por transacción) para rendimiento óptimo
4. **Transacciones**: Cada lote dentro de `BEGIN/COMMIT` para consistencia
5. **Idempotencia**: Gracias al UPSERT, si la carga falla a mitad y se reintenta, no se duplican datos
6. **Timestamps**: `updated_at = NOW()` se ejecuta en el servidor PostgreSQL, no depende del reloj del cliente
7. **NULL handling**: Los campos que pueden ser NULL (SDLY, LY, Budget, cancel_rate_sdly, cancel_rate_ly) se envían como NULL cuando no hay datos. **No enviar 0 cuando no hay datos** -- NULL significa "no disponible", 0 significa "cero real"

---

## Multi-tenant: Múltiples Power Automate desde distintos tenants Microsoft

Revtool soporta cargas simultáneas desde múltiples tenants de Microsoft. Cada tenant tiene
su propio Power Automate que ejecuta a horas diferentes, escribiendo en la misma base de datos.

### Por qué es seguro

```
Tenant A (hotel.com)          Tenant B (resort.es)
├── PowerBI con 5 hoteles     ├── PowerBI con 3 hoteles
├── Power Automate: 6:00 AM   ├── Power Automate: 8:00 AM
└── Escribe:                  └── Escribe:
    Hotel Playa Dorada            Hotel Costa Brava
    Hotel Sierra Nevada           Hotel Pirineos Resort
    Hotel Costa Luz               Hotel Delta del Ebro
    Hotel Playa Tropical
    Hotel Sierra Blanca
         │                              │
         └──────────┬───────────────────┘
                    ▼
         PostgreSQL (misma BD)
         UPSERT por hotel_name (cada hotel es único)
```

1. **UPSERT por `hotel_name`**: Cada hotel tiene un nombre globalmente único. Cada tenant escribe solo SUS hoteles. Nunca se pisan.
2. **Sin dependencias cruzadas**: Los datos del Hotel A no dependen de los del Hotel B. Cada hotel es autocontenido.
3. **PostgreSQL row-level locking**: UPSERTs concurrentes en distintos hoteles no se bloquean entre sí.
4. **Idempotente**: Si un Power Automate falla a mitad y se reintenta, el UPSERT sobrescribe con los mismos datos.
5. **El orden no importa**: Tenant A a las 6 AM, Tenant B a las 8 AM. Cada hotel recibe sus datos completos independientemente.

### Requisito implícito

**`hotel_name` debe ser globalmente único entre todos los tenants.** Si dos tenants tuvieran un hotel con el mismo nombre exacto, el segundo en escribir sobreescribiría al primero. Esto es fácil de evitar porque los nombres comerciales de hoteles son naturalmente únicos.

### Proceso diario completo (ejemplo con 2 tenants)

```
06:00  Tenant A → PowerBI refresca datos de sus 5 hoteles
06:15  Tenant A → Power Automate arranca:
       1. UPSERT dim_hotels (5 hoteles)
       2. UPSERT daily_hotel_summary (5 hoteles × ~365 stay_dates)
       3. UPSERT daily_hotel_segment (5 hoteles × dates × segments)
       4. ... (resto de tablas)
       5. SYNC user_hotel_access (usuarios del Tenant A)
06:45  Tenant A → Carga completa. Usuarios de Tenant A ven datos frescos.

08:00  Tenant B → PowerBI refresca datos de sus 3 hoteles
08:10  Tenant B → Power Automate arranca:
       1. UPSERT dim_hotels (3 hoteles — NO toca los de Tenant A)
       2. UPSERT daily_hotel_summary (3 hoteles)
       3. ... (resto de tablas)
       4. SYNC user_hotel_access (usuarios del Tenant B)
08:30  Tenant B → Carga completa.

→ Resultado: Los 8 hoteles tienen datos actualizados. Cada usuario ve
  solo los hoteles a los que tiene acceso (via user_hotel_access).
```

### Sync de `user_hotel_access` (NO usar TRUNCATE)

`user_hotel_access` tiene una FK desde `email_report_subscriptions` con `ON DELETE CASCADE`.
Si se hace TRUNCATE, se borran **todas** las suscripciones de email. En su lugar,
usamos `sync_user_hotel_access()` que solo elimina los accesos revocados y añade los nuevos.

**SQL desde Power Automate (ejemplo Tenant A con 5 hoteles):**

```sql
-- 1. Crear tabla temporal con los datos frescos de PowerBI
CREATE TEMP TABLE _uha_staging (
    upn         VARCHAR(200),
    hotel_name  VARCHAR(200)
);

-- 2. Insertar TODOS los registros del tenant
INSERT INTO _uha_staging (upn, hotel_name) VALUES
    ('usuario1@hotel.com', 'Hotel Playa Dorada'),
    ('usuario1@hotel.com', 'Hotel Sierra Nevada'),
    ('usuario2@hotel.com', 'Hotel Playa Dorada'),
    -- ... todos los pares upn+hotel del tenant
    ('admin@hotel.com',    'Hotel Costa Luz');

-- 3. Ejecutar sync (pasar array de hoteles del tenant para no tocar otros tenants)
SELECT * FROM sync_user_hotel_access(
    ARRAY['Hotel Playa Dorada', 'Hotel Sierra Nevada', 'Hotel Costa Luz',
          'Hotel Playa Tropical', 'Hotel Sierra Blanca']
);
-- Devuelve: deleted_count (accesos revocados) | inserted_count (accesos nuevos)

-- 4. La tabla temporal se borra sola al cerrar la conexión
```

**Qué hace internamente:**
1. **DELETE** de `user_hotel_access` los pares `(upn, hotel_name)` que YA NO están en staging → `ON DELETE CASCADE` borra automáticamente sus suscripciones en `email_report_subscriptions`
2. **INSERT** los nuevos pares que no existían → `ON CONFLICT DO NOTHING` para idempotencia
3. Los pares que no cambiaron → intactos, sus suscripciones se conservan

**Importante:** Pasar siempre `p_tenant_hotels` con la lista de hoteles del tenant para que el sync no toque los accesos de otros tenants.
