# Revtool AI - Data Dictionary

## Key Metrics Glossary

| Metric | Abbreviation | Description |
|--------|-------------|-------------|
| Room Nights | RN | Number of room-nights booked |
| Average Daily Rate | ADR | Revenue / Room Nights (gross package pre-stay) |
| Revenue | REV | Total gross package revenue (accommodation + board, pre-stay valuation) |
| Occupancy | OCC | Room Nights / Available Room Nights x 100 |
| Cancellation Rate | CANCEL% | Cancelled RN / (OTB RN + Cancelled RN) x 100 |
| Pickup | PICKUP | New confirmed bookings in a given period (NO cancellations) |

## ADR: What It Means in Revtool

The ADR is the **gross package value in pre-stay**:
- Includes accommodation + meal plan/board (not accommodation-only)
- Is the invoice amount to the client/agency as per the reservation
- Booking.com ADR includes their ~17% commission (what the hotel invoices including commission)
- Tour operator ADR does NOT include the TO's margin (what the hotel invoices the TO)
- Direct channel ADR is clean (no intermediary)
- **Never adjusted for commissions** — higher gross ADR = more cash-in = better, regardless of commission structure
- **No post-stay adjustments**: no regularizations, no upgrades, no no-show penalties
- This is a **pre-stay only** metric: compares what bookings were worth before guests arrived

## Comparison Bases

| Base | Code | Logic | Used For |
|------|------|-------|----------|
| On The Books | OTB | Current live bookings from PMS (raw, unmodified) | Present state — what the user recognizes |
| OTB Projected | OTB_PROJ | OTB adjusted by Revtool's cancellation model | AI internal reasoning (NEVER shown to user as "their data") |
| SDLY Gross | SDLY_GROSS | Same point last year, raw (includes future cancellations) | Traditional RM comparison |
| SDLY Net | SDLY_NET | Same point last year, adjusted for known cancellations | Fair comparison vs OTB Projected |
| Last Year | LY | Same calendar date, prior year (crystallized, inherently net) | Closed months, final reality |
| Forecast | FC | Predicted final close value | Future months performance expectation |
| Budget | BDG | Hotel's loaded budget targets | Performance vs plan |

## SDLY Gross vs SDLY Net: The Revtool Approach

Traditional RM uses a single SDLY. Revtool provides two:

- **SDLY Gross**: What was in the books at the same point last year, including reservations that later cancelled. This is what a traditional RMS would show.
- **SDLY Net**: Same snapshot, but minus the cancellations that were already known at that point. This removes the "noise" of bookings that were never going to materialize.

**Why both?**
- `OTB vs SDLY Gross` → the traditional view (for users who want the classic comparison)
- `OTB Projected vs SDLY Net` → the fair, real comparison (for AI reasoning: "how are we REALLY doing vs last year?")

## SDLY vs LY: When to Use Which

- **SDLY (Same Day Last Year)**: For months that are NOT yet closed. Compares the current booking pace with where we were at the same point last year, matching day-of-week. This accounts for booking patterns being different on weekdays vs weekends.
  - Example: Monday February 10, 2026 compares with Monday February 10, 2025 (both Mondays).

- **LY (Last Year)**: For months that ARE closed/crystallized. Compares final results with the same calendar month last year.
  - Example: January 2026 closed at 5,000 RN vs January 2025 closed at 4,800 RN.

## Pickup: Confirmed Only

Pickup measures **only confirmed new bookings** in a time window. Cancellations are tracked separately and never contaminate pickup numbers. This ensures:
- Pickup shows pure demand momentum
- Cancellations get their own analysis
- No confusion between "net pickup" (traditional, which mixes bookings and cancellations) and actual new business

## Table Relationships

```
dim_hotels (PK: hotel_name) ──┬── daily_hotel_summary
                              │── daily_hotel_segment      (segment_name embedded)
                              │── daily_hotel_channel       (channel_name embedded)
                              │── daily_hotel_roomtype      (room_type_name embedded)
                              │── daily_hotel_mealplan      (meal_plan_name embedded)
                              │── daily_pricing_strategy    (hotel-level signals)
                              │── daily_pricing_strategy_by_roomtype (room_type_name embedded)
                              │── monthly_hotel_summary
                              │── monthly_hotel_segment     (segment_name embedded)
                              │── monthly_hotel_channel      (channel_name embedded)
                              │── monthly_hotel_roomtype     (room_type_name embedded)
                              │── monthly_hotel_mealplan     (meal_plan_name embedded)
                              │── monthly_hotel_guest_country (country_name embedded)
                              └── user_hotel_access (upn + hotel_name, text keys)

benchmark_categories (PK: category_name)
    └── benchmark_sectorial (PK: country + ccaa + province + zone + category + year + month_num)
            └── v_hotel_benchmark (joins dim_hotels benchmark config → benchmark_sectorial)

users (PK: upn) ──┬── user_billing_profile (company data for invoicing, determines VAT)
                   ├── token_usage_log
                   ├── credit_balance
                   ├── credit_transactions
                   ├── stripe_customers
                   ├── sales_ledger (snapshot of billing data per topup, for ERP export)
                   └── conversation_summaries (PK: upn + summary_date, rolling 48h)
```

Note: There are no separate dimension tables for segments, channels, room types, or meal plans.
All dimensional names are embedded directly in the fact tables as text (e.g., `segment_name`,
`channel_name`, `room_type_name`, `meal_plan_name`). PowerBI sends the names from each hotel's
PMS, so naming may vary between hotels.

There is also no dim_calendar table. The AI resolves dates, holidays, and local events
dynamically from its own knowledge or via web search. All daily tables use a plain DATE
column (`stay_date`) that the AI filters with concrete date ranges.

## Aggregation Rules (Critical)

When aggregating daily data across a date range (event, week, custom period), derived metrics
must ALWAYS be recalculated from their base components. Never average percentages or ratios.

| Metric | Correct aggregation | WRONG aggregation |
|--------|--------------------|--------------------|
| Occupancy | `SUM(rn_otb) / SUM(rooms_available) * 100` | ~~`AVG(occ_otb)`~~ |
| ADR | `SUM(revenue_otb) / SUM(rn_otb)` | ~~`AVG(adr_otb)`~~ |
| Cancel rate | Weighted recalculation from base RN values (pre-calculated in PowerBI) | ~~`AVG(cancel_rate_otb)`~~ |

**Why it matters:** If Day 1 has 200 rooms available (80% occ) and Day 2 has 100 rooms available
(90% occ), the correct occupancy is 250/300 = 83.3%, not the average 85%.

The same rule applies to all comparison bases (SDLY Gross, SDLY Net, LY, Forecast, Budget).

RN and Revenue are additive metrics — they can be safely summed: `SUM(rn_otb)`, `SUM(revenue_otb)`.

## Sparse Data: Missing Days and Months (Critical)

The daily and monthly tables are **sparse** — not all dates or months will have rows for every hotel.

### Rule: Only days with inventory generate rows

`daily_hotel_summary` and `daily_hotel_roomtype` only contain rows for days where
`rooms_available > 0`. If a hotel is closed (seasonal closure, renovation, etc.),
those days simply don't exist in the database.

**Implications:**
- A hotel does NOT necessarily have 365 rows per year. It only has rows for the days it was open.
- When querying a date range, some dates may be absent. This is normal — it means the hotel
  was closed on those days.
- `SUM(rooms_available)` for a month automatically excludes closed days (they have no row).
- `COUNT(*)` on a date range gives the number of open days, not calendar days.

### Rule: Months without any open days don't exist

In `monthly_hotel_summary` and `monthly_hotel_roomtype`, a month only appears if there
is at least one day with `rooms_available > 0` in that month. If a hotel is closed for
an entire month (e.g., a seasonal hotel closed in January), that month won't have a row.

**Implications:**
- Not all 12 months will necessarily appear for every hotel.
- When querying months for a year, gaps are expected for seasonal hotels.
- Year-to-date aggregations must handle missing months naturally (they simply don't contribute).

### Rule: Daily roomtype sum ≠ Monthly summary (possible mismatch)

The sum of `daily_hotel_roomtype` across all days in a month does **not necessarily match**
the corresponding `monthly_hotel_summary` row for that month. This happens when:

- Not all room types have data for every day (a room type may be out of inventory on
  certain days but the hotel is still open with other room types)
- A room type is added or removed mid-month
- The PMS reports room types inconsistently across days

The `monthly_hotel_summary` is the authoritative source for hotel-level monthly totals.
The `daily_hotel_roomtype` and `monthly_hotel_roomtype` provide the room-type breakdown
but may have gaps due to small sample sizes at the disaggregated level.

## NULL and Zero Values: Interpretation by Field Type (Critical)

### SDLY fields (same point last year)

A **NULL** always means no historical data. A **0** is ambiguous and must be cross-referenced
with LY to determine its meaning:

| Situation | Meaning |
|-----------|---------|
| SDLY = NULL | No historical data — do not compare |
| SDLY = 0, LY > 0 | Historical data EXISTS. At this same point last year, the hotel had zero bookings for that date (hadn't started selling yet). This is a real data point. |
| SDLY = 0, LY = 0 or NULL | No historical data available — do not compare |

### LY fields (crystallized final result)

| Situation | Meaning |
|-----------|---------|
| LY = NULL | No data for the same calendar period last year |
| LY > 0 | Hotel had activity last year — reliable comparison point |
| LY = 0, SDLY also 0 or NULL | Likely no historical data |

### OTB fields (current bookings)

A **0** in OTB fields is a **real data point** when `stay_date >= today` (open date):
the hotel genuinely has zero bookings for that date. OTB fields are `NOT NULL DEFAULT 0`,
so they are never NULL.

| Value | Meaning |
|-------|---------|
| `rn_otb = 0` (future date) | No bookings yet — genuine zero, relevant signal |
| `rn_otb = 0` (past date) | Closed date with no room nights (crystallized result) |

### Other nullable fields

| Field is NULL | Meaning |
|---------------|---------|
| `rn_forecast`, `revenue_forecast` | No forecast has been calculated for this period |
| `rn_budget`, `revenue_budget` | Hotel has not loaded a budget for this period (may arrive later) |
| `cancel_rate_sdly`, `cancel_rate_ly` | Hotel lacks historical cancellation data for that comparison period |
| `dim_hotels.destination`, `city`, etc. | Hotel hasn't been configured yet (`setup_complete = FALSE`) |

The AI detects NULL and zero comparison data directly from query results and proactively informs users.
There are no static flags like `has_historical` or `has_budget` — data availability can change
over time as new data is loaded from PowerBI.

## Cumulative Cancellations: Rates Only

The cumulative cancellation fields have been simplified to store only the cancellation **rates**
(`cancel_rate_otb`, `cancel_rate_sdly`, `cancel_rate_ly`). The absolute values (cancel_rn and
cancel_rev for cumulative) are no longer stored in the fact tables.

- Cancellation rates are pre-calculated in PowerBI based on RN: `cancel_rn / (rn_otb + cancel_rn) × 100`
- The AI compares `cancel_rate_otb` vs `cancel_rate_sdly` vs `cancel_rate_ly` directly
- Recent cancellation windows (7d/1d) still include absolute RN and revenue values

### Sign Convention: Always Positive (Absolute Values)

All cancellation RN and revenue values (`cancel_rn_7d`, `cancel_rev_7d`, `cancel_rn_1d`,
`cancel_rev_1d`) are **always positive (absolute)**, never negative. They represent
**opportunity cost**: bookings that were originally confirmed but later cancelled. Those
room nights and their associated revenue did not materialize.

Example: `cancel_rn_7d = 5` means "5 room nights were cancelled in the last 7 days",
not "room nights decreased by -5".

## Hotel Configuration (Dedicated Form)

Hotels start with only `hotel_name` (the primary key of `dim_hotels`). Descriptive fields are
configured by users through a **dedicated web form** (⚙️ button in header). This avoids
consuming AI credits for configuration and scales well for users with many hotels.

### Hotel Descriptive Fields

| Field | Type | Values | Purpose |
|-------|------|--------|---------|
| `hotel_type` | VARCHAR | 'vacation', 'urban', 'mixed' | Typology — affects AI analysis context |
| `target_client` | VARCHAR | 'family', 'adults_only', 'mixed' | Target market — affects recommendations |
| `destination` | VARCHAR | Free text | Tourist destination for event resolution |
| `province` | VARCHAR | Free text | Province/region for geographical context |
| `city` | VARCHAR | Free text | City — used for local event resolution |
| `country` | VARCHAR | ISO code | Country code ('ES', 'PT', 'MX') |
| `total_rooms` | INT | Positive | Room inventory (optional, derivable from daily data) |
| `currency` | VARCHAR | ISO code | Operating currency ('EUR', 'USD') |

### Benchmark Configuration Fields (on dim_hotels)

| Field | Type | Values | Purpose |
|-------|------|--------|---------|
| `benchmark_category` | VARCHAR(30) | FK → benchmark_categories | Competitive set category (Economy, Midscale, Upper Midscale, Upscale, Upper Upscale, Luxury) |
| `benchmark_country` | VARCHAR(100) | 'España' or manual text | Country for sector comparison |
| `benchmark_ccaa` | VARCHAR(100) | From dropdown (ES) or manual | Comunidad Autónoma for sector comparison |
| `benchmark_province` | VARCHAR(100) | From dropdown (ES) or manual | Province for sector comparison |
| `benchmark_zone` | VARCHAR(100) | From dropdown (ES) or manual | Tourism zone for sector comparison |
| `benchmark_available` | BOOLEAN | TRUE/FALSE | TRUE = Spain (all combinations covered). FALSE = non-Spain, AI uses web search |

These fields are configured during hotel onboarding. The selection logic depends on the hotel's country:

- **Spain (ES):** All geographic combinations are covered in `benchmark_sectorial`. The form shows
  a single concatenated dropdown with `display_label` from `v_benchmark_geo` (format: "CCAA - Provincia - Zona").
  The user must select from existing options. `benchmark_available` is always `TRUE`.
- **Non-Spain:** No benchmark data exists. The user enters country, province, and zone as free text.
  `benchmark_available` is always `FALSE`. The AI searches the web for competitive set data.

### Setup Tracking

| Field | Type | Description |
|-------|------|-------------|
| `setup_complete` | BOOLEAN | `TRUE` once onboarding is finished. `FALSE` = pending |
| `setup_by` | VARCHAR | UPN of the user who completed the configuration |
| `setup_at` | TIMESTAMPTZ | When the configuration was completed |

### Rules
- Any user with access to a hotel can configure it
- Once configured by one user, all other users benefit (no re-prompting)
- The AI proposes onboarding at session start, but user can decline
- Room types, segments, channels, meal plans, and guest country names all come from PowerBI, embedded directly in fact tables as text (no separate dimension tables)

## Guest Country (Nationality)

Guest country data is available at **monthly level only** (`monthly_hotel_guest_country`).

There is **no dimension table** for guest countries. The `country_name` field is embedded directly
in the fact table as free text. PowerBI sends the country name from each hotel's PMS, so naming
may vary between hotels (e.g., one hotel might send "UK" and another "United Kingdom").

The table has the same metric structure as other monthly dimensional tables (OTB, SDLY Gross,
LY, Forecast, shares), but with a critical data quality limitation:

### Critical Limitation

| Month Status | Data Quality | AI Behavior |
|-------------|-------------|-------------|
| **Closed** (`is_closed = TRUE`) | Complete — all guests checked in | Full analysis available |
| **Open/Future** (`is_closed = FALSE`) | Incomplete — many bookings without country | Warn user about limitation |

- Guest nationality is typically assigned at **check-in**, not at booking time
- For future months, a large percentage of bookings will have no country assigned
- The AI must always warn when analyzing guest country for open months
- SDLY and Forecast fields are available in the schema, but for open months the OTB data is incomplete

## Benchmark Sectorial (Competitive Set Data)

Sector-level benchmark data loaded from PowerBI via Power Automate. Contains industry KPIs
aggregated by geographic area and hotel category, at monthly granularity.

### Tables

**`benchmark_categories`** — Fixed reference table

| Value | Sort Order |
|-------|-----------|
| Economy | 1 |
| Midscale | 2 |
| Upper Midscale | 3 |
| Upscale | 4 |
| Upper Upscale | 5 |
| Luxury | 6 |

**`benchmark_sectorial`** — Sector KPIs

| Field | Type | Description |
|-------|------|-------------|
| `country` | VARCHAR(100) | Country (e.g., 'España') — PK component |
| `ccaa` | VARCHAR(100) | Comunidad Autónoma (e.g., 'Andalucía') — PK component |
| `province` | VARCHAR(100) | Province (e.g., 'Málaga') — PK component |
| `zone` | VARCHAR(100) | Tourism zone (e.g., 'Costa del Sol') — PK component |
| `category` | VARCHAR(30) | FK → benchmark_categories — PK component |
| `year` | SMALLINT | Year — PK component |
| `month_num` | SMALLINT | Month (1-12) — PK component |
| `occ` | DECIMAL(5,2) | Sector occupancy % |
| `adr` | DECIMAL(10,2) | Sector ADR (EUR) |
| `revpar` | DECIMAL(10,2) | Sector RevPAR (EUR) |
| `occ_ly` | DECIMAL(5,2) | Sector occupancy % last year |
| `adr_ly` | DECIMAL(10,2) | Sector ADR last year |
| `revpar_ly` | DECIMAL(10,2) | Sector RevPAR last year |
| `yoy_occ` | DECIMAL(6,2) | Year-over-year occupancy (pp) |
| `yoy_adr` | DECIMAL(6,2) | Year-over-year ADR (%) |
| `yoy_revpar` | DECIMAL(6,2) | Year-over-year RevPAR (%) |

PK: `(country, ccaa, province, zone, category, year, month_num)`

### Data Characteristics

- **Past months**: crystallized actual values from industry sources (INE, etc.)
- **Future months**: projected/forecast values — useful for comparing hotel forecast vs sector projection
- **Coverage**: currently Spain only. All Spanish geographic combinations (CCAA/Provincia/Zona) are covered.
  Non-Spain hotels have no benchmark data — the AI falls back to web search
- **Loaded via Power Automate** from PowerBI, same ETL pattern as other tables

### Views

| View | Purpose |
|------|---------|
| `v_benchmark_geo` | DISTINCT (country, ccaa, province, zone, display_label) — populates single concatenated dropdown for Spain |
| `v_hotel_benchmark` | Joins hotel benchmark config with matching sector data — ready for AI queries |

### AI Behavior

- If `benchmark_available = TRUE`: AI queries `v_hotel_benchmark` for sector comparison
- If `benchmark_available = FALSE`: AI searches the web for competitive set data
- Both past (actual vs sector actual) and future (forecast vs sector projection) comparisons are possible

## Pricing Strategy — Two Levels

Revtool provides pricing signals at two granularity levels. Each hotel may have data in one or both, depending on how they manage their revenue strategy.

### Hotel Level: `daily_pricing_strategy`

One row per hotel + future stay date. Contains 3 operational levers at the hotel level. Suitable for hotels that use **derivation pricing** (base room price + derived room type markups).

| Field | Type | Description |
|-------|------|-------------|
| `hotel_name` | VARCHAR(200) | FK → dim_hotels |
| `stay_date` | DATE | Future stay date |
| `close_intermediaries` | BOOLEAN | Signal to close/filter OTA channels |
| `price_delta` | INT | Whole EUR to add/subtract from channel manager price |
| `rooms_remaining` | INT | Available rooms on that date |
| `rooms_remaining_diff_prev` | INT | Comparison to previous day |
| `rooms_remaining_diff_next` | INT | Comparison to next day |

PK: `(hotel_name, stay_date)`

### Room Type Level: `daily_pricing_strategy_by_roomtype`

One row per hotel + future stay date + room type. Contains the **same 3 operational levers** but at room type granularity. Suitable for hotels that manage each room type as an independent "sub-hotel" with its own pricing, minimum stays, and partial closures.

| Field | Type | Description |
|-------|------|-------------|
| `hotel_name` | VARCHAR(200) | FK → dim_hotels |
| `stay_date` | DATE | Future stay date |
| `room_type_name` | VARCHAR(100) | Room type name (text, same naming as `daily_hotel_roomtype`) |
| `close_intermediaries` | BOOLEAN | Signal to close/filter OTA channels for this room type |
| `price_delta` | INT | Whole EUR to add/subtract for this room type |
| `rooms_remaining` | INT | Available rooms of this type on that date |
| `rooms_remaining_diff_prev` | INT | Comparison to previous day for this room type |
| `rooms_remaining_diff_next` | INT | Comparison to next day for this room type |

PK: `(hotel_name, stay_date, room_type_name)`

### When to use which

| Hotel approach | Table to use | Description |
|---------------|-------------|-------------|
| **Derivation** | `daily_pricing_strategy` | Hotel sets a base room price; other room types derive from it (e.g., double = base, superior = base + 20€). One price signal for the whole hotel. |
| **By room type** | `daily_pricing_strategy_by_roomtype` | Hotel manages each room type independently. Each type has its own demand rhythm, booking pace, and needs its own signals. |

The AI must ask the user which level they want when they ask about pricing recommendations, minimum stays, or channel closures. If only one table has data for a given hotel, the AI uses that one directly without asking.

### Views

| View | Source | Purpose |
|------|--------|---------|
| `v_pricing_strategy` | daily_pricing_strategy + dim_hotels | Hotel-level pricing signals (future dates only) |
| `v_pricing_strategy_by_roomtype` | daily_pricing_strategy_by_roomtype + dim_hotels | Room-type pricing signals (future dates only) |

## Analysis Modes

| Mode | Trigger | AI Behavior |
|------|---------|-------------|
| **Hotel** (operational) | 1 hotel selected | Action-oriented RM: pricing, distribution, min stay, pickup analysis |
| **Group** (portfolio) | 2+ hotels selected | Portfolio advisor: comparisons, rankings, patterns, aggregates |

The user can switch between modes dynamically during a session by changing the hotel selection.
The `analysis_mode` field in `token_usage_log` records which mode was active for each interaction.

## User Billing Profile

Each user must complete their billing profile before making topups. The profile stores company data for invoicing and determines VAT treatment.

### Table: `user_billing_profile`

| Field | Type | Description |
|-------|------|-------------|
| `upn` | VARCHAR(200) | PK, FK → users. The user who owns this profile |
| `company_name` | VARCHAR(300) | Company legal name |
| `tax_id` | VARCHAR(30) | NIF / CIF / VAT number |
| `notification_email` | VARCHAR(300) | Email for invoices and communications (NOT the UPN) |
| `address_line` | VARCHAR(500) | Fiscal address |
| `city` | VARCHAR(200) | City |
| `province` | VARCHAR(200) | Province (dropdown for Spain, free text for others) |
| `postal_code` | VARCHAR(20) | Postal code (optional) |
| `country` | VARCHAR(100) | Country |
| `vat_applicable` | BOOLEAN | **Generated column**: TRUE if country=España AND province NOT IN (Las Palmas, Santa Cruz de Tenerife, Ceuta, Melilla) |

### VAT Treatment

| vat_applicable | VAT rate | Meaning |
|:--------------:|:--------:|---------|
| TRUE | 21% (configurable) | Spain mainland + Balearic Islands. Credits = payment / 1.21 |
| FALSE | 0% | Canarias, Ceuta, Melilla, or any other country. Credits = full payment |

## Credit System

| Concept | Description |
|---------|-------------|
| **Balance** | Prepaid EUR balance. If ≤ 0, chat is blocked. |
| **Topup** | User adds EUR via Stripe. Credits loaded = base amount (net of VAT). `credit_transactions.type = 'topup'` |
| **Consumption** | Each AI interaction deducts from balance. `credit_transactions.type = 'consumption'` |
| **Cost formula** | `cost_eur = (tokens/1000 × price_per_1k) × (1 + markup%) × usd_to_eur` |

### Credit Tables

| Table | Purpose |
|-------|---------|
| `credit_balance` | One row per user. Current balance + lifetime totals. Fast read path. |
| `credit_transactions` | Immutable audit log. Every movement (topup, consumption, refund, adjustment). |

### Transaction Types

| Type | amount_eur | When |
|------|-----------|------|
| `topup` | + (positive, base amount) | Stripe payment confirmed. Amount = base imponible (net of VAT). |
| `consumption` | - (negative) | After each AI interaction |
| `refund` | + (positive) | Stripe refund or admin correction |
| `adjustment` | ± | Manual admin adjustment |

## Sales Ledger (Invoicing)

Each topup is recorded in `sales_ledger` with a snapshot of the billing data at the time of payment, plus the full VAT breakdown. This table is designed for periodic export to the ERP.

### Table: `sales_ledger`

| Field | Type | Description |
|-------|------|-------------|
| `id` | BIGSERIAL | PK |
| `upn` | VARCHAR(200) | FK → users |
| `transaction_date` | TIMESTAMPTZ | When the payment was processed |
| `company_name` | VARCHAR(300) | Snapshot from billing profile |
| `tax_id` | VARCHAR(30) | Snapshot from billing profile |
| `notification_email` | VARCHAR(300) | Snapshot from billing profile |
| `address_line` | VARCHAR(500) | Snapshot from billing profile |
| `city` | VARCHAR(200) | Snapshot from billing profile |
| `province` | VARCHAR(200) | Snapshot from billing profile |
| `postal_code` | VARCHAR(20) | Snapshot from billing profile |
| `country` | VARCHAR(100) | Snapshot from billing profile |
| `total_paid_eur` | DECIMAL(12,4) | What Stripe charged |
| `vat_rate` | DECIMAL(5,2) | 21.00 or 0.00 |
| `base_amount_eur` | DECIMAL(12,4) | Net taxable base |
| `vat_amount_eur` | DECIMAL(12,4) | VAT portion |
| `credits_loaded_eur` | DECIMAL(12,4) | Credits loaded to balance (= base_amount_eur) |
| `stripe_payment_intent_id` | VARCHAR(100) | Stripe traceability |
| `stripe_checkout_session_id` | VARCHAR(100) | Stripe traceability |

**Why snapshot?** If a user changes their company name or address after a payment, past sales records must retain the data that was valid at the time of the sale.

## Conversation Summaries (Session Persistence)

The system maintains conversational context via cumulative summaries, updated after each
AI interaction by Claude Haiku. This enables the AI to reference previous topics without
requiring the user to repeat context.

### Table: `conversation_summaries`

| Field | Type | Description |
|-------|------|-------------|
| `upn` | VARCHAR(200) | PK component, FK → users. The user who owns this summary |
| `summary_date` | DATE | PK component. The UTC calendar date this summary covers |
| `summary_text` | TEXT | Cumulative summary of all interactions on this date |

PK: `(upn, summary_date)`

### How it works

Each API call to Claude (Sonnet) includes:
  `system_prompt + conversation_summary (from BD) + current_user_message`

After each AI response, Haiku generates an updated summary in the background:
  1. Receives: previous `summary_text` + new user message + AI response
  2. Produces: updated `summary_text` incorporating the new exchange
  3. UPSERT into `conversation_summaries` WHERE upn = X AND summary_date = CURRENT_DATE (UTC)

The summary captures: topics analyzed, key data points discussed, recommendations given,
files analyzed (content, not the file itself), and decisions pending.

### Retention: Rolling 48 hours

- Summaries with `summary_date < CURRENT_DATE - 2` are purged automatically
- Purge runs on session load or via periodic job
- A user who connects daily always has at most 2 calendar days of summaries
- A user who disconnects for >48h starts fresh with no summary context
- All dates are UTC — no timezone management per user

### On reconnection

When a user opens a new session, the system loads summaries from the last 2 UTC days:
```sql
SELECT summary_text FROM conversation_summaries
WHERE upn = :upn AND summary_date >= CURRENT_DATE - INTERVAL '2 days'
ORDER BY summary_date ASC;
```
Both summaries (yesterday + today, if they exist) are concatenated and injected as
`{conversation_summary}` in the system prompt.

### Cost

Summary generation uses Claude Haiku (~$0.25/M input tokens). A typical summary
update costs fractions of a cent — negligible compared to the main Sonnet interaction.

### What is NOT stored

- Individual messages are NOT stored (no `conversation_messages` table)
- File attachments are NOT stored (processed in-memory, discarded after response)
- Only the distilled summary persists, capturing essential context

## Data Freshness

- No `snapshot_date` column. Each daily load from Power Automate **overwrites** the previous data via UPSERT.
- Pickup (1d, 7d) and cancellation windows are pre-calculated by PowerBI and embedded in each row.
- The AI always works with the latest data — no need to filter by snapshot.

## Data Retention

Monthly and daily tables have **different** retention windows:

**Monthly facts** (analytical/historical): Rolling 3-year window — **previous year + current year + next year**.
- Example in 2026: Jan 2025 → Dec 2027
- Power Automate rotates data at the start of each new year (drops oldest year)

**Daily facts** (operational/tactical): **today → today + 270 days** (≈9 months).
- Same horizon as the pricing strategy tables
- No past dates — daily data is purely for current + future operational decisions
- Each row embeds pre-calculated SDLY/LY fields from PowerBI for YoY context
- Power Automate prunes rows where `stay_date < today` or `stay_date > today + 270 days`

**Design rationale**: Daily data serves tactical actions (pricing changes, channel closures, min stay). Monthly data serves strategic analysis (trend analysis, YoY comparisons, closed-month reviews). This separation reduces daily data volume by ~80% while preserving full historical access through monthly tables.

- If queried for a past date at daily level, the AI explains that daily detail is only available for the next 9 months and offers the monthly-level data as alternative
- If queried for a year outside the monthly window, the AI explains the 3-year retention policy
