# Proceso diario completo — De PMS a respuesta de la IA

Este documento traza paso a paso lo que ocurre cada día en Revtool, desde que el PMS genera datos hasta que un usuario recibe una respuesta de la IA. Es el mapa completo del sistema.

---

## Visión general

```
┌──────────┐    ┌──────────┐    ┌───────────────┐    ┌────────────┐    ┌──────────┐
│   PMS    │───▶│ PowerBI  │───▶│ Power Automate│───▶│ PostgreSQL │───▶│ Revtool  │
│ (hotel)  │    │ (tenant) │    │   (tenant)    │    │  (central) │    │  AI Chat │
└──────────┘    └──────────┘    └───────────────┘    └────────────┘    └──────────┘
  Datos raw      Calcula KPIs     UPSERT a BD        Fuente de         Consulta +
  del hotel      según spec       tabla por tabla     verdad única      respuesta
```

---

## Fase 0: Datos en origen (PMS del hotel)

**Cuándo**: Continuo (el PMS se actualiza en tiempo real con cada reserva/cancelación/check-in)

El PMS (Property Management System) de cada hotel contiene:
- Reservas actuales (on the books)
- Cancelaciones
- Histórico del año anterior
- Check-ins y check-outs
- Detalle por segmento, canal, tipo habitación, régimen, nacionalidad

**Revtool no se conecta al PMS directamente.** Los datos llegan a Revtool a través de PowerBI, que es la herramienta que el hotel ya usa para reporting.

---

## Fase 1: PowerBI refresca los datos (por tenant)

**Cuándo**: Programado. Cada tenant configura su hora de refresco (típicamente de madrugada/primera hora).

```
Tenant A (hotel.com)                    Tenant B (resort.es)
┌─────────────────────────┐             ┌─────────────────────────┐
│ PowerBI Workspace       │             │ PowerBI Workspace       │
│                         │             │                         │
│ Dataset: "Revtool Data" │             │ Dataset: "Revtool Data" │
│ Scheduled refresh: 5:30 │             │ Scheduled refresh: 7:00 │
│                         │             │                         │
│ Conectado a:            │             │ Conectado a:            │
│ ├── PMS Hotel Playa     │             │ ├── PMS Hotel Costa     │
│ ├── PMS Hotel Sierra    │             │ ├── PMS Hotel Pirineos  │
│ └── PMS Hotel Costa Luz │             │ └── PMS Hotel Delta     │
└─────────────────────────┘             └─────────────────────────┘
```

### Qué calcula PowerBI

PowerBI transforma los datos del PMS en los KPIs definidos en `powerbi_field_spec.md`:

1. **OTB**: Room nights, revenue, ADR — directos del PMS
2. **OTB Proyectado**: Modelo Revtool que ajusta OTB por cancelación esperada
3. **SDLY Bruto**: Foto del mismo día de la semana del año anterior (sin ajustar)
4. **SDLY Neto**: SDLY descontando cancelaciones conocidas
5. **LY**: Dato final cristalizado del año anterior
6. **Forecast**: Previsión de cierre
7. **Budget**: Presupuesto prorrateado al día
8. **Pickup 1d/7d**: Reservas confirmadas que entraron ayer / últimos 7 días
9. **Cancelaciones**: Ventana reciente (1d/7d) + acumuladas + tasas
10. **Pricing strategy**: 3 palancas (intermediarios, precio, estancia mínima) — a nivel hotel y/o por tipo de habitación

Todo esto se calcula **por hotel × stay_date** (daily) y **por hotel × year × month** (monthly),
tanto a nivel resumen como desglosado por segmento, canal, tipo habitación, régimen y país.

### Qué NO calcula PowerBI

- `is_closed` (se deriva dinámicamente en la vista SQL)
- `updated_at` (lo pone PostgreSQL con `NOW()`)
- Datos de crédito/facturación (gestionados por la app)

---

## Fase 2: Power Automate ejecuta la carga ETL (por tenant)

**Cuándo**: Se dispara automáticamente después del refresco de PowerBI.

Cada tenant tiene su propio flujo de Power Automate que:
1. Lee los datos calculados de PowerBI
2. Los envía a PostgreSQL mediante UPSERTs

### Secuencia de carga

```
Power Automate (Tenant A) — arranca a las 06:00
│
├── Paso 1: UPSERT dim_hotels
│   Solo hotel_name + active.
│   ON CONFLICT (hotel_name) DO UPDATE SET active = EXCLUDED.active, updated_at = NOW()
│   → Asegura que el hotel existe antes de cargar facts.
│
├── Paso 2: UPSERT daily_hotel_summary
│   Una fila por hotel × stay_date (~270 stay_dates futuras)
│   ON CONFLICT (hotel_name, stay_date) DO UPDATE SET ... all fields ...
│   → Cada fila tiene ~49 campos (OTB, Proj, SDLY, LY, Forecast, Budget, occ, pickup, cancel)
│   → Sobrescribe la foto del día anterior. No hay histórico de snapshots.
│
├── Paso 3: UPSERT daily_hotel_segment (TOP 5 por día)
│   Solo los 5 segmentos con mayor rn_otb por hotel × stay_date
│   Solo días con venta (rn_otb > 0).
│   Mismo set completo de métricas que el summary
│   → TOP 5 segmentos × ~270 dates = ~1.350 filas/hotel
│
├── Paso 4: UPSERT daily_hotel_channel (TOP 5 por día)
│   Solo los 5 canales con mayor rn_otb por hotel × stay_date
│   Solo días con venta (rn_otb > 0).
│   → TOP 5 canales × ~270 dates = ~1.350 filas/hotel
│
├── Paso 5: UPSERT daily_hotel_roomtype (TOP 5 por día)
│   Solo los 5 tipos con mayor rn_otb por hotel × stay_date
│   rooms_available propio del tipo. Solo días con venta (rn_otb > 0).
│   → TOP 5 tipos × ~270 dates = ~1.350 filas/hotel
│
├── Paso 6: UPSERT daily_hotel_mealplan (TOP 5 por día)
│   Solo los 5 regímenes con mayor rn_otb por hotel × stay_date
│   Solo días con venta (rn_otb > 0).
│   → TOP 5 regímenes × ~270 dates = ~1.350 filas/hotel
│
├── Paso 7: UPSERT daily_pricing_strategy
│   Solo fechas futuras. 3 palancas a nivel HOTEL por stay_date.
│   Para hoteles que usan derivación (habitación base + derivadas).
│   → ~270 filas/hotel
│
├── Paso 7b: UPSERT daily_pricing_strategy_by_roomtype
│   Solo fechas futuras. 3 palancas por hotel × stay_date × room_type_name.
│   Para hoteles que gestionan cada tipo de habitación independientemente.
│   → ~2.160 filas/hotel (~8 tipos × 270 dates)
│
├── Paso 8: UPSERT monthly_hotel_summary
│   Una fila por hotel × year × month_num
│   Métricas agregadas del mes (SUM de daily, ADR/occ/rates recalculados)
│   → ~12 filas/hotel
│
├── Paso 9: UPSERT monthly_hotel_segment (TODOS los segmentos)
│   Sin límite top-5 — todos los segmentos del mes se cargan completos
│   → ~5 segments × 12 meses = ~60 filas/hotel
│
├── Paso 10: UPSERT monthly_hotel_channel (TODOS los canales)
│   Sin límite top-5 — todos los canales del mes se cargan completos
│   → ~20 canales × 12 meses = ~240 filas/hotel
│
├── Paso 11: UPSERT monthly_hotel_roomtype (TODOS los tipos)
│   Sin límite top-5 — todos los tipos del mes se cargan completos
│   Incluye rooms_available propio del tipo
│   → ~8 tipos × 12 meses = ~96 filas/hotel
│
├── Paso 12: UPSERT monthly_hotel_mealplan (TODOS los regímenes)
│   Sin límite top-5 — todos los regímenes del mes se cargan completos
│   → ~4 regímenes × 12 meses = ~48 filas/hotel
│
├── Paso 13: UPSERT monthly_hotel_guest_country (TODOS los países)
│   Sin límite top-5 — todos los países del mes se cargan completos
│   Solo fiable para meses cerrados (nacionalidad se asigna en check-in)
│   → ~25 países × 12 meses = ~300 filas/hotel
│
└── Paso 14: UPSERT user_hotel_access
    Mapeo upn → hotel_name para los usuarios de este tenant
    ON CONFLICT (upn, hotel_name) DO NOTHING
    → Solo añade filas nuevas. Para revocar acceso, se eliminan filas manualmente.
```

### Volumen total por ejecución

| Concepto | Por hotel | 5 hoteles |
|----------|----------|-----------|
| Daily tables (summary + 4 dimensiones TOP 5 + pricing hotel + pricing roomtype) | ~7.830 filas | ~39.150 filas |
| Monthly tables (summary + 4 dimensiones COMPLETAS + country) | ~756 filas | ~3.780 filas |
| **Total UPSERTs** | **~8.586** | **~42.930** |

La optimización top-5 en las tablas diarias dimensionales reduce el volumen un ~37% respecto a cargar todas las dimensiones.
A 100-500 filas por batch con `BEGIN/COMMIT`, la carga completa de 5 hoteles tarda **~3-12 minutos**.

### Manejo de errores

```
Si la carga falla a mitad:
├── Los batches ya commiteados están correctos (UPSERT idempotente)
├── Los batches no ejecutados simplemente no actualizaron
├── Solución: reintentar la carga completa
│   → El UPSERT sobrescribe los datos ya cargados con los mismos valores
│   → Los datos pendientes se cargan por primera vez
└── Resultado: mismo estado final que si hubiera funcionado a la primera
```

---

## Fase 3: Estado de la base de datos tras la carga

**Cuándo**: Después de que todos los tenants han ejecutado su Power Automate.

```
PostgreSQL (base de datos central)
│
├── dim_hotels
│   Todos los hoteles de todos los tenants. Cada uno con su updated_at.
│   Hoteles sin setup_complete = FALSE → la IA informará y redirigirá al formulario ⚙️.
│
├── daily_hotel_summary + dimensionales
│   Datos frescos del día. Cada hotel tiene su última foto.
│   Cada fila con updated_at = NOW() del momento del UPSERT.
│
├── monthly_hotel_summary + dimensionales
│   Agregaciones mensuales actualizadas.
│   Meses cerrados: dato cristalizado.
│   Mes actual: evoluciona cada día.
│
├── daily_pricing_strategy
│   Señales de pricing A NIVEL HOTEL para fechas futuras.
│   close_intermediaries, price_delta, rooms_remaining.
│
├── daily_pricing_strategy_by_roomtype
│   Señales de pricing POR TIPO DE HABITACIÓN para fechas futuras.
│   Mismas 3 palancas, desglosadas por room_type_name.
│
├── user_hotel_access
│   Mapeo usuario → hoteles. Cada tenant mantiene sus accesos.
│
├── users
│   Se crean en el primer login (no en la carga).
│
├── credit_balance / credit_transactions / stripe_customers / token_usage_log
│   Gestionados por la aplicación. No tocados por Power Automate.
│
├── user_billing_profile
│   Datos de empresa para facturación. Rellenados por el usuario en el onboarding.
│   Determina si aplica IVA (España peninsular + Baleares = 21%, resto = 0%).
│
└── sales_ledger
    Registro de cada recarga con snapshot de datos de empresa y desglose IVA.
    Para exportar al ERP. No tocado por Power Automate.
```

### Multi-tenant: timing

```
05:30  Tenant A → PowerBI refresca (3 hoteles)
06:00  Tenant A → Power Automate carga (~45K UPSERTs)
06:15  Tenant A → ✅ Datos frescos. Usuarios de Tenant A ya pueden consultar.

07:00  Tenant B → PowerBI refresca (5 hoteles)
07:30  Tenant B → Power Automate carga (~75K UPSERTs)
07:45  Tenant B → ✅ Datos frescos.

08:00  Tenant C → PowerBI refresca (2 hoteles)
08:15  Tenant C → Power Automate carga (~30K UPSERTs)
08:20  Tenant C → ✅ Datos frescos.

→ A las 08:20 los 10 hoteles de los 3 tenants tienen datos actualizados.
  Cada tenant es independiente. Si Tenant B falla, A y C no se ven afectados.
```

---

## Fase 4: Un usuario abre el chat

**Cuándo**: Cuando el usuario lo necesite (típicamente por la mañana, después de la carga).

### 4.1 Autenticación (Microsoft Entra ID)

```
Usuario abre Revtool (web o embebido en PowerBI)
  │
  ├── Redirect a login.microsoftonline.com
  ├── Usuario introduce credenciales Microsoft
  ├── Microsoft devuelve token con:
  │   └── UPN: rm.mallorca@hotel.com
  │
  └── Backend de Revtool:
      ├── Busca UPN en tabla users
      │   ├── Si existe → actualiza last_login_at
      │   └── Si no existe → INSERT INTO users (upn) VALUES ('rm.mallorca@hotel.com')
      │
      └── Consulta user_hotel_access WHERE upn = 'rm.mallorca@hotel.com'
          → Devuelve lista de hoteles accesibles
```

### 4.2 Perfil de facturación (onboarding obligatorio)

```
Backend consulta user_billing_profile WHERE upn = 'rm.mallorca@hotel.com'
  │
  ├── Si existe → billing_profile_complete = TRUE
  │   └── Frontend carga la app normalmente
  │
  └── Si NO existe → billing_profile_complete = FALSE
      └── Frontend muestra modal obligatorio:
          "Para usar Revtool, completa tus datos de facturación"
          ├── Nombre empresa, NIF, Email notificaciones
          ├── Dirección, Ciudad, País, Provincia
          └── Código postal (opcional)
      → POST /api/user/billing-profile
      → vat_applicable se calcula automáticamente
      → Ahora puede continuar
```

### 4.3 Selector de hoteles

```
Frontend recibe lista de hoteles (via v_user_hotels) y los muestra en la cabecera fija:

┌────────────────────────────────────────────────────────────────┐
│ [Hotel ▼] ☑ Playa Dorada  ☐ Sierra Nevada  ☐ Costa Luz ⚠    │
│                                         Saldo: 25.00€  [+]   │
└────────────────────────────────────────────────────────────────┘
  ↑ selector siempre visible en la cabecera (no panel lateral)

→ 1 hotel seleccionado = mode "hotel" (consejo operativo)
→ 2+ hoteles seleccionados = mode "group" (análisis de cartera)
→ ⚠ indica hoteles con setup_complete = FALSE
```

### 4.4 Verificación de crédito

```
Backend consulta v_user_credit WHERE upn = 'rm.mallorca@hotel.com'
  │
  ├── balance_eur = 25.00 → ✅ Permitido
  │   └── Frontend muestra: "Saldo: 25.00€"
  │
  ├── balance_eur = 1.50, is_low_balance = TRUE → ⚠ Warning
  │   └── Frontend muestra: "⚠ Saldo bajo: 1.50€ [Recargar]"
  │
  └── balance_eur = 0.00, is_blocked = TRUE → 🚫 Bloqueado
      └── Frontend muestra: "Sin saldo. [Recargar saldo]"
         Chat input deshabilitado. Solo funciona el botón de recarga.
```

### 4.5 Detección de hoteles sin configurar

```
Backend consulta v_hotel_setup_status para los hoteles seleccionados
  │
  ├── Hotel Playa Dorada: setup_complete = TRUE → OK, sin acción
  │
  └── Hotel Costa Luz: setup_complete = FALSE
      → La IA informa al usuario y redirige al formulario ⚙️:
        "Veo que Hotel Costa Luz aún no tiene su perfil configurado.
         Puedes configurarlo desde el botón ⚙️ en la cabecera."
```

---

## Fase 5: El usuario hace una pregunta

**Cuándo**: Dentro de la sesión de chat, con hoteles seleccionados y crédito suficiente.

### 5.1 Validación de acceso y construcción del system prompt

**Antes de invocar a la IA**, el backend valida que los hoteles seleccionados
pertenecen al usuario (ver Security: Hotel Data Access en `architecture.md`):

```
selected_hotel_names ⊆ user_hotel_access? → Si NO → 403 Forbidden (IA nunca se invoca)
```

Si la validación es correcta, el backend inyecta el system prompt de la IA
(`ai_system_prompt.md`) con variables dinámicas:

```
{hotel_list}           → "Hotel Playa Dorada, Hotel Sierra Nevada Resort"
                          (TODOS los hoteles accesibles — perímetro de seguridad)
{selected_hotels}      → "Hotel Playa Dorada"
                          (hoteles seleccionados para ESTE análisis)
{analysis_mode}        → "hotel"
{current_date}         → "2026-02-17"
{hotels_pending_setup} → "Hotel Costa Luz"
```

### 5.2 La IA interpreta la pregunta

```
Usuario: "¿Cómo va julio para Semana Santa?"

La IA razona:
├── "julio" → mes 7, year 2026
├── "Semana Santa" → NO es en julio. La IA sabe que Semana Santa 2026 es 29 mar - 5 abr.
├── Interpretación: el usuario probablemente quiso decir "¿cómo va julio?" o "¿cómo va Semana Santa?"
├── Respuesta: aclara la confusión y ofrece datos de ambos periodos
│
└── Si la pregunta fuera clara, ej: "¿Cómo va julio?"
    ├── Decide qué tablas consultar:
    │   ├── monthly_hotel_summary (resumen del mes)
    │   ├── daily_hotel_summary (detalle diario para tendencias)
    │   └── daily_pricing_strategy o daily_pricing_strategy_by_roomtype (según el nivel que prefiera el usuario)
    │
    └── Genera SQL con los filtros correctos:
        WHERE hotel_name = 'Hotel Playa Dorada'
          AND stay_date BETWEEN '2026-07-01' AND '2026-07-31'
```

### 5.3 Consulta a la base de datos

```
La IA genera y ejecuta SQL contra PostgreSQL:

SELECT stay_date, rn_otb, revenue_otb, adr_otb,
       rn_otb_proj, occ_otb, occ_otb_proj,
       rn_sdly_gross, rn_ly, rn_forecast, rn_budget,
       pickup_rn_7d, cancel_rn_7d, cancel_rate_otb
FROM v_daily_summary
WHERE hotel_name = 'Hotel Playa Dorada'
  AND stay_date BETWEEN '2026-07-01' AND '2026-07-31'
ORDER BY stay_date;

→ Devuelve ~31 filas con todos los KPIs diarios de julio
```

### 5.4 La IA formula la respuesta

La IA analiza los datos y responde en el idioma en que el usuario escriba:

```
"Julio para Hotel Playa Dorada va bien. Tienes 4.200 RN en libros con un ADR de 185€,
lo que supone una ocupación OTB del 67%. Respecto al año pasado al mismo punto (SDLY),
estás un +12% arriba en RN y +8% en revenue.

El pickup de la última semana ha sido fuerte: +180 RN confirmadas, especialmente
en el segmento Individual (+95 RN) y el canal Booking (+60 RN).

Las cancelaciones están controladas: tasa del 14%, por debajo del 18% que tenías
al mismo punto del año pasado.

Para las fechas del 18-25 julio, el modelo recomienda subir precio +15€ y empezar
a filtrar intermediarios — el forecast prevé que llenarás esas fechas."
```

### 5.5 La IA muestra el coste (post-respuesta)

```
┌─────────────────────────────────────────────────────────┐
│ [Respuesta de la IA]                                    │
│                                                         │
│ Esta consulta: 0.04€ · Saldo restante: 24.96€          │
└─────────────────────────────────────────────────────────┘
```

---

## Fase 6: Cálculo de coste y deducción de crédito

**Cuándo**: Inmediatamente después de completar la respuesta de la IA.

### 6.1 Registro de tokens

```
INSERT INTO token_usage_log (
    upn, session_id, model_used,
    tokens_input, tokens_output,
    cost_input_usd, cost_output_usd, cost_eur,
    query_type, hotels_queried, analysis_mode, query_summary
) VALUES (
    'rm.mallorca@hotel.com', 'abc-123', 'claude-sonnet-4-5-20250929',
    2400, 850,                          -- tokens
    0.007200, 0.012750,                 -- USD (raw provider cost)
    0.0380,                             -- EUR (con markup + cambio)
    'text', ARRAY['Hotel Playa Dorada'], 'hotel',
    'Consulta sobre julio: OTB, pickup, pricing'
);
```

### 6.2 Deducción atómica del saldo

```sql
BEGIN;

-- Deducir del saldo (con check de saldo suficiente)
UPDATE credit_balance
SET balance_eur = balance_eur - 0.0380,
    total_consumed = total_consumed + 0.0380,
    last_consumption_at = NOW(),
    updated_at = NOW()
WHERE upn = 'rm.mallorca@hotel.com'
  AND balance_eur >= 0.0380    -- Previene saldo negativo
RETURNING balance_eur;
-- → 24.9620

-- Registrar la transacción
INSERT INTO credit_transactions (
    upn, transaction_type, amount_eur, balance_after,
    token_usage_log_id, description, created_by
) VALUES (
    'rm.mallorca@hotel.com', 'consumption', -0.0380, 24.9620,
    <id del token_usage_log>, 'Consulta IA: 0.0380€', 'system'
);

COMMIT;
```

### 6.3 Frontend actualiza el saldo

```
Antes: Saldo: 25.00€
Después: Saldo: 24.96€
Footer: "Esta consulta: 0.04€ · Saldo restante: 24.96€"
```

---

## Fase 7: Recarga de crédito (cuando el saldo se agota)

**Cuándo**: El usuario decide recargar (botón "Recargar") o el saldo llega a 0 (obligatorio).

**Requisito**: El perfil de facturación (user_billing_profile) debe estar completo.

```
1. Usuario pulsa [Recargar] → TopupModal con importe + desglose IVA
   ├── Si empresa en España (no Canarias/Ceuta/Melilla):
   │   → Base: 20.66€, IVA 21%: 4.34€, Total: 25.00€, Créditos: 20.66€
   └── Si empresa en Canarias/internacional:
       → Base: 25.00€, IVA 0%: 0.00€, Total: 25.00€, Créditos: 25.00€
2. Frontend: POST /api/stripe/create-checkout { amount_eur: 25.00 }
3. Backend:
   ├── Verifica que user_billing_profile existe → si no → 400
   ├── Busca stripe_customers WHERE upn = 'rm.mallorca@hotel.com'
   │   ├── Si existe → reutiliza customer_id
   │   └── Si no → crea Stripe Customer con metadata.upn
   ├── Crea Stripe Checkout Session (Stripe es solo un cajero):
   │   ├── customer: cus_XXXXXXXXX
   │   ├── metadata: { upn: 'rm.mallorca@hotel.com', amount_eur: '25.00' }
   │   ├── line_items: [{ name: 'Revtool AI - Recarga', amount: 2500 cents }]
   │   └── success_url: /chat?topup=success
   └── Devuelve checkout_url
4. Frontend redirige a checkout_url (Stripe hosted page)
5. Usuario en Stripe Checkout:
   ├── Introduce datos de pago
   └── Paga 25.00€
6. Stripe → Webhook POST /api/stripe/webhook (checkout.session.completed)
7. Backend webhook:
   ├── Verifica firma stripe-signature
   ├── Extrae metadata.upn = 'rm.mallorca@hotel.com', amount_eur = 25.00
   ├── Idempotency check: ¿payment_intent_id ya procesado? → skip
   ├── Consulta user_billing_profile → vat_applicable = TRUE
   ├── Calcula: base = 25.00/1.21 = 20.66€, IVA = 4.34€, créditos = 20.66€
   ├── BEGIN
   │   ├── UPDATE credit_balance SET balance_eur += 20.66, total_topped_up += 20.66
   │   ├── INSERT INTO credit_transactions (type='topup', amount=20.66)
   │   └── INSERT INTO sales_ledger (snapshot billing data + total=25, base=20.66, IVA=4.34)
   │   COMMIT
   └── Responde 200 { received: true }
8. Usuario vuelve a /chat?topup=success
   ├── Frontend poll GET /api/credits/balance
   ├── Muestra: "Recarga completada. Tu nuevo saldo es 20.66€"
   └── Chat re-habilitado si estaba bloqueado
```

---

## Resumen del día completo (timeline)

```
05:30  ┌─ PowerBI Tenant A refresca datos (3 hoteles)
06:00  ├─ Power Automate Tenant A → UPSERT a PostgreSQL (~45K filas)
06:15  ├─ ✅ Tenant A listo
       │
07:00  ├─ PowerBI Tenant B refresca datos (5 hoteles)
07:30  ├─ Power Automate Tenant B → UPSERT a PostgreSQL (~75K filas)
07:45  ├─ ✅ Tenant B listo
       │
08:00  ├─ PowerBI Tenant C refresca datos (2 hoteles)
08:15  ├─ Power Automate Tenant C → UPSERT a PostgreSQL (~30K filas)
08:20  ├─ ✅ Todos los tenants listos (10 hoteles actualizados)
       │
08:30  ├─ Revenue Manager de Hotel Playa Dorada abre Revtool
       │  ├─ Login Microsoft → UPN: rm.mallorca@hotel.com
       │  ├─ Perfil facturación: ✅ (Hotel Playa Sol S.L., B12345678, Illes Balears)
       │  ├─ Selecciona: Hotel Playa Dorada
       │  ├─ Saldo: 25.00€ ✅
       │  └─ "¿Cómo va julio?"
       │     ├─ IA consulta v_daily_summary + v_pricing_strategy
       │     ├─ Responde con análisis de OTB, pickup, pricing
       │     ├─ Coste: 0.04€ → Saldo: 24.96€
       │     └─ token_usage_log + credit_transaction registrados
       │
09:00  ├─ Director de grupo abre Revtool
       │  ├─ Login Microsoft → UPN: director@hotel.com
       │  ├─ Selecciona: 3 hoteles (mode "group")
       │  ├─ Saldo: 0.00€ 🚫 Bloqueado
       │  └─ [Recargar saldo] → TopupModal (50€, IVA 21%: 8.59€, base: 41.32€)
       │     → Stripe → pago 50€ → Webhook → Saldo: +41.32€
       │     └─ "Dame el briefing del grupo para este mes"
       │        ├─ IA consulta v_monthly_summary para 3 hoteles
       │        └─ Responde con comparativa de cartera
       │
  ...  │  (usuarios siguen consultando durante el día)
       │
23:59  └─ Fin del día. Mañana se repite desde Fase 1.
```

---

## Puntos de fallo y recuperación

| Punto de fallo | Impacto | Recuperación |
|---------------|---------|-------------|
| PowerBI no refresca | Datos de ayer siguen en BD. Usuarios ven datos stale. | Reintentar refresco manualmente. IA sigue funcionando con datos antiguos. |
| Power Automate falla a mitad | Algunos hoteles actualizados, otros no. | Reintentar la carga completa (UPSERT idempotente). |
| PostgreSQL caído | Chat no funciona (no puede consultar datos). | Restaurar BD. Los datos se re-cargan en la siguiente ejecución. |
| Stripe webhook no llega | Pago procesado pero crédito no actualizado. | Stripe reintenta webhooks hasta 3 días. Idempotency check evita duplicados. |
| Microsoft Entra ID caído | Usuarios no pueden hacer login. | Esperar a que Microsoft restaure el servicio. Sesiones activas siguen funcionando. |
| Un tenant falla | Solo sus hoteles quedan con datos stale. Otros tenants no afectados. | Reintentar solo ese tenant. |
