# Stripe Integration Specification

## Overview

Revtool AI uses Stripe Checkout (hosted page) for prepaid credit topups. Users add EUR to their balance, which is consumed per AI interaction.

**Model:** One-time payments (no subscriptions). Each topup is a standalone Stripe Checkout session with a dynamic amount.

**Key principles:**
- **Stripe is just a cashier.** It charges the amount the user selects. No Stripe Tax, no tax management in Stripe.
- **Billing data lives in Revtool.** The user's company information (name, NIF, address, country, province, notification email) is stored in `user_billing_profile`. This determines VAT treatment.
- **VAT is calculated by Revtool** after each payment. If the company is in mainland Spain or Balearic Islands → 21% IVA included in the payment. Otherwise → 0% IVA.
- **Credits loaded = base amount** (net of VAT). If a Spanish user pays 100€, they get 82.64€ in credits.
- **Each topup is recorded in `sales_ledger`** with a snapshot of billing data, for periodic export to the ERP.

## User Billing Profile (Prerequisite)

Before a user can make any topup, they must complete their billing profile in Revtool (🏢 button in the header, or mandatory onboarding modal on first login).

```
┌─────────────────────────────────────────────────────────┐
│  UPN: rm.mallorca@hotel.com (from Microsoft Entra ID)   │
│  ├── Revtool user_billing_profile:                      │
│  │   ├── company_name: Hotel Playa Sol S.L.             │
│  │   ├── tax_id: B12345678                              │
│  │   ├── notification_email: admin@hotelplayasol.com    │
│  │   ├── address_line: Calle Mayor 10                   │
│  │   ├── city: Palma                                    │
│  │   ├── province: Illes Balears                        │
│  │   ├── country: España                                │
│  │   └── vat_applicable: TRUE (auto-calculated)         │
│  │                                                      │
│  Stripe Customer (cus_XXXXXXXXX):                       │
│  ├── payment methods: cards, etc.                       │
│  └── Revtool only stores: stripe_customer_id            │
│       (via stripe_customers table)                      │
└─────────────────────────────────────────────────────────┘
```

### VAT Logic

The `vat_applicable` column in `user_billing_profile` is a PostgreSQL generated column:

```sql
vat_applicable BOOLEAN GENERATED ALWAYS AS (
    country = 'España'
    AND province NOT IN ('Las Palmas', 'Santa Cruz de Tenerife', 'Ceuta', 'Melilla')
) STORED
```

| Company location | vat_applicable | VAT rate | 100€ payment → credits |
|-----------------|:--------------:|:--------:|:----------------------:|
| España (peninsular + Baleares) | TRUE | 21% | 82.64€ |
| Canarias (Las Palmas, Santa Cruz de Tenerife) | FALSE | 0% | 100.00€ |
| Ceuta, Melilla | FALSE | 0% | 100.00€ |
| Any other country | FALSE | 0% | 100.00€ |

**Fiscal notes:**
- Canarias has IGIC (7%), Ceuta and Melilla have IPSI (10%), but these are the buyer's responsibility, not the seller's. As a peninsular Spanish company, the operation is "no sujeta a IVA" for these territories.
- For international B2B clients, reverse charge applies — 0% VAT is correct.
- The VAT rate is configurable via `VAT_RATE` environment variable (default: 21.0).

## UPN vs Notification Email

The UPN (User Principal Name) from Microsoft Entra ID is a **technical identifier**, NOT necessarily a functional email inbox. Many hotel users only have a Power BI license without Exchange/Outlook, so sending receipts to the UPN would fail silently.

**Solution:**
- The UPN is the **internal identifier** — used as PK in `users`, `credit_balance`, `user_billing_profile`, etc.
- The **notification email** is a separate field in `user_billing_profile`. It's the email for invoices and communications.
- The UPN also travels as `metadata.upn` in Stripe Checkout sessions to link payments back to the Revtool account.

## Stripe Configuration

### Environment Variables

```
STRIPE_SECRET_KEY=sk_live_xxx           # Server-side API key
STRIPE_PUBLISHABLE_KEY=pk_live_xxx      # Client-side key (for redirects)
STRIPE_WEBHOOK_SECRET=whsec_xxx         # Webhook signature verification
STRIPE_CURRENCY=eur                     # Payment currency
STRIPE_MIN_AMOUNT_CENTS=100             # Minimum topup: 1€ (100 cents)
STRIPE_MAX_AMOUNT_CENTS=50000           # Maximum topup: 500€ (50000 cents)
VAT_RATE=21.0                           # Spanish IVA rate (mainland + Balearic Islands)
```

### Stripe Dashboard Settings

1. **Webhooks**: Register endpoint `POST /api/stripe/webhook` for events:
   - `checkout.session.completed` — successful payment
   - `charge.refunded` — refund processed
2. **Payment methods**: Enable Card, Google Pay, Apple Pay (optional: SEPA, iDEAL for EU users)
3. **Customer portal**: Not needed (no subscriptions)
4. **Tax settings**: Not needed. VAT is calculated by Revtool, not Stripe. Do NOT enable Stripe Tax.

## Database Tables Involved

```sql
-- Company billing data per user (mandatory before first topup)
user_billing_profile (
    upn                 VARCHAR(200) PK → users(upn),
    company_name        VARCHAR(300) NOT NULL,
    tax_id              VARCHAR(30)  NOT NULL,       -- NIF/CIF/VAT number
    notification_email  VARCHAR(300) NOT NULL,       -- For invoices & communications
    address_line        VARCHAR(500) NOT NULL,
    city                VARCHAR(200) NOT NULL,
    province            VARCHAR(200) NOT NULL,
    postal_code         VARCHAR(20),
    country             VARCHAR(100) NOT NULL,
    vat_applicable      BOOLEAN GENERATED            -- Auto: TRUE if Spain not Canarias/Ceuta/Melilla
)

-- Links UPN to Stripe Customer (created on first purchase)
stripe_customers (
    upn                 VARCHAR(200) PK → users(upn),
    stripe_customer_id  VARCHAR(100) UNIQUE  -- cus_XXXXXXXXX
)

-- Real-time balance (checked before every AI interaction)
credit_balance (
    upn                 VARCHAR(200) PK → users(upn),
    balance_eur         DECIMAL(12,4),
    total_topped_up     DECIMAL(12,4),
    total_consumed      DECIMAL(12,4),
    low_balance_alert   DECIMAL(12,4) DEFAULT 2.00,
    last_topup_at       TIMESTAMPTZ,
    last_consumption_at TIMESTAMPTZ
)

-- Immutable log of every credit movement
credit_transactions (
    upn                 VARCHAR(200) → users(upn),
    transaction_type    VARCHAR(20),   -- 'topup', 'consumption', 'refund', 'adjustment'
    amount_eur          DECIMAL(12,4), -- positive for topup/refund, negative for consumption
    balance_after       DECIMAL(12,4),
    stripe_payment_intent_id   VARCHAR(100),  -- for topups
    stripe_checkout_session_id VARCHAR(100),  -- for topups
    stripe_refund_id           VARCHAR(100),  -- for refunds
    token_usage_log_id         BIGINT,        -- for consumptions
    description         VARCHAR(500),
    created_by          VARCHAR(200)   -- 'stripe_webhook', 'system', 'admin'
)

-- Immutable record of every topup for invoicing (snapshot of billing data)
sales_ledger (
    id                          BIGSERIAL PK,
    upn                         VARCHAR(200) → users(upn),
    transaction_date            TIMESTAMPTZ DEFAULT NOW(),
    -- Billing data snapshot (copied from user_billing_profile at payment time)
    company_name, tax_id, notification_email, address_line, city, province,
    postal_code, country,
    -- Amounts
    total_paid_eur              DECIMAL(12,4),   -- What Stripe charged
    vat_rate                    DECIMAL(5,2),     -- 21.00 or 0.00
    base_amount_eur             DECIMAL(12,4),   -- Net taxable base
    vat_amount_eur              DECIMAL(12,4),   -- VAT portion
    credits_loaded_eur          DECIMAL(12,4),   -- = base_amount_eur
    -- Stripe traceability
    stripe_payment_intent_id, stripe_checkout_session_id
)
```

### Why snapshot billing data in sales_ledger?

If a user changes their company address or NIF after a payment, the past sales record must preserve the data that was valid at the time of the sale. The `sales_ledger` copies all billing fields from `user_billing_profile` at payment time.

## API Endpoints

### POST /api/stripe/create-checkout

Creates a Stripe Checkout session. Called when the user clicks "Pagar con Stripe" in the TopupModal.

**Prerequisite:** `user_billing_profile` must exist for this UPN. If not, returns 400.

**Request:**
```json
{
  "amount_eur": 25.00
}
```

**Validation:**
- User must be authenticated (Microsoft Entra ID session)
- `user_billing_profile` must exist (billing profile check)
- `amount_eur >= 1.00` (Stripe minimum for EUR is 0.50, we set 1.00)
- `amount_eur <= 500.00` (configurable cap)
- Amount converted to cents: `amount_cents = Math.round(amount_eur * 100)`

**Response:**
```json
{
  "checkout_url": "https://checkout.stripe.com/c/pay/cs_xxx",
  "session_id": "cs_xxx"
}
```

**Frontend:** Redirect user to `checkout_url`. Stripe handles the payment UI. No tax configuration needed in Stripe — it just charges the amount.

### POST /api/stripe/webhook

Receives Stripe webhook events. Called by Stripe servers, not by the frontend.

**Headers required:** `stripe-signature` (Stripe sends this automatically)

**Event: `checkout.session.completed`**

The webhook now performs these additional steps:

1. Verify webhook signature
2. Extract `upn` and `amount_eur` from session metadata
3. Idempotency check (has this `payment_intent_id` been processed already?)
4. **Fetch billing profile** → determine `vat_applicable`
5. **Calculate VAT breakdown:**
   - If `vat_applicable`: `base = amount / 1.21`, `vat = amount - base`
   - Else: `base = amount`, `vat = 0`
6. **Credits loaded = base amount** (not total paid)
7. Atomic transaction:
   - Update `credit_balance` with `credits_to_load` (base amount)
   - Insert `credit_transactions` (topup record)
   - **Insert `sales_ledger`** (snapshot of billing data + amounts)
8. Commit

```
Example: Spanish user (mainland) pays 100€
  → vat_applicable = TRUE, vat_rate = 21%
  → base_amount = 100 / 1.21 = 82.64€
  → vat_amount = 100 - 82.64 = 17.36€
  → credits_loaded = 82.64€
  → credit_balance += 82.64€
  → sales_ledger: total=100, base=82.64, vat=17.36, credits=82.64

Example: Canary Islands user pays 100€
  → vat_applicable = FALSE, vat_rate = 0%
  → base_amount = 100€
  → vat_amount = 0€
  → credits_loaded = 100€
  → credit_balance += 100€
  → sales_ledger: total=100, base=100, vat=0, credits=100
```

### GET /api/credits/balance

Returns current credit status. Called by the frontend to display balance.

**Auth required:** Microsoft Entra ID session → extracts UPN

**Response:**
```json
{
  "balance_eur": 12.45,
  "is_low_balance": false,
  "is_blocked": false,
  "total_topped_up": 75.00,
  "total_consumed": 62.55,
  "requests_this_month": 47,
  "cost_eur_this_month": 3.21
}
```

**Source:** `SELECT * FROM v_user_credit WHERE upn = $1`

### GET /api/user/billing-profile

Returns the billing profile for the authenticated user. Returns 404 if not set up.

**Response:**
```json
{
  "upn": "rm.mallorca@hotel.com",
  "company_name": "Hotel Playa Sol S.L.",
  "tax_id": "B12345678",
  "notification_email": "admin@hotelplayasol.com",
  "address_line": "Calle Mayor 10",
  "city": "Palma",
  "province": "Illes Balears",
  "postal_code": "07001",
  "country": "España",
  "vat_applicable": true
}
```

### PUT /api/user/billing-profile

Creates or updates the billing profile. Uses UPSERT on UPN.

**Request:**
```json
{
  "company_name": "Hotel Playa Sol S.L.",
  "tax_id": "B12345678",
  "notification_email": "admin@hotelplayasol.com",
  "address_line": "Calle Mayor 10",
  "city": "Palma",
  "province": "Illes Balears",
  "postal_code": "07001",
  "country": "España"
}
```

**Response:** Same as GET (includes `vat_applicable` auto-calculated).

## Credit Deduction Flow

After each AI interaction completes, cost is deducted from `credit_balance`. This is unchanged — deduction is always in EUR from the credit balance regardless of VAT.

## Pre-Interaction Credit Check

Before calling the LLM, check `credit_balance.balance_eur > 0`. If not, return 402 (Payment Required). The AI is never called.

## Frontend UI Specification

### Balance Display (always visible in chat header)

```
┌──────────────────────┐
│  Saldo: 12.45€       │
│  [Recargar]          │
└──────────────────────┘
```

### Low Balance Warning (balance < low_balance_alert threshold)

```
┌──────────────────────────────────────────┐
│  ⚠ Saldo bajo: 1.50€                    │
│  Recarga pronto para no quedarte sin     │
│  servicio. [Recargar ahora]              │
└──────────────────────────────────────────┘
```

### Blocked State (balance <= 0)

The chat input is disabled. The AI is never called. Only the topup button works.

### Post-Interaction Cost Display

After each AI response, a small footer:

```
Esta consulta: 0.03€ · Saldo restante: 12.42€
```

### Topup Modal (with IVA breakdown)

User clicks "Recargar" → modal shows amount selector, IVA breakdown, and pay button:

```
For a Spanish user (mainland/Baleares, vat_applicable=TRUE):
┌──────────────────────────────────────────┐
│  Recargar saldo                          │
│                                          │
│  Importe rápido: [5€] [10€] [25€] [50€] │
│  Importe personalizado: [____] €         │
│                                          │
│  ┌──────────────────────────────────┐    │
│  │  Base imponible:    82.64€       │    │
│  │  IVA (21%):         17.36€       │    │
│  │  Total a pagar:    100.00€       │    │
│  │  Créditos a recibir: 82.64€     │    │
│  └──────────────────────────────────┘    │
│                                          │
│  [Pagar 100.00€ con Stripe →]           │
│                                          │
│  Saldo actual: 1.50€                     │
│  Gasto este mes: 8.30€                   │
└──────────────────────────────────────────┘

For a Canary Islands or international user (vat_applicable=FALSE):
┌──────────────────────────────────────────┐
│  ...                                     │
│  ┌──────────────────────────────────┐    │
│  │  Base imponible:   100.00€       │    │
│  │  IVA (0%):           0.00€       │    │
│  │  Total a pagar:    100.00€       │    │
│  │  Créditos a recibir: 100.00€    │    │
│  └──────────────────────────────────┘    │
│  ...                                     │
└──────────────────────────────────────────┘
```

The IVA breakdown is calculated client-side using `session.vat_applicable` and `session.vat_rate` from the `/api/session` response. This is a preview only — the authoritative calculation happens server-side in the webhook.

### After Successful Payment

When the user returns from Stripe (URL contains `?topup=success`):
1. Show a confirmation banner: "Recarga completada. Tu nuevo saldo es X.XX€"
2. Refresh the balance display
3. Re-enable chat input if it was blocked

Note: The balance update happens via webhook (server-side), which may arrive before or after the user redirect. Poll `GET /api/credits/balance` for a few seconds after redirect to catch the update.

## Sales Ledger (ERP Export)

The `sales_ledger` table is designed for periodic export to the ERP for invoice generation. Each row represents one topup with complete billing data:

```sql
SELECT
    transaction_date, company_name, tax_id, notification_email,
    country, province,
    total_paid_eur, vat_rate, base_amount_eur, vat_amount_eur,
    credits_loaded_eur, stripe_payment_intent_id
FROM sales_ledger
ORDER BY transaction_date;
```

Export can be done via CSV, JSON, or direct DB query — integration with the ERP is out of scope for Revtool.

## Security Considerations

1. **Webhook signature verification**: Always verify `stripe-signature` header with `STRIPE_WEBHOOK_SECRET`. Never trust unverified requests.
2. **Idempotency**: Check `stripe_payment_intent_id` before processing to prevent double-credits on webhook retries.
3. **Atomic transactions**: Balance update + transaction log + sales ledger always in a single DB transaction with BEGIN/COMMIT.
4. **Race conditions**: `WHERE balance_eur >= cost` in UPDATE prevents negative balance even with concurrent requests.
5. **Amount validation**: Server-side validation of min/max amounts. Never trust client-side amounts — the authoritative amount comes from `session.metadata.amount_eur` in the webhook.
6. **Billing profile required**: `create-checkout` rejects requests without a `user_billing_profile`. No profile → no topup.
7. **VAT calculated server-side**: The TopupModal preview is informational only. The real calculation happens in the webhook handler.
8. **HTTPS only**: All endpoints must be served over HTTPS. Stripe requires it for webhooks in live mode.

## Stripe Checkout Setup Checklist

For the developer configuring this:

- [ ] Create a Stripe account (or use existing) at https://dashboard.stripe.com
- [ ] Get API keys from Dashboard → Developers → API keys
- [ ] Set environment variables (`STRIPE_SECRET_KEY`, `STRIPE_PUBLISHABLE_KEY`, `VAT_RATE`)
- [ ] Register webhook endpoint in Dashboard → Developers → Webhooks:
  - URL: `https://revtool.thetotalprofitjourney.com/api/stripe/webhook`
  - Events: `checkout.session.completed`, `charge.refunded`
  - Copy the signing secret → `STRIPE_WEBHOOK_SECRET`
- [ ] Enable payment methods in Dashboard → Settings → Payment methods:
  - Card (mandatory)
  - Google Pay / Apple Pay (recommended, no extra integration needed)
  - SEPA Direct Debit (optional, for EU bank transfers)
- [ ] Do NOT enable Stripe Tax (VAT is handled by Revtool)
- [ ] Test with Stripe CLI locally: `stripe listen --forward-to localhost:3000/api/stripe/webhook`
- [ ] Test card numbers: `4242 4242 4242 4242` (success), `4000 0000 0000 0002` (decline)
- [ ] Verify idempotency: trigger the same webhook twice, confirm only one credit added
- [ ] Verify billing profile block: try to create checkout without profile, confirm 400 error
- [ ] Verify VAT calculation: topup with Spanish profile → credits = amount/1.21; topup with Canarias profile → credits = amount
- [ ] Verify sales_ledger: after topup, confirm row exists with correct snapshot data
