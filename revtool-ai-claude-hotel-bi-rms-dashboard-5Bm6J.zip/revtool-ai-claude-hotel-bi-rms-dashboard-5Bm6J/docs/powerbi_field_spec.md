# Especificación de campos para exportación desde PowerBI

Este documento define **exactamente** qué campos debe generar Revtool desde PowerBI para alimentar cada tabla de la base de datos de Revtool AI. Es la referencia definitiva para el ETL vía Power Automate.

---

## Principios generales

### ADR
- **Bruto de paquete en pre-stay**: alojamiento + pensión alimenticia, valoración de la reserva antes de la llegada del cliente.
- Incluye la comisión del canal cuando aplique (ej: Booking incluye su ~17%).
- **NO** incluye regularizaciones de producción, cargos por upgrades, penalizaciones por no-shows, ni ajustes post-stay.
- Es el importe que se facturará al cliente/agencia según la reserva.

### OTB
- **Siempre tal como está en el PMS**. Sin ajustes, sin proyecciones. Es el dato que el usuario del hotel reconoce en su sistema.
- El campo `otb_proj` es un cálculo interno de Revtool que la IA usa para razonar, pero **nunca** se presenta al usuario como "sus datos".

### Pickup
- **Solo reservas confirmadas** (sin cancelaciones). Entrada de negocio nuevo puro.

### Cancelaciones
- **Separadas siempre**. Se analizan aparte, no contaminan el pickup.
- Las cancelaciones acumuladas solo almacenan **tasas (ratios)**: `cancel_rate_otb`, `cancel_rate_sdly`, `cancel_rate_ly`. Los valores absolutos de RN y revenue cancelado acumulado no se almacenan.
- Las cancelaciones de ventana (7d/1d) sí incluyen RN y revenue absolutos.

### SDLY (Same Day Last Year)
- **SDLY Bruto**: Foto del mismo día de la semana del año anterior, sin ajustar. Lo que había en libros a esa fecha.
- **SDLY Neto**: Misma foto pero descontando las cancelaciones conocidas hasta ese punto. Es la comparación justa contra `rn_otb_proj`.

### LY y SDLY: siempre relativos al año de la stay_date

El año de referencia para LY y SDLY **siempre es el año anterior al de la stay_date** en esa fila. No es un año fijo.

| stay_date | LY referencia | SDLY referencia |
|-----------|---------------|-----------------|
| 2026-07-15 | 2025-07-15 | Mismo día de la semana, julio 2025 |
| 2027-03-10 | 2026-03-10 | Mismo día de la semana, marzo 2026 |
| 2025-12-20 | 2024-12-20 | Mismo día de la semana, diciembre 2024 |

**PowerBI calcula estos campos mirando siempre al año anterior de cada stay_date**. Cada fila lleva su propia comparativa embebida — la base de datos no necesita saber "qué año es el actual".

### Snapshot
- No se envía `snapshot_date`. Cada carga diaria **sobrescribe** la anterior. El pickup a 1d y 7d ya está embebido en los datos.

### NULL vs 0
- **NULL** = dato no disponible (hotel sin histórico, PMS sin cancel revenue, sin budget cargado)
- **0** = dato real de valor cero (0 room nights, 0 cancelaciones, 0 revenue)
- **Nunca enviar 0 cuando el dato no está disponible**. La IA trata NULL y 0 de forma diferente.

**Alcance de la regla NULL vs 0**: La regla aplica **solo a `rn_*` y `revenue_*`** (las medidas base).
Las medidas dependientes (`adr_*`, `occ_*`, `cancel_rate_*`) son divisiones calculadas en PowerBI
con `DIVIDE(numerador, denominador, 0)` — si el denominador es NULL o 0, PowerBI devuelve 0
y no es posible cambiarlo a NULL en el origen. **La IA debe saber que cuando un `rn_*` o
`revenue_*` es NULL para un grupo (LY, Budget, SDLY, Forecast), sus medidas dependientes
(`adr_*`, `occ_*`, `cancel_rate_*`) llegarán como 0 pero NO representan un dato real de valor
cero — representan ausencia de dato**. La IA debe inferir la disponibilidad de datos SIEMPRE
desde `rn_*` y `revenue_*`, e ignorar el valor de las medidas dependientes cuando las bases son NULL.

**Matiz SDLY/LY**: Un 0 en campos SDLY puede ser ambiguo. La IA cruza SDLY con LY para
discriminar:
- SDLY = 0 y LY > 0 → dato real: a esa fecha del año anterior aún no había vendido nada.
- SDLY = 0 y LY = 0/NULL → ausencia de histórico.
Para evitar ambigüedades, enviar **NULL** (no 0) cuando no haya datos históricos disponibles.

**OTB**: Un 0 siempre es dato real (el hotel no tiene reservas para esa fecha). OTB es NOT NULL.

### Datos sparse: solo días con inventario
- **Solo se generan filas para días con `rooms_available > 0`**. Si un hotel está cerrado
  (cierre estacional, renovación, etc.), esos días NO se envían a `daily_hotel_summary` ni
  a `daily_hotel_roomtype`. No hay fila con `rooms_available = 0`.
- Esto implica que un hotel NO tendrá necesariamente 365 filas/año. Solo tendrá filas para
  los días en que tiene inventario (y por tanto está abierto).
- En los **meses**, si un hotel está cerrado todo el mes, la fila SÍ se envía con
  `rooms_available = 0`. Esto garantiza que los 12 meses del año siempre aparecen en la
  serie temporal, lo cual es necesario para consultas de resultados anuales. La IA debe
  interpretar `rooms_available = 0` en monthly como "hotel cerrado ese mes" (no como error).
- La **suma de los daily por tipología** (`daily_hotel_roomtype`) no necesariamente coincidirá
  con el monthly de ese mes (`monthly_hotel_summary`), en el momento en que no haya datos
  de todas las habitaciones por tipología para todos los días. Puede faltar una tipología
  ciertos días (fuera de inventario, PMS no reporta), y esos room nights existirán a nivel
  hotel pero no a nivel tipología.

---

## Tabla 1: `dim_hotels`

> Catálogo de hoteles. Se carga inicialmente con `hotel_name` + `active`.
> `hotel_name` es la **PRIMARY KEY** y el identificador único del hotel en todo el sistema.
> Los campos descriptivos (categoría, ubicación, tipología, etc.) se configuran desde el
> formulario ⚙️ en la cabecera. **No es necesario cargarlos desde PowerBI.**

### Campos que se cargan desde PowerBI

| Campo | Tipo | Obligatorio | Descripción |
|-------|------|-------------|-------------|
| `hotel_name` | VARCHAR(200) | Sí | Nombre comercial del hotel. **PRIMARY KEY** y clave UPSERT |
| `active` | BOOLEAN | Sí | ¿Está activo? |

### Campos configurados por el usuario desde el formulario ⚙️ (NO cargar desde PowerBI)

| Campo | Tipo | Valores | Descripción |
|-------|------|---------|-------------|
| `hotel_type` | VARCHAR(20) | `vacation`, `urban`, `mixed` | Tipología del hotel |
| `target_client` | VARCHAR(20) | `family`, `adults_only`, `mixed` | Cliente objetivo |
| `destination` | VARCHAR(100) | Libre | Destino turístico (ej: "Mallorca", "Costa del Sol") |
| `province` | VARCHAR(100) | Libre | Provincia/región (ej: "Islas Baleares", "Málaga") |
| `city` | VARCHAR(100) | Libre | Ciudad. Usado por la IA para resolver eventos locales |
| `country` | VARCHAR(5) | ISO | Código país (ej: "ES", "PT", "MX") |
| `total_rooms` | INT | Positivo | Número total de habitaciones (opcional, derivable de datos diarios) |
| `currency` | VARCHAR(3) | ISO | Moneda de operación (ej: "EUR", "USD") |

### Campos de control del setup (gestionados automáticamente por la app)

| Campo | Tipo | Descripción |
|-------|------|-------------|
| `setup_complete` | BOOLEAN | `TRUE` cuando el onboarding está completo. Default: `FALSE` |
| `setup_by` | VARCHAR(200) | UPN del usuario que completó la configuración |
| `setup_at` | TIMESTAMPTZ | Timestamp de cuándo se completó |

> **Nota**: Los campos `has_historical`, `has_budget` y `pms_source` han sido eliminados.
> La disponibilidad de datos históricos y presupuesto se detecta dinámicamente por la IA
> (campos NULL en los datos = no disponible). Esto es mejor porque estos estados cambian
> con el tiempo — un hotel puede no tener presupuesto en enero pero sí en febrero.

---

## Tabla 2: `daily_hotel_summary`

> Tabla principal. Una fila por hotel × fecha de estancia. Contiene todos los KPIs a nivel hotel. Se refresca diariamente, sobrescribiendo la foto anterior.

**Clave única**: `hotel_name` + `stay_date`

### Grupo 1: OTB (tal cual del PMS)

| Campo | Tipo | NULL | Descripción |
|-------|------|------|-------------|
| `rn_otb` | INT | No | Room nights en libros. Dato directo del PMS |
| `revenue_otb` | DECIMAL(14,2) | No | Revenue bruto de paquete pre-stay |
| `adr_otb` | DECIMAL(10,2) | No | ADR = revenue_otb / rn_otb |

### Grupo 2: OTB Proyectado (modelo Revtool)

> Lo que se espera que realmente pernocte, ajustado por cancelación esperada. **Nunca se muestra al usuario como "sus datos"**. Es herramienta interna de la IA.

| Campo | Tipo | NULL | Descripción |
|-------|------|------|-------------|
| `rn_otb_proj` | INT | No | RN proyectadas tras modelo de cancelación |
| `revenue_otb_proj` | DECIMAL(14,2) | No | Revenue proyectado |
| `adr_otb_proj` | DECIMAL(10,2) | No | ADR proyectado |

### Grupo 3: SDLY Bruto (foto misma fecha año anterior, sin ajustar)

> Compara lunes con lunes. Lo que había en libros al mismo punto del año anterior, **incluyendo reservas que luego se cancelaron**.

| Campo | Tipo | NULL | Descripción |
|-------|------|------|-------------|
| `rn_sdly_gross` | INT | Sí | RN en libros SDLY sin ajustar |
| `revenue_sdly_gross` | DECIMAL(14,2) | Sí | Revenue SDLY bruto |
| `adr_sdly_gross` | DECIMAL(10,2) | Sí | ADR SDLY bruto |

> NULL cuando el hotel no tiene datos del año anterior. La IA lo detecta dinámicamente.

### Grupo 4: SDLY Neto (misma foto, descontando cancelaciones conocidas)

> La comparación justa: "qué había en libros SDLY que realmente iba a pernoctar". Se compara con `otb_proj`.

| Campo | Tipo | NULL | Descripción |
|-------|------|------|-------------|
| `rn_sdly_net` | INT | Sí | RN SDLY netas de cancelaciones conocidas |
| `revenue_sdly_net` | DECIMAL(14,2) | Sí | Revenue SDLY neto |
| `adr_sdly_net` | DECIMAL(10,2) | Sí | ADR SDLY neto |

### Grupo 5: LY (dato final cristalizado)

> Resultado final del año anterior para la misma fecha calendario. Inherentemente neto (es lo que pasó).

| Campo | Tipo | NULL | Descripción |
|-------|------|------|-------------|
| `rn_ly` | INT | Sí | RN finales año anterior |
| `revenue_ly` | DECIMAL(14,2) | Sí | Revenue final año anterior |
| `adr_ly` | DECIMAL(10,2) | Sí | ADR final año anterior |

### Grupo 6: Forecast

| Campo | Tipo | NULL | Descripción |
|-------|------|------|-------------|
| `rn_forecast` | INT | Sí | RN previstas al cierre |
| `revenue_forecast` | DECIMAL(14,2) | Sí | Revenue previsto al cierre |
| `adr_forecast` | DECIMAL(10,2) | Sí | ADR previsto al cierre |

> NULL si no hay forecast calculado para esa fecha.

### Grupo 7: Budget (presupuesto prorrateado al día)

| Campo | Tipo | NULL | Descripción |
|-------|------|------|-------------|
| `rn_budget` | INT | Sí | RN presupuestadas |
| `revenue_budget` | DECIMAL(14,2) | Sí | Revenue presupuestado |
| `adr_budget` | DECIMAL(10,2) | Sí | ADR presupuestado |

> NULL cuando el hotel no tiene presupuesto cargado para este periodo.

### Grupo 8: Capacidad y ocupación

| Campo | Tipo | NULL | Descripción |
|-------|------|------|-------------|
| `rooms_available` | INT | No | **Total de inventario** (vendidas + libres). Es el denominador de la ocupación. Puede variar por día si hay habitaciones fuera de servicio |
| `occ_otb` | DECIMAL(5,2) | No | rn_otb / rooms_available × 100 |
| `occ_otb_proj` | DECIMAL(5,2) | No | rn_otb_proj / rooms_available × 100 |
| `occ_sdly_gross` | DECIMAL(5,2) | Sí | rn_sdly_gross / rooms_available × 100 |
| `occ_sdly_net` | DECIMAL(5,2) | Sí | rn_sdly_net / rooms_available × 100 |
| `occ_ly` | DECIMAL(5,2) | Sí | rn_ly / rooms_available × 100 |
| `occ_forecast` | DECIMAL(5,2) | Sí | rn_forecast / rooms_available × 100 |
| `occ_budget` | DECIMAL(5,2) | Sí | rn_budget / rooms_available × 100 |

### Grupo 9: Pickup 7 días (solo confirmadas)

> Reservas confirmadas que han entrado en los últimos 7 días para esta fecha de estancia. Sin cancelaciones.

| Campo | Tipo | NULL | Descripción |
|-------|------|------|-------------|
| `pickup_rn_7d` | INT | No | RN confirmadas últimos 7 días |
| `pickup_rev_7d` | DECIMAL(14,2) | No | Revenue de confirmadas 7d |
| `pickup_rn_7d_sdly` | INT | Sí | RN confirmadas mismos 7 días del año anterior |
| `pickup_rev_7d_sdly` | DECIMAL(14,2) | Sí | Revenue de confirmadas 7d SDLY |

### Grupo 10: Pickup 1 día (solo confirmadas)

> Reservas confirmadas que entraron ayer para esta fecha de estancia.

| Campo | Tipo | NULL | Descripción |
|-------|------|------|-------------|
| `pickup_rn_1d` | INT | No | RN confirmadas ayer |
| `pickup_rev_1d` | DECIMAL(14,2) | No | Revenue de confirmadas 1d |
| `pickup_rn_1d_sdly` | INT | Sí | RN confirmadas mismo día SDLY |
| `pickup_rev_1d_sdly` | DECIMAL(14,2) | Sí | Revenue de confirmadas 1d SDLY |

### Grupo 11: Cancelaciones recientes (ventana)

> Cancelaciones que ocurrieron en la ventana temporal. Para detectar tendencias de cancelación recientes.
> **Los valores son siempre POSITIVOS (absolutos)**, nunca negativos. Representan coste de oportunidad:
> reservas que se hicieron originalmente pero se cancelaron a posteriori, por lo que ni las roomnights
> ni la producción se cristalizaron. Ejemplo: cancel_rn_7d = 5 significa que se cancelaron 5 RN,
> no que las RN bajaron -5.

| Campo | Tipo | NULL | Descripción |
|-------|------|------|-------------|
| `cancel_rn_7d` | INT | No | RN canceladas últimos 7 días (valor absoluto positivo) |
| `cancel_rev_7d` | DECIMAL(14,2) | **Sí*** | Revenue cancelado 7d (valor absoluto positivo) |
| `cancel_rn_1d` | INT | No | RN canceladas ayer (valor absoluto positivo) |
| `cancel_rev_1d` | DECIMAL(14,2) | **Sí*** | Revenue cancelado 1d (valor absoluto positivo) |

> \* NULL cuando el PMS no proporciona revenue de cancelaciones

### Grupo 12: Tasas de cancelación acumuladas (total para esa stay_date)

> Tasas de cancelación acumuladas. Solo se almacenan las tasas (ratios), no los valores absolutos de RN ni revenue cancelado.

| Campo | Tipo | NULL | Descripción |
|-------|------|------|-------------|
| `cancel_rate_otb` | DECIMAL(5,2) | No | Tasa de cancelación acumulada OTB (%) |
| `cancel_rate_sdly` | DECIMAL(5,2) | Sí | Tasa cancelación SDLY |
| `cancel_rate_ly` | DECIMAL(5,2) | Sí | Tasa cancelación final LY |

> La tasa de cancelación se calcula por RN en PowerBI antes del envío: `cancel_rn / (rn_otb + cancel_rn) × 100`.

**Total de campos por fila**: ~49 (sin contar id, hotel_name, stay_date, timestamps)

---

## Tablas 3-6: Dimensionales diarias (`daily_hotel_segment` / `channel` / `roomtype` / `mealplan`)

> **TOP 5 PER DIMENSION PER DAY (principio de Pareto):** Solo se envían las 5 dimensiones
> con mayor `rn_otb` por hotel × stay_date. Esto reduce el volumen drásticamente (~37%)
> mientras retiene los valores que tienen impacto real (~80% del revenue/RN).
> Solo se generan filas para días con venta (rn_otb > 0 para al menos un valor de la dimensión).
> Para el detalle completo de TODOS los valores de dimensión, se usan las tablas mensuales.
>
> Desglose diario por dimensión. **Cada tabla lleva el MISMO set completo de métricas** que
> `daily_hotel_summary` (OTB, OTB Proj, SDLY Gross, SDLY Net, LY, Forecast, Budget, ocupación,
> pickup 7d/1d, cancelaciones ventana/acumuladas).
>
> Se documentan como un bloque porque la estructura de métricas es idéntica.
> Solo varía el campo de dimensión y el cálculo de ocupación.

### Claves únicas

| Tabla | Clave UPSERT |
|-------|-------------|
| `daily_hotel_segment` | `hotel_name` + `stay_date` + `segment_name` (VARCHAR 100) |
| `daily_hotel_channel` | `hotel_name` + `stay_date` + `channel_name` (VARCHAR 200) |
| `daily_hotel_roomtype` | `hotel_name` + `stay_date` + `room_type_name` (VARCHAR 100) |
| `daily_hotel_mealplan` | `hotel_name` + `stay_date` + `meal_plan_name` (VARCHAR 50) |

### Ocupación: cálculo diferente por tabla

| Tabla | `rooms_available` | Cálculo de `occ_*` |
|-------|-------------------|-------------------|
| segment, channel, mealplan | NO tiene — usa el del summary | `rn / rooms_available del hotel` (contribución a ocupación total) |
| roomtype | SÍ tiene (inventario físico del tipo) | `rn / rooms_available del tipo` (ocupación propia) |

### Campos de dimensión (uno por tabla) + ranking

| Campo | Tipo | NULL | Descripción |
|-------|------|------|-------------|
| `segment_name` | VARCHAR(100) | No | Nombre del segmento de mercado, texto libre desde PowerBI |
| `channel_name` | VARCHAR(200) | No | Nombre del canal de distribución, texto libre desde PowerBI |
| `room_type_name` | VARCHAR(100) | No | Nombre del tipo de habitación, texto libre desde PowerBI |
| `meal_plan_name` | VARCHAR(50) | No | Nombre del régimen alimenticio, texto libre desde PowerBI |

### Métricas (idénticas en las 4 tablas)

Todos los grupos de métricas de `daily_hotel_summary` aplican aquí:

- **Grupo 1: OTB** — `rn_otb`, `revenue_otb`, `adr_otb`
- **Grupo 2: OTB Proyectado** — `rn_otb_proj`, `revenue_otb_proj`, `adr_otb_proj`
- **Grupo 3: SDLY Bruto** — `rn_sdly_gross`, `revenue_sdly_gross`, `adr_sdly_gross` (Sí NULL)
- **Grupo 4: SDLY Neto** — `rn_sdly_net`, `revenue_sdly_net`, `adr_sdly_net` (Sí NULL)
- **Grupo 5: LY** — `rn_ly`, `revenue_ly`, `adr_ly` (Sí NULL)
- **Grupo 6: Forecast** — `rn_forecast`, `revenue_forecast`, `adr_forecast` (Sí NULL)
- **Grupo 7: Budget** — `rn_budget`, `revenue_budget`, `adr_budget` (Sí NULL)
- **Grupo 8: Ocupación** — `occ_otb`, `occ_otb_proj`, `occ_sdly_gross`, `occ_sdly_net`, `occ_ly`, `occ_forecast`, `occ_budget` (todos Sí NULL excepto occ_otb en segment/channel/mealplan que es nullable)
- **Grupo 9: Pickup 7d** — `pickup_rn_7d`, `pickup_rev_7d`, `pickup_rn_7d_sdly`, `pickup_rev_7d_sdly`
- **Grupo 10: Pickup 1d** — `pickup_rn_1d`, `pickup_rev_1d`, `pickup_rn_1d_sdly`, `pickup_rev_1d_sdly`
- **Grupo 11: Cancelaciones ventana** — `cancel_rn_7d`, `cancel_rev_7d`, `cancel_rn_1d`, `cancel_rev_1d`
- **Grupo 12: Tasas de cancelación acumuladas** — `cancel_rate_otb`, `cancel_rate_sdly`, `cancel_rate_ly`

Además, `rooms_available` (INT, Sí NULL) solo en `daily_hotel_roomtype`.

> **Nota sobre ADR por canal**: El ADR de Booking incluirá su comisión (~17%). El ADR de un touroperador no incluirá su margen. Esto es correcto y deliberado: se trabaja con el bruto de facturación del hotel. La IA no penaliza canales por comisión.

---

## Tabla 7: `daily_pricing_strategy`

> Las 3 palancas de revenue management operativo. Una fila por hotel × fecha de estancia futura. Es INPUT para la IA: lo que el modelo Revtool recomienda como señales de acción.

**Clave única**: `hotel_name` + `stay_date`

### Palanca 1: Control de intermediarios

| Campo | Tipo | NULL | Descripción |
|-------|------|------|-------------|
| `close_intermediaries` | BOOLEAN | No | `true` = el forecast prevé que el hotel va a llenar y puede empezar a filtrar intermediarios de menor contribución. **La IA NO especifica cuáles cerrar**, presenta el análisis de mix y deja la decisión al hotelero |

### Palanca 2: Ajuste de precio

| Campo | Tipo | NULL | Descripción |
|-------|------|------|-------------|
| `price_delta` | INT | No | Euros enteros a **sumar o restar** al precio configurado en el channel manager. Ej: `+12` = subir 12€, `-10` = bajar 10€, `0` = mantener |

### Palanca 3: Análisis de estancia mínima

| Campo | Tipo | NULL | Descripción |
|-------|------|------|-------------|
| `rooms_remaining` | INT | No | Habitaciones que quedan libres (sin vender) para esta fecha de estancia |
| `rooms_remaining_diff_prev` | INT | No | `rooms_remaining(stay_date - 1) - rooms_remaining(stay_date)`. **Positivo** = el día anterior tiene más habitaciones libres que este → **este día está más lleno** |
| `rooms_remaining_diff_next` | INT | No | `rooms_remaining(stay_date + 1) - rooms_remaining(stay_date)`. **Positivo** = el día siguiente tiene más habitaciones libres que este → **este día está más lleno** |

> **Interpretación de los diffs para la IA:**
>
> | diff_prev | diff_next | Significado | Acción |
> |-----------|-----------|-------------|--------|
> | + | + | **PICO**: esta fecha está más llena que ambas vecinas | Recomendar estancia mínima para aplanar la curva de ocupación y no bloquear estancias largas |
> | - | - | **VALLE**: esta fecha tiene más disponibilidad que sus vecinas | No restringir, dejar vender libre |
> | + | - | Transición descendente: el pico está a la izquierda | Analizar contexto, posible cola de pico |
> | - | + | Transición ascendente: el pico está a la derecha | Analizar contexto, posible entrada a pico |
>
> **El objetivo de la estancia mínima es llevar una ocupación lo más plana posible**. Cuando se detecta un pico, la restricción de estancia mínima fuerza a que las nuevas reservas cubran también los días adyacentes, distribuyendo la demanda y evitando que un día lleno aísle a los contiguos de captar estancias largas (más rentables).

---

## Tabla 7b: `daily_pricing_strategy_by_roomtype`

> Las mismas 3 palancas de revenue management que `daily_pricing_strategy`, pero desglosadas
> **por tipo de habitación**. Para hoteles que gestionan cada tipología de forma independiente,
> no por derivación desde una habitación base.
>
> No todos los hoteles necesitan esta tabla. Solo los que reconocen que cada tipo de habitación
> es un "sub-hotel" con sus propios ritmos de demanda, velocidad de reserva y dinámica competitiva.
>
> `room_type_name` es texto libre embebido, con la misma nomenclatura que `daily_hotel_roomtype`.

**Clave única**: `hotel_name` + `stay_date` + `room_type_name`

### Palanca 1: Control de intermediarios (por tipo de habitación)

| Campo | Tipo | NULL | Descripción |
|-------|------|------|-------------|
| `close_intermediaries` | BOOLEAN | No | `true` = el forecast prevé que ESTE TIPO de habitación va a llenar y puede empezar a filtrar intermediarios de menor contribución para esta tipología. |

### Palanca 2: Ajuste de precio (por tipo de habitación)

| Campo | Tipo | NULL | Descripción |
|-------|------|------|-------------|
| `price_delta` | INT | No | Euros enteros a **sumar o restar** al precio de ESTE TIPO de habitación. Ej: `+12` = subir 12€, `-10` = bajar 10€, `0` = mantener |

### Palanca 3: Análisis de estancia mínima (por tipo de habitación)

| Campo | Tipo | NULL | Descripción |
|-------|------|------|-------------|
| `rooms_remaining` | INT | No | Habitaciones DE ESTE TIPO que quedan libres para esta fecha |
| `rooms_remaining_diff_prev` | INT | No | `rooms_remaining(stay_date - 1) - rooms_remaining(stay_date)` para este tipo. **Positivo** = el día anterior tiene más habitaciones libres de este tipo → **este día está más lleno** |
| `rooms_remaining_diff_next` | INT | No | `rooms_remaining(stay_date + 1) - rooms_remaining(stay_date)` para este tipo. **Positivo** = el día siguiente tiene más habitaciones libres de este tipo → **este día está más lleno** |

> **Nota**: La interpretación de los diffs es idéntica a la de `daily_pricing_strategy`
> (ver tabla de interpretación en Tabla 7), pero aplicada a cada tipo de habitación
> individualmente. Un tipo puede estar en pico mientras otro tiene valle para la misma fecha.

---

## Tabla 8: `monthly_hotel_summary`

> Mismos KPIs que `daily_hotel_summary` pero agregados al mes. Una fila por hotel × año × mes.

**Clave única**: `hotel_name` + `year` + `month_num`

### Campos de contexto del mes

| Campo | Tipo | NULL | Descripción |
|-------|------|------|-------------|
| `year` | SMALLINT | No | Año |
| `month_num` | SMALLINT | No | Mes (1-12) |
| `rooms_available` | INT | No | Capacidad total del mes = rooms_available sumadas de todos los días |

> **Nota**: `is_closed` NO es una columna física. Se calcula dinámicamente en la vista `v_monthly_summary`:
> mes cerrado si `(year < año_actual) OR (year = año_actual AND month_num < mes_actual)`.
> Esto evita que un valor estático de PowerBI quede desactualizado si no se ejecuta la carga.

### Métricas (misma estructura que daily, agregadas)

Todos los campos de los grupos 1-12 de `daily_hotel_summary` aplican aquí, con estas diferencias:
- Los RN son **SUM** de los diarios
- Los Revenue son **SUM** de los diarios
- Los ADR se **recalculan**: SUM(revenue) / SUM(rn)
- Las ocupaciones se **recalculan**: SUM(rn) / rooms_available × 100
- Los pickup son **SUM** de los diarios (total de entrada al mes en la ventana)
- Las cancelaciones son **SUM** de las diarias
- Las tasas de cancelación se **recalculan** desde los SUM de RN

> **NUNCA promediar** ADR, ocupación o tasas de cancelación. Siempre recalcular desde los valores base.

---

## Tablas 9-12: Mensuales dimensionales (`monthly_hotel_segment` / `channel` / `roomtype` / `mealplan`)

> **TODOS los valores de dimensión** — sin límite top-5 a nivel mensual. Mientras las tablas
> diarias solo almacenan el top 5, las mensuales son la fuente de verdad para el análisis
> dimensional completo (todos los segmentos, canales, tipos de habitación y regímenes).
>
> Versión mensual de las tablas 3-6. **Llevan el MISMO set completo de métricas** que
> `monthly_hotel_summary` (OTB, OTB Proj, SDLY Gross, SDLY Net, LY, Forecast, Budget,
> ocupación, pickup 7d/1d, cancelaciones ventana/acumuladas), más shares.

### Claves únicas

| Tabla | Clave UPSERT |
|-------|-------------|
| `monthly_hotel_segment` | `hotel_name` + `year` + `month_num` + `segment_name` (VARCHAR 100) |
| `monthly_hotel_channel` | `hotel_name` + `year` + `month_num` + `channel_name` (VARCHAR 200) |
| `monthly_hotel_roomtype` | `hotel_name` + `year` + `month_num` + `room_type_name` (VARCHAR 100) |
| `monthly_hotel_mealplan` | `hotel_name` + `year` + `month_num` + `meal_plan_name` (VARCHAR 50) |

### Ocupación: cálculo diferente por tabla

| Tabla | `rooms_available` | Cálculo de `occ_*` |
|-------|---------------------|-------------------|
| segment, channel, mealplan | NO tiene — usa el del summary | `rn / rooms_available del hotel` (contribución) |
| roomtype | SÍ tiene (inventario físico del tipo) | `rn / rooms_available del tipo` (ocupación propia) |

### Métricas (idénticas en las 4 tablas)

Todos los grupos de métricas de `monthly_hotel_summary` aplican aquí (con `DECIMAL(16,2)` para revenue):

- **Grupos 1-7**: OTB, OTB Proj, SDLY Gross, SDLY Net, LY, Forecast, Budget (rn + revenue + adr cada uno)
- **Grupo 8: Ocupación** — `occ_otb`, `occ_otb_proj`, `occ_sdly_gross`, `occ_sdly_net`, `occ_ly`, `occ_forecast`, `occ_budget`
- **Grupos 9-10: Pickup** — pickup 7d y 1d (rn + rev + sdly)
- **Grupos 11-12: Cancelaciones** — ventana (7d/1d) y tasas acumuladas (cancel_rate_otb/sdly/ly)

Además:

| Campo | Tipo | NULL | Descripción |
|-------|------|------|-------------|
| `rooms_available` | INT | Sí | Solo en `monthly_hotel_roomtype`: inventario físico mensual del tipo |
| `share_rn_otb` | DECIMAL(5,2) | No | % de los RN totales del hotel que representa esta dimensión |
| `share_revenue_otb` | DECIMAL(5,2) | No | % del revenue total del hotel |

---

## Tabla 13: `monthly_hotel_guest_country`

> Desglose mensual por país de origen del huésped. **Mismo set completo de métricas** que las
> tablas 9-12, con `country_name` como texto libre embebido directamente (no hay tabla dimensional).
> Ocupación = `rn / rooms_available del hotel` (contribución, sin rooms_available propio).
>
> ⚠️ **Dato solo fiable para meses cerrados**. Para meses abiertos/futuros, muchas reservas no
> tendrán país asignado (la nacionalidad se asigna en el check-in). La IA debe advertir.

**Clave única**: `hotel_name` + `year` + `month_num` + `country_name`

El campo de dimensión es `country_name` (VARCHAR 100, texto libre desde PowerBI, ej: "España", "United Kingdom").

Las métricas son las mismas que las tablas 9-12 (grupos 1-12 completos + shares). Ver sección anterior.

---

## Tabla 14: `users`

> Usuarios autenticados vía Microsoft Entra ID (Azure AD).
> Tabla mínima: solo necesitamos el UPN para autenticar y rastrear.
> No hay perfil ni roles. El idioma de la conversación lo determina la IA automáticamente según el idioma en que escriba el usuario.
> **PRIMARY KEY**: `upn`

| Campo | Tipo | NULL | Descripción |
|-------|------|------|-------------|
| `upn` | VARCHAR(200) | No | Microsoft UPN (user@domain.com). **PRIMARY KEY** |
| `active` | BOOLEAN | No | ¿Está activo? Default: `TRUE` |
| `first_login_at` | TIMESTAMPTZ | Sí | Primer login registrado |
| `last_login_at` | TIMESTAMPTZ | Sí | Último login registrado |

> Esta tabla se crea automáticamente en el primer login del usuario. No requiere carga desde PowerBI.

---

## Tabla 15: `user_hotel_access`

> Mapeo de qué hoteles puede ver cada usuario. Acceso binario: si la fila existe, el usuario tiene acceso.
> Para revocar acceso, se elimina la fila. No hay niveles de acceso ni expiración.
> **PRIMARY KEY compuesta**: `(upn, hotel_name)`
>
> No tiene FK a `users`: el acceso se puede pre-cargar antes del primer login del usuario.
> Sí tiene FK a `dim_hotels`: el hotel debe existir antes de cargar el acceso.

| Campo | Tipo | NULL | Descripción |
|-------|------|------|-------------|
| `upn` | VARCHAR(200) | No | UPN del usuario (parte de la PK compuesta) |
| `hotel_name` | VARCHAR(200) | No | Referencia a `dim_hotels.hotel_name` (parte de la PK compuesta) |

---

## Nota sobre dimensiones

> **No existen tablas de catálogo separadas** para segmentos, canales, tipos de habitación ni regímenes alimenticios.
> Todas las dimensiones se embeben como **texto libre** directamente en las tablas de hechos
> (`segment_name`, `channel_name`, `room_type_name`, `meal_plan_name`, `country_name`).
> La única tabla dimensional es `dim_hotels`, que usa `hotel_name` como PRIMARY KEY.
>
> Esto simplifica el ETL (no hay que sincronizar catálogos) y permite que cada hotel
> nombre sus segmentos, canales y tipos como quiera sin restricciones.

---

## Tablas que se ELIMINAN del esquema anterior

| Tabla | Motivo |
|-------|--------|
| `daily_pickup` | Todo el pickup (1d, 7d) y cancelaciones recientes están embebidos en `daily_hotel_summary` |
| `daily_recommendations` | Reemplazada por `daily_pricing_strategy` con estructura completamente diferente |

---

## Resumen de tablas y volumen estimado

| Tabla | Filas/año/hotel | Frecuencia de carga |
|-------|-----------------|---------------------|
| `dim_hotels` | 1 | Cuando cambia |
| `daily_hotel_summary` | ≤365 (solo días abiertos) | Diaria (sobrescribe) |
| `daily_hotel_segment` | ~1.825 | Diaria (sobrescribe, top 5 por día) |
| `daily_hotel_channel` | ~1.825 | Diaria (sobrescribe, top 5 por día — antes ~7.300) |
| `daily_hotel_roomtype` | ~1.825 | Diaria (sobrescribe, top 5 por día — antes ~2.920) |
| `daily_hotel_mealplan` | ~1.825 | Diaria (sobrescribe, top 5 por día) |
| `daily_pricing_strategy` | ~365 | Diaria (sobrescribe) |
| `daily_pricing_strategy_by_roomtype` | ~2.920 | Diaria (sobrescribe, ~8 tipos × 365 días) |
| `monthly_hotel_summary` | ≤12 (solo meses con inventario) | Diaria (sobrescribe) |
| `monthly_hotel_segment` | ~60 | Diaria (sobrescribe, TODOS los segmentos) |
| `monthly_hotel_channel` | ~240 | Diaria (sobrescribe, TODOS los canales) |
| `monthly_hotel_roomtype` | ~96 | Diaria (sobrescribe, TODOS los tipos) |
| `monthly_hotel_mealplan` | ~48 | Diaria (sobrescribe, TODOS los regímenes) |
| `monthly_hotel_guest_country` | ~300 | Diaria (TODOS los países, solo fiable meses cerrados) |
| `users` | Variable | Cuando cambia |
| `user_hotel_access` | Variable | Cuando cambia |
| `credit_balance` | 1 por usuario | Automático (topup/consumo) |
| `credit_transactions` | Variable | Automático (cada topup/interacción) |

**Total por hotel/año: ~12.000 filas** (con top-5 daily). Para 50 hoteles: ~600K filas. Mínimo para PostgreSQL.

> **Nota**: Las tablas `credit_balance` y `credit_transactions` NO se cargan desde PowerBI. Se gestionan automáticamente por la aplicación (topups vía Stripe, consumo por interacción con la IA).

---

## Flujo de carga diaria (Power Automate)

```
1. PowerBI calcula todos los campos según esta especificación
2. Power Automate ejecuta diariamente:
   a. UPSERT daily_hotel_summary         (ON CONFLICT hotel_name, stay_date → UPDATE)
   b. UPSERT daily_hotel_segment         (ON CONFLICT hotel_name, stay_date, segment_name → UPDATE) — TOP 5 by rn_otb
   c. UPSERT daily_hotel_channel         (ON CONFLICT hotel_name, stay_date, channel_name → UPDATE) — TOP 5 by rn_otb
   d. UPSERT daily_hotel_roomtype        (ON CONFLICT hotel_name, stay_date, room_type_name → UPDATE) — TOP 5 by rn_otb
   e. UPSERT daily_hotel_mealplan        (ON CONFLICT hotel_name, stay_date, meal_plan_name → UPDATE) — TOP 5 by rn_otb
   f. UPSERT daily_pricing_strategy      (ON CONFLICT hotel_name, stay_date → UPDATE)
   f2. UPSERT daily_pricing_strategy_by_roomtype (ON CONFLICT hotel_name, stay_date, room_type_name → UPDATE)
   g. UPSERT monthly_hotel_summary       (ON CONFLICT hotel_name, year, month_num → UPDATE)
   h. UPSERT monthly_hotel_segment       (ON CONFLICT hotel_name, year, month_num, segment_name → UPDATE)
   i. UPSERT monthly_hotel_channel       (ON CONFLICT hotel_name, year, month_num, channel_name → UPDATE)
   j. UPSERT monthly_hotel_roomtype      (ON CONFLICT hotel_name, year, month_num, room_type_name → UPDATE)
   k. UPSERT monthly_hotel_mealplan      (ON CONFLICT hotel_name, year, month_num, meal_plan_name → UPDATE)
   l. UPSERT monthly_hotel_guest_country (ON CONFLICT hotel_name, year, month_num, country_name → UPDATE)
3. dim_hotels es la única tabla dimensional separada. Se actualiza solo cuando hay cambios (ON CONFLICT hotel_name → UPDATE)
4. Users y user_hotel_access se mantienen según gestión de accesos
5. updated_at es automático (NOW() en el SQL de UPSERT). NO enviar desde Power Automate
```
