# Revtool AI — Viability Review & Diagnostic

**Date:** 2026-02-27
**Scope:** Full codebase review — architecture, AI layer, business logic, security, frontend, data model
**Branch:** claude/review-ai-viability-50IzY

---

## 1. Project Coherence: HIGH

The project is architecturally well-designed with no significant inconsistencies:

- **Data model**: Coherent end-to-end. 3 layers (daily facts, monthly aggregations, pricing strategy) cover all necessary scenarios. Pareto optimization (top-5 daily, complete monthly) is smart and well-documented.
- **Data flow**: PowerBI → Power Automate → PostgreSQL → Claude → User. Clean, unambiguous.
- **Security**: 4-layer defense-in-depth for hotel data isolation. Unusual quality for an MVP.
- **Monetization**: Prepaid credit system with Stripe, race condition protection, complete audit trail.
- **System prompt**: 1,310 lines with deep revenue management domain knowledge — the real intellectual property of the product.

## 2. Real AI Capabilities

### What it does effectively:

| Capability | Level | Comment |
|-----------|-------|---------|
| Performance diagnosis (OTB vs SDLY vs LY) | **High** | Direct access to real PMS data, pre-calculated comparisons |
| Pickup and cancellation analysis | **High** | 1d/7d window data with SDLY comparison |
| Pricing signals (raise/lower/close channels) | **High** | Pre-calculated by Revtool model, AI contextualizes |
| Occupancy peak detection | **High** | rooms_remaining_diff_prev/next well designed |
| Dimensional analysis (channels, segments, types) | **High** | Top-5 daily + complete monthly |
| Sector benchmark comparison | **Medium-High** | Spain only (sectorial data), rest requires web search |
| Portfolio analysis (group mode) | **High** | Rankings, outliers, cross-hotel patterns, correct aggregation |
| Campaign targeting | **Medium** | 12-month historical profiles, but no execution platform integration |
| Event/date resolution | **Medium-High** | Uses LLM knowledge + web search, no calendar table |
| Conversational memory (48h) | **Medium** | Functional but loses context after 2 days |

### What it does NOT do:

- Does not execute actions (no PMS/Channel Manager/OTA connection)
- No proprietary ML models (forecast is deterministic: projected OTB + adjusted historical)
- No automated dynamic pricing (suggests deltas, someone must implement them)
- No real-time competitor analysis (only sectorial benchmark for Spain)
- No exportable reports (all conversational — no PDF, Excel, or persistent dashboard)

## 3. Can It Be Presented as a "Digital Revenue Manager"?

**Yes, with proper positioning.**

Viable denomination: **diagnostic and analysis assistant**, not autonomous revenue management system.

> An always-available revenue analyst with data updated every morning, who masters sector metrics and can answer any performance, pricing, and distribution question in seconds — but doesn't touch the channel manager buttons.

## 4. Replacement Capacity Assessment

### vs. Junior Revenue Director (diagnostic portion):

- AI covers **70-80% of diagnostic work** a junior would do
- A data-inexperienced junior will make errors the AI won't (averaging percentages, confusing gross/net SDLY, not detecting forecast = OTB due to missing history)
- But a junior **learns, scales, executes, and takes responsibility**
- **Conclusion**: AI is a **multiplier** for the junior, not a substitute. A junior WITH the AI equals 2-3 juniors without it.

### vs. External Consultancy (diagnostic and recommendations):

- For **recurring diagnosis** (how's the month going? what about weekend pricing?) the AI **replaces 80-90%** of consultant work
- For **deep strategic analysis** (repositioning, channel mix changes, new market entry) the AI **falls short** — lacks market context, distributor relationships, and strategic creativity
- **Conclusion**: AI can **drastically reduce dependency** on external consultancy for daily operations, but doesn't eliminate the need for occasional strategic advice.

### What the AI does BETTER than humans:

| Function | Why |
|---------|-----|
| Data access speed | Junior takes 20-30 min for a PowerBI report. AI responds in 10 seconds. |
| Availability | 24/7, no agendas, no emails, no waiting for Monday meetings |
| Methodological consistency | Always calculates ADR, OCC, RevPAR the same way |
| Daily operational briefing | What takes a junior 1-2 hours is one question here |
| Portfolio analysis | Comparing 10+ hotels simultaneously — consultancy takes days |
| Cost | ~0.30€ per interaction vs 150-500€/hour consultancy |

### What humans do BETTER:

| Function | Why |
|---------|-----|
| Qualitative context | Staff issues, road works, influencer mentions — not in data |
| Relationships & negotiation | Booking contracts, TO renegotiation — requires humans |
| Strategic creativity | Packages, local partnerships, experiential marketing |
| Execution | Actually changing prices, opening/closing channels |
| Market intuition | New airline routes, shifting tourist patterns |
| Accountability | AI doesn't answer for its recommendations |

## 5. Differential Strengths

1. **System prompt is the core IP** — 1,310 lines of distilled revenue management knowledge with edge cases only experienced practitioners would cover
2. **Cost architecture is viable** — ~0.30€/interaction, a hotel doing 20 queries/day spends ~180€/month (order of magnitude cheaper than any human alternative)
3. **Serious multi-tenant security** — 4-layer defense is production-grade
4. **Dual mode (hotel vs group)** — same system serves operational RM and chain director

## 6. Risks and Honest Limitations

| Risk | Severity | Current Mitigation |
|------|----------|-------------------|
| LLM hallucination | Medium | System doesn't invent data (SQL-sourced), but may misinterpret results |
| Claude dependency | High | 100% Anthropic. No fallback if API goes down or prices increase |
| Limited forecast | Medium | Deterministic, not ML. Works well with history, just OTB without it |
| No execution | High (perception) | User expects "do it" but AI only says "do this". Expectation gap |
| 48h memory | Medium | Loses long-term strategic context. No cumulative hotel learning |
| No tests | High (tech debt) | 0 unit or integration tests in repository. Production risk |
| File attachments | Low | Documented but not implemented. Feature gap vs documentation |

## 7. Final Verdict

**Is it viable as a product?** Yes, clearly. Architecture is solid, domain knowledge is deep, cost model is sustainable.

**Can it be sold as "Digital Revenue"?** Yes, if positioned as a **24/7 diagnostic and recommendation assistant**, not as an autonomous revenue manager.

**Does it replace junior/consultancy for diagnostics?** In 70-80% of daily operational diagnostics, **yes**. In strategy, creativity, execution, and accountability, **no**. The product's sweet spot is **democratizing access to revenue diagnostics** for hotels that can't afford a dedicated revenue manager or permanent consultancy.
