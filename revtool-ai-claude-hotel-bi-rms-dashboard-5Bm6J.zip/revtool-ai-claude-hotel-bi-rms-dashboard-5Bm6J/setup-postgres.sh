#!/usr/bin/env bash
# =============================================================================
# Revtool AI — PostgreSQL Setup for Ubuntu 24.04 LTS
#
# This script installs PostgreSQL 16 from the Ubuntu apt repository,
# creates the revtool user and database, and configures access from
# Docker containers via the docker0 bridge network.
#
# Usage:
#   sudo bash setup-postgres.sh
#
# After running this script, set the DATABASE_URL in backend/.env:
#   - From Docker:  postgresql+asyncpg://revtool:<PASSWORD>@host.docker.internal:5432/revtool_ai
#   - From host:    postgresql+asyncpg://revtool:<PASSWORD>@localhost:5432/revtool_ai
# =============================================================================

set -euo pipefail

# --- Configuration ---
DB_USER="revtool"
DB_NAME="revtool_ai"
PG_VERSION="16"
PG_CONF_DIR="/etc/postgresql/${PG_VERSION}/main"
DOCKER_SUBNET="172.17.0.0/16"
DOCKER_GATEWAY="172.17.0.1"

# --- Must run as root ---
if [[ $EUID -ne 0 ]]; then
  echo "Error: this script must be run as root (sudo)."
  exit 1
fi

# --- Prompt for password ---
read -rsp "Enter password for PostgreSQL user '${DB_USER}': " DB_PASSWORD
echo
if [[ -z "$DB_PASSWORD" ]]; then
  echo "Error: password cannot be empty."
  exit 1
fi

echo "==> Installing PostgreSQL ${PG_VERSION}..."
apt-get update -qq
apt-get install -y -qq postgresql postgresql-contrib

echo "==> Starting PostgreSQL service..."
systemctl enable postgresql
systemctl start postgresql

echo "==> Creating user '${DB_USER}' and database '${DB_NAME}'..."
sudo -u postgres psql -v ON_ERROR_STOP=1 <<SQL
DO \$\$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = '${DB_USER}') THEN
    CREATE ROLE ${DB_USER} WITH LOGIN PASSWORD '${DB_PASSWORD}';
  ELSE
    ALTER ROLE ${DB_USER} WITH PASSWORD '${DB_PASSWORD}';
  END IF;
END
\$\$;

SELECT 'CREATE DATABASE ${DB_NAME} OWNER ${DB_USER}'
WHERE NOT EXISTS (SELECT FROM pg_database WHERE datname = '${DB_NAME}')
\gexec

GRANT ALL PRIVILEGES ON DATABASE ${DB_NAME} TO ${DB_USER};
\c ${DB_NAME}
GRANT ALL ON SCHEMA public TO ${DB_USER};
SQL

echo "==> Configuring PostgreSQL to listen on Docker bridge (${DOCKER_GATEWAY})..."
# Add docker gateway to listen_addresses if not already present
if grep -q "^listen_addresses" "${PG_CONF_DIR}/postgresql.conf"; then
  # Replace existing listen_addresses line
  sed -i "s/^listen_addresses.*/listen_addresses = 'localhost, ${DOCKER_GATEWAY}'/" \
    "${PG_CONF_DIR}/postgresql.conf"
else
  echo "listen_addresses = 'localhost, ${DOCKER_GATEWAY}'" >> "${PG_CONF_DIR}/postgresql.conf"
fi

echo "==> Adding pg_hba.conf rule for Docker subnet (${DOCKER_SUBNET})..."
HBA_RULE="host    ${DB_NAME}    ${DB_USER}    ${DOCKER_SUBNET}    scram-sha-256"
if ! grep -qF "${DOCKER_SUBNET}" "${PG_CONF_DIR}/pg_hba.conf"; then
  echo "" >> "${PG_CONF_DIR}/pg_hba.conf"
  echo "# Allow connections from Docker containers (bridge network)" >> "${PG_CONF_DIR}/pg_hba.conf"
  echo "${HBA_RULE}" >> "${PG_CONF_DIR}/pg_hba.conf"
fi

echo "==> Restarting PostgreSQL..."
systemctl restart postgresql

echo "==> Running schema migrations..."
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SQL_DIR="${SCRIPT_DIR}/sql"

if [[ -d "${SQL_DIR}/schema" ]]; then
  for f in "${SQL_DIR}"/schema/0*.sql; do
    echo "    Running $(basename "$f")..."
    PGPASSWORD="${DB_PASSWORD}" psql -U "${DB_USER}" -h localhost -d "${DB_NAME}" -f "$f" -q
  done
else
  echo "    WARNING: ${SQL_DIR}/schema not found — skipping schema migrations."
fi

if [[ -f "${SQL_DIR}/views/001_analytical_views.sql" ]]; then
  echo "    Running views/001_analytical_views.sql..."
  PGPASSWORD="${DB_PASSWORD}" psql -U "${DB_USER}" -h localhost -d "${DB_NAME}" \
    -f "${SQL_DIR}/views/001_analytical_views.sql" -q
fi

echo ""
echo "==> Done! PostgreSQL ${PG_VERSION} is ready."
echo ""
echo "    Database:  ${DB_NAME}"
echo "    User:      ${DB_USER}"
echo "    Host port: 5432"
echo ""
echo "    From Docker containers, connect to: host.docker.internal:5432"
echo "    From the host, connect to:          localhost:5432"
echo ""
echo "    Next steps:"
echo "    1. Set DATABASE_URL in backend/.env"
echo "    2. Run: docker compose up -d"
