# Revtool AI

Extensión de IA para los clientes de Revtool que ya usan PowerBI. Los Revenue Managers consultan sus datos de hotel en lenguaje natural y reciben análisis, recomendaciones de pricing y comparativas de cartera — directamente desde su PowerBI o desde una web ligera.

No es un producto standalone. Es un add-on para clientes existentes: sus datos ya están en PowerBI, Revtool AI los aprovecha para ofrecer un chat inteligente.

```
PMS (hotel) → PowerBI (ya existente) → Power Automate → PostgreSQL → Revtool AI Chat
                                                                      (web o embebido en PowerBI)
```

---

## Tabla de contenidos

- [Arquitectura general](#arquitectura-general)
- [Stack tecnológico](#stack-tecnológico)
- [Servicios externos requeridos](#servicios-externos-requeridos)
- [Base de datos](#base-de-datos)
- [Variables de entorno](#variables-de-entorno)
- [Guía de configuración](#guía-de-configuración)
- [Pipeline de datos (ETL diario)](#pipeline-de-datos-etl-diario)
- [Modelo de IA](#modelo-de-ia)
- [Sistema de créditos y facturación](#sistema-de-créditos-y-facturación)
- [Multi-tenancy](#multi-tenancy)
- [Estructura del repositorio](#estructura-del-repositorio)
- [Documentación detallada](#documentación-detallada)

---

## Arquitectura general

```
┌────────────┐     ┌──────────┐     ┌────────────────┐     ┌────────────┐     ┌──────────────┐
│  Hotel PMS │────▶│ PowerBI  │────▶│ Power Automate │────▶│ PostgreSQL │────▶│ Revtool Chat │
│  (origen)  │     │ (tenant) │     │   (tenant)     │     │ (central)  │     │    (IA)      │
└────────────┘     └──────────┘     └────────────────┘     └────────────┘     └──────────────┘
                   Calcula KPIs     UPSERT diario          Fuente de          Claude Sonnet
                   por hotel        ~10K filas/hotel        verdad única       + SQL + chat
```

### Flujo resumido

1. **PMS** genera datos de reservas, cancelaciones, histórico
2. **PowerBI** refresca diariamente y calcula ~49 KPIs por hotel/día
3. **Power Automate** envía esos KPIs a PostgreSQL mediante UPSERT
4. **Revtool AI Chat** (web pública o embebido en PowerBI) permite consultar vía chat
5. **La IA** genera SQL, analiza resultados y responde con recomendaciones
6. **Créditos** se deducen por consulta (prepago vía Stripe)

### Opciones de despliegue del chat

| Opción | Descripción | Cuándo usar |
|--------|-------------|-------------|
| **Web pública** | App web en `revtool.thetotalprofitjourney.com` | Acceso rápido sin abrir PowerBI |
| **Embebido en PowerBI** | iFrame dentro del report PowerBI del cliente | Experiencia integrada, todo en un sitio |

Ambas opciones comparten el mismo backend, la misma autenticación (Microsoft Entra ID) y la misma base de datos. La diferencia es solo dónde se renderiza el frontend.

---

## Stack tecnológico

| Componente | Tecnología |
|-----------|-----------|
| Base de datos | PostgreSQL |
| Autenticación | Microsoft Entra ID (Azure AD) |
| BI / Transformación | Microsoft PowerBI |
| ETL | Microsoft Power Automate |
| Modelo IA | Claude Sonnet 4.5 (`claude-sonnet-4-5-20250929`) |
| Pagos | Stripe Checkout |

---

## Servicios externos requeridos

### 1. Microsoft Entra ID (Azure AD) — Multi-tenant
- **Función**: Autenticación de usuarios
- **Proporciona**: UPN (User Principal Name) como identificador único
- **Protocolo**: OAuth 2.0
- **Multi-tenant**: Cualquier usuario con cuenta Microsoft de trabajo (cualquier tenant Azure AD) puede autenticarse. La autorización se controla vía las tablas `users` y `user_hotel_access`

### 2. Microsoft PowerBI
- **Función**: Conecta al PMS del hotel y calcula todos los KPIs
- **Arquitectura**: Un workspace por tenant/cliente
- **Refresco**: Programado (típicamente de madrugada)

### 3. Microsoft Power Automate
- **Función**: ETL — mueve datos de PowerBI a PostgreSQL
- **Arquitectura**: Un flujo por tenant/cliente
- **Trigger**: Se dispara tras el refresco de PowerBI
- **Operación**: UPSERT idempotente sobre 16 tablas

### 4. Anthropic (Claude API)
- **Función**: Motor de IA para el chat
- **Modelo principal**: Claude Sonnet 4.5 (`claude-sonnet-4-5-20250929`) — chat, SQL, análisis
- **Modelo secundario**: Claude Haiku 4.5 (`claude-haiku-4-5-20251001`) — resúmenes de conversación
- **Capacidades**: Generación de SQL, análisis de datos, recomendaciones de pricing

### 5. Stripe
- **Función**: Procesamiento de pagos para recarga de créditos
- **Modo**: Stripe Checkout (página hosted)
- **Webhooks**: `checkout.session.completed`, `charge.refunded`

### 6. PostgreSQL
- **Función**: Base de datos central (multi-tenant, shared)
- **Todas las tablas en un solo esquema**, aisladas por `hotel_name`

---

## Base de datos

### Esquema completo

**Dimensión (1 tabla)**

| Tabla | Clave | Descripción |
|-------|-------|-------------|
| `dim_hotels` | `hotel_name` | Catálogo de hoteles + metadata (tipo, ubicación, config benchmark) |

**Facts diarios (7 tablas)** — ~49 métricas por fila

| Tabla | Clave | Descripción |
|-------|-------|-------------|
| `daily_hotel_summary` | `hotel_name, stay_date` | KPIs diarios a nivel hotel |
| `daily_hotel_segment` | `hotel_name, stay_date, segment_name` | Desglose por segmento |
| `daily_hotel_channel` | `hotel_name, stay_date, channel_name` | Desglose por canal |
| `daily_hotel_roomtype` | `hotel_name, stay_date, room_type_name` | Desglose por tipo habitación |
| `daily_hotel_mealplan` | `hotel_name, stay_date, meal_plan_name` | Desglose por régimen |
| `daily_pricing_strategy` | `hotel_name, stay_date` | 3 palancas RM a nivel hotel (precio, intermediarios, inventario) |
| `daily_pricing_strategy_by_roomtype` | `hotel_name, stay_date, room_type_name` | 3 palancas RM por tipo de habitación |

**Facts mensuales (6 tablas)** — mismas métricas agregadas al mes

| Tabla | Clave | Descripción |
|-------|-------|-------------|
| `monthly_hotel_summary` | `hotel_name, year, month_num` | KPIs mensuales a nivel hotel |
| `monthly_hotel_segment` | `hotel_name, year, month_num, segment_name` | Desglose por segmento |
| `monthly_hotel_channel` | `hotel_name, year, month_num, channel_name` | Desglose por canal |
| `monthly_hotel_roomtype` | `hotel_name, year, month_num, room_type_name` | Desglose por tipo habitación |
| `monthly_hotel_mealplan` | `hotel_name, year, month_num, meal_plan_name` | Desglose por régimen |
| `monthly_hotel_guest_country` | `hotel_name, year, month_num, country_name` | Desglose por nacionalidad |

**Benchmark sectorial (2 tablas)** — datos del sector para set competitivo

| Tabla | Clave | Descripción |
|-------|-------|-------------|
| `benchmark_categories` | `category_name` | Categorías fijas: Economy, Midscale, Upper Midscale, Upscale, Upper Upscale, Luxury |
| `benchmark_sectorial` | `country, ccaa, province, zone, category, year, month_num` | OCC, ADR, RevPAR del sector (actual + LY + YoY). Datos pasados cristalizados + futuros proyectados |

**Acceso y facturación (9 tablas)**

| Tabla | Clave | Descripción |
|-------|-------|-------------|
| `users` | `upn` | Usuarios (se crean en primer login) |
| `user_hotel_access` | `upn, hotel_name` | Acceso binario usuario → hotel |
| `user_billing_profile` | `upn` | Perfil de empresa para facturación (nombre, NIF, dirección, país, provincia, email notificaciones). Determina si aplica IVA |
| `stripe_customers` | `upn` | Mapeo UPN → Stripe Customer ID |
| `credit_balance` | `upn` | Saldo actual materializado |
| `credit_transactions` | `id` (serial) | Log inmutable de movimientos de crédito |
| `token_usage_log` | `id` (serial) | Registro por consulta IA (tokens, coste, modelo) |
| `sales_ledger` | `id` (serial) | Registro de cada recarga con snapshot de datos de empresa y desglose IVA (para exportar al ERP) |
| `conversation_summaries` | `upn, summary_date` | Resumen acumulativo por usuario y día UTC (rolling 48h) |

**Vistas analíticas (10 vistas)**

| Vista | Fuente | Función |
|-------|--------|---------|
| `v_daily_summary` | daily_hotel_summary + dim_hotels | Datos diarios con info del hotel |
| `v_monthly_summary` | monthly_hotel_summary + dim_hotels | Datos mensuales + `is_closed` derivado |
| `v_ytd_summary` | monthly_hotel_summary agregado | Year-to-date (cerrados + actual + forecast) |
| `v_pricing_strategy` | daily_pricing_strategy + dim_hotels | Señales de pricing a nivel hotel (solo futuro) |
| `v_pricing_strategy_by_roomtype` | daily_pricing_strategy_by_roomtype + dim_hotels | Señales de pricing por tipo de habitación (solo futuro) |
| `v_user_credit` | credit_balance | Estado de crédito en tiempo real |
| `v_user_hotels` | user_hotel_access + dim_hotels | Hoteles accesibles por usuario (para selector) |
| `v_hotel_setup_status` | dim_hotels | Hoteles pendientes de onboarding (incluye estado benchmark) |
| `v_benchmark_geo` | benchmark_sectorial | Jerarquía geográfica única para dropdowns del formulario |
| `v_hotel_benchmark` | dim_hotels + benchmark_sectorial | Datos del sector cruzados con cada hotel configurado |

### Métricas por fila (set completo)

Cada fila de facts incluye estos 12 grupos de métricas:

| Grupo | Campos (rn, revenue, adr) | Descripción |
|-------|---------------------------|-------------|
| OTB | `rn_otb`, `revenue_otb`, `adr_otb` | En libros (dato real del PMS) |
| OTB Proyectado | `rn_otb_proj`, `revenue_otb_proj`, `adr_otb_proj` | OTB ajustado por cancelación esperada |
| SDLY Bruto | `rn_sdly_gross`, `revenue_sdly_gross`, `adr_sdly_gross` | Mismo día semana año anterior (sin ajustar) |
| SDLY Neto | `rn_sdly_net`, `revenue_sdly_net`, `adr_sdly_net` | SDLY menos cancelaciones conocidas |
| LY | `rn_ly`, `revenue_ly`, `adr_ly` | Cierre real del año anterior |
| Forecast | `rn_forecast`, `revenue_forecast`, `adr_forecast` | Previsión de cierre |
| Budget | `rn_budget`, `revenue_budget`, `adr_budget` | Presupuesto prorrateado |
| Ocupación | `occ_otb`, `occ_otb_proj`, `occ_sdly_gross`, ... | % ocupación para cada serie |
| Pickup 7d | `pickup_rn_7d`, `pickup_rev_7d` | Reservas últimos 7 días |
| Pickup 1d | `pickup_rn_1d`, `pickup_rev_1d` | Reservas de ayer |
| Cancelaciones ventana | `cancel_rn_1d`, `cancel_rn_7d`, `cancel_rev_1d/7d` | Cancelaciones recientes |
| Cancelaciones acumuladas | `cancel_rate_otb`, `cancel_rate_sdly`, `cancel_rate_ly` | Tasas de cancelación |

---

## Variables de entorno

```bash
# ── Base de datos ──────────────────────────────────────
DATABASE_URL=postgresql+asyncpg://user:password@host:5432/revtool_ai

# ── Microsoft Entra ID (multi-tenant) ──────────────────
AZURE_CLIENT_ID=
# No se necesita TENANT_ID — la app es multi-tenant (authority: /organizations)
# No se necesita CLIENT_SECRET — el frontend usa MSAL.js (SPA, flujo implícito)

# ── Anthropic (Claude) ────────────────────────────────
ANTHROPIC_API_KEY=
CLAUDE_SONNET_MODEL=claude-sonnet-4-5-20250929
CLAUDE_HAIKU_MODEL=claude-haiku-4-5-20251001

# ── Stripe ─────────────────────────────────────────────
STRIPE_SECRET_KEY=
STRIPE_PUBLISHABLE_KEY=
STRIPE_WEBHOOK_SECRET=
STRIPE_CURRENCY=eur
STRIPE_MIN_AMOUNT_CENTS=100       # 1€ mínimo
STRIPE_MAX_AMOUNT_CENTS=50000     # 500€ máximo

# ── Aplicación ─────────────────────────────────────────
APP_HOST=0.0.0.0
APP_PORT=8000
CORS_ORIGINS=["http://localhost:3000"]

# ── Costes IA ──────────────────────────────────────────
PRICE_INPUT_PER_1K=0.003
PRICE_OUTPUT_PER_1K=0.015
COST_MULTIPLIER=3
USD_TO_EUR=0.92

# ── IVA ───────────────────────────────────────────────
VAT_RATE=21.0                     # IVA español (España peninsular + Baleares)
```

---

## Guía de configuración

### 1. Base de datos PostgreSQL

```bash
# Crear la base de datos
createdb revtool_ai

# Ejecutar los scripts de esquema en orden
psql revtool_ai < sql/schema/001_dimensions.sql
psql revtool_ai < sql/schema/002_daily_facts.sql
psql revtool_ai < sql/schema/003_monthly_facts.sql
psql revtool_ai < sql/schema/004_pricing_strategy.sql
psql revtool_ai < sql/schema/005_access_and_billing.sql
psql revtool_ai < sql/schema/006_benchmark_sectorial.sql
psql revtool_ai < sql/schema/007_pricing_strategy_by_roomtype.sql
psql revtool_ai < sql/schema/008_conversation_summaries.sql
psql revtool_ai < sql/schema/009_billing_profile.sql
psql revtool_ai < sql/views/001_analytical_views.sql

# Opcional: cargar datos de ejemplo
psql revtool_ai < sql/seeds/002_sample_data.sql
```

### 2. Microsoft Entra ID (Azure AD) — Multi-tenant

1. Ir a **Azure Portal** → Microsoft Entra ID → App registrations
2. **New registration**:
   - Name: `Revtool AI`
   - Supported account types: **Accounts in any organizational directory (Any Microsoft Entra ID tenant — Multitenant)**
   - Redirect URI: Tipo **SPA**, URL: `https://revtool.thetotalprofitjourney.com`
3. Copiar **Application (client) ID** → `AZURE_CLIENT_ID`
4. API permissions: Añadir `Microsoft Graph → User.Read` (delegated)
5. Grant admin consent

> **Nota**: No se necesita `TENANT_ID` ni `CLIENT_SECRET`. La app es multi-tenant
> y usa MSAL.js (SPA) en el frontend. El backend solo valida tokens JWT.

### 3. Stripe

1. Crear cuenta en [Stripe](https://stripe.com) (o usar existente)
2. **Dashboard → Developers → API keys**:
   - Publishable key → `STRIPE_PUBLISHABLE_KEY`
   - Secret key → `STRIPE_SECRET_KEY`
3. **Dashboard → Developers → Webhooks**:
   - Endpoint: `https://revtool.thetotalprofitjourney.com/api/stripe/webhook`
   - Eventos: `checkout.session.completed`, `charge.refunded`
   - Signing secret → `STRIPE_WEBHOOK_SECRET`
4. **Dashboard → Settings → Payment methods**: Habilitar Card, Google Pay, Apple Pay

### 4. Anthropic (Claude API)

1. Registrarse en [console.anthropic.com](https://console.anthropic.com)
2. Generar API key → `ANTHROPIC_API_KEY`
3. Configurar modelos en `.env`:
   - `CLAUDE_SONNET_MODEL=claude-sonnet-4-5-20250929` (chat principal)
   - `CLAUDE_HAIKU_MODEL=claude-haiku-4-5-20251001` (resúmenes de conversación)

### 5. PowerBI (por tenant/cliente)

1. Crear workspace en PowerBI para el cliente
2. Conectar al PMS del hotel
3. Construir dataset según [`docs/powerbi_field_spec.md`](docs/powerbi_field_spec.md)
4. Configurar scheduled refresh (ej: 05:30 diario)
5. Verificar que los campos coinciden con la especificación

### 6. Power Automate (por tenant/cliente)

1. Crear flujo en Power Automate
2. Trigger: "When a dataset refresh completes" (PowerBI)
3. Para cada tabla (16 en total, incluyendo benchmark_sectorial):
   - Leer datos del dataset PowerBI
   - Formatear como UPSERT según [`docs/power_automate_load.md`](docs/power_automate_load.md)
   - Ejecutar contra PostgreSQL
4. Añadir manejo de errores y reintentos
5. Probar con dataset pequeño antes de producción

---

## Pipeline de datos (ETL diario)

Cada día, cada tenant ejecuta su pipeline de forma independiente:

```
05:30  PowerBI Tenant A refresca (3 hoteles)
06:00  Power Automate Tenant A → UPSERT ~30K filas a PostgreSQL
06:15  ✅ Tenant A listo

07:00  PowerBI Tenant B refresca (5 hoteles)
07:30  Power Automate Tenant B → UPSERT ~50K filas
07:45  ✅ Tenant B listo

08:00  Usuarios empiezan a consultar con datos frescos
```

### Secuencia de carga (por tenant)

Power Automate ejecuta UPSERTs en este orden:

1. `dim_hotels` — Asegura que el hotel existe
2. `daily_hotel_summary` — KPIs diarios (~270 filas/hotel, ventana 270 días)
3. `daily_hotel_segment` — (~1.350 filas/hotel, top 5 × 270 días)
4. `daily_hotel_channel` — (~1.350 filas/hotel, top 5 × 270 días)
5. `daily_hotel_roomtype` — (~1.350 filas/hotel, top 5 × 270 días)
6. `daily_hotel_mealplan` — (~1.080 filas/hotel, top 4-5 × 270 días)
7. `daily_pricing_strategy` — (~270 filas/hotel, solo futuro)
8. `daily_pricing_strategy_by_roomtype` — (~2.160 filas/hotel, ~8 tipos × 270 días, solo futuro)
9. `monthly_hotel_summary` — (~36 filas/hotel, 3 años)
10. `monthly_hotel_segment` — (~180 filas/hotel)
11. `monthly_hotel_channel` — (~720 filas/hotel)
12. `monthly_hotel_roomtype` — (~288 filas/hotel)
13. `monthly_hotel_mealplan` — (~144 filas/hotel)
14. `monthly_hotel_guest_country` — (~900 filas/hotel)
15. `user_hotel_access` — Mapeo usuario → hotel
16. `benchmark_sectorial` — Datos del sector (~filas según cobertura geográfica, no por hotel)

**Total: ~10.000 UPSERTs por hotel + benchmark sectorial** (idempotente, se puede reintentar sin riesgo)

---

## Modelo de IA

### Configuración

- **Modelo**: Claude Sonnet 4.5 (`claude-sonnet-4-5-20250929`)
- **System prompt**: [`docs/ai_system_prompt.md`](docs/ai_system_prompt.md) (con variables dinámicas)
- **Idioma**: Automático — la IA responde en el idioma en que el usuario escriba

### Dos modos de análisis

| | Modo Hotel (1 hotel) | Modo Grupo (2+ hoteles) |
|--|---------------------|------------------------|
| **Persona** | Revenue Manager operativo | Director de cartera |
| **Tono** | Táctico, orientado a acción | Estratégico, comparativo |
| **Pricing** | Recomienda deltas y restricciones (hotel o por tipología) | No aplica (nivel portfolio) |
| **SQL** | Consulta tablas diarias + pricing | Consulta mensuales + comparativas |
| **Output** | Recomendaciones específicas por fecha | Rankings, alertas, tendencias |

### Onboarding de usuario y hotel

El onboarding tiene dos pasos obligatorios:

1. **Perfil de facturación** (primer login): Se muestra un modal obligatorio para rellenar los datos de empresa (nombre, NIF, email notificaciones, dirección, país, provincia). Se guarda en `user_billing_profile`. No se puede usar la app sin completarlo.

2. **Configuración de hoteles**: Cuando un hotel tiene `setup_complete = FALSE`, la IA informa al usuario y lo redirige al formulario de configuración (botón ⚙️ en la cabecera). Desde ahí se configuran: tipo, cliente objetivo, destino, provincia, ciudad, habitaciones totales, moneda, categoría de benchmark y zona geográfica. Se guarda en `dim_hotels` y no se repite.

---

## Sistema de créditos y facturación

### Modelo de negocio

- **Prepago** (no suscripción): el usuario recarga saldo y consume por consulta
- **Moneda**: EUR
- **Recarga**: 1€ – 500€ vía Stripe Checkout
- **Consumo**: Calculado por tokens usados (input + output) con markup

### Perfil de facturación (obligatorio)

Antes de poder recargar saldo, el usuario debe completar su **perfil de empresa** (botón 🏢 en la cabecera):

| Campo | Obligatorio | Descripción |
|-------|:-----------:|-------------|
| Nombre empresa | Sí | Razón social |
| NIF / CIF / VAT | Sí | Identificación fiscal |
| Email notificaciones | Sí | Para envío de facturas y comunicaciones (no es el UPN) |
| Dirección | Sí | Domicilio fiscal |
| Ciudad | Sí | Ciudad |
| País | Sí | Dropdown con países |
| Provincia | Sí | Dropdown para España, texto libre para otros |
| Código postal | No | Código postal |

El UPN del usuario se muestra pero no es editable (viene del JWT de Microsoft).

### Tratamiento del IVA

El IVA se determina automáticamente a partir del país y provincia del perfil de empresa:

| Ubicación empresa | IVA | Créditos por 100€ pagados |
|-------------------|-----|--------------------------|
| España peninsular + Baleares | 21% | 82.64€ (100/1.21) |
| Canarias | 0% | 100.00€ |
| Ceuta y Melilla | 0% | 100.00€ |
| Resto de países | 0% | 100.00€ |

- **Stripe es solo un cajero**: cobra el importe que elige el usuario, sin gestión fiscal
- **Revtool calcula el IVA** al recibir el pago exitoso (webhook)
- **Los créditos cargados = base imponible** (el importe neto sin IVA)
- Cada transacción se registra en `sales_ledger` con snapshot de los datos de empresa, para exportar al ERP

### Fórmula de coste

```
coste_usd = (tokens_input / 1000 × precio_input) + (tokens_output / 1000 × precio_output)
coste_eur = coste_usd × (1 + markup%) × tipo_cambio_usd_eur
```

### Estados de saldo

| Saldo | Estado | Comportamiento |
|-------|--------|---------------|
| > 2€ | Normal | Chat habilitado |
| ≤ 2€ y > 0€ | Aviso | Chat habilitado + banner "saldo bajo" |
| ≤ 0€ | Bloqueado | Chat deshabilitado, solo botón "Recargar" |

### Flujo de recarga

```
Usuario pulsa [Recargar] → TopupModal muestra desglose IVA → Stripe Checkout → Pago → Webhook → Calcula base/IVA → Carga créditos (base) → Registra en sales_ledger
```

- **Perfil de empresa obligatorio**: si no está completo, no se puede recargar
- El TopupModal muestra el desglose antes de pagar: base imponible, IVA, total a pagar, créditos a recibir
- Stripe gestiona solo el cobro del importe total
- Revtool almacena los datos de facturación en `user_billing_profile` y registra cada venta en `sales_ledger`
- **Idempotencia**: `payment_intent_id` evita duplicados si el webhook llega dos veces

---

## Multi-tenancy

### Arquitectura

```
Tenant A (hotel.com)              Tenant B (resort.es)
├── PowerBI Workspace propio      ├── PowerBI Workspace propio
├── Power Automate propio         ├── Power Automate propio
├── 3 hoteles                     ├── 5 hoteles
│                                 │
└─────────────┬───────────────────┘
              ▼
     PostgreSQL (compartido)
     Aislamiento por hotel_name + user_hotel_access
```

- **ETL separado**: cada tenant tiene su propio PowerBI y Power Automate
- **BD compartida**: todos los hoteles en las mismas tablas
- **Aislamiento**: `user_hotel_access` determina qué hoteles ve cada usuario
- **Fallo independiente**: si Tenant A falla, Tenant B no se ve afectado

### Volumen por escala

| Escala | Hoteles | Filas diarias | Total 3 años |
|--------|---------|--------------|--------------|
| Pequeño | 5 | ~50K UPSERTs | ~50K filas |
| Medio | 20 | ~200K UPSERTs | ~200K filas |
| Grande | 50 | ~500K UPSERTs | ~500K filas |

PostgreSQL maneja estos volúmenes sin problemas.

---

## Estructura del repositorio

```
revtool-ai/
├── README.md                              ← Este archivo
├── docker-compose.yml                     ← Backend + frontend containers
├── setup-postgres.sh                      ← Setup PostgreSQL nativo en Ubuntu 24.04
│
├── backend/
│   ├── app/
│   │   ├── main.py                        ← FastAPI entry point
│   │   ├── config.py                      ← Settings (env vars)
│   │   ├── database.py                    ← AsyncPG + SQLAlchemy async engine
│   │   ├── models/
│   │   │   └── schemas.py                 ← Pydantic request/response models
│   │   ├── middleware/
│   │   │   ├── auth.py                    ← Microsoft Entra ID JWT validation
│   │   │   ├── credits.py                 ← Balance check + cost calculation + deduction
│   │   │   └── hotel_access.py            ← Hotel access control + SQL validation
│   │   ├── routers/
│   │   │   ├── chat.py                    ← POST /api/chat (main AI flow)
│   │   │   ├── session.py                 ← GET /api/session (user context)
│   │   │   ├── hotels.py                  ← Hotel config CRUD
│   │   │   ├── billing_profile.py         ← Billing profile GET/PUT
│   │   │   └── stripe_routes.py           ← Stripe checkout + webhooks + balance
│   │   └── services/
│   │       ├── ai.py                      ← AI orchestration (prompt, SQL, execution)
│   │       └── conversation.py            ← Conversation summary management (Haiku)
│   ├── requirements.txt
│   ├── Dockerfile
│   └── .env.example
│
├── frontend/
│   ├── src/
│   │   ├── main.tsx                       ← React entry point + MSAL init
│   │   ├── App.tsx                        ← Root component (auth routing)
│   │   ├── pages/
│   │   │   └── ChatPage.tsx               ← Main chat interface layout
│   │   ├── components/                    ← 11 UI components
│   │   ├── hooks/
│   │   │   └── useChat.ts                 ← Chat API calls + cost display
│   │   ├── contexts/
│   │   │   └── SessionContext.tsx          ← Global session state
│   │   ├── services/
│   │   │   └── api.ts                     ← API client with MSAL tokens
│   │   ├── config/
│   │   │   ├── api.ts                     ← API base URL
│   │   │   └── msal.ts                    ← MSAL config (multi-tenant)
│   │   └── types/
│   │       └── index.ts                   ← TypeScript interfaces
│   ├── Dockerfile
│   └── .env.example
│
├── docs/
│   ├── architecture.md                    ← Arquitectura técnica detallada
│   ├── data_dictionary.md                 ← Diccionario de datos (todas las tablas y campos)
│   ├── powerbi_field_spec.md              ← Especificación de campos PowerBI
│   ├── power_automate_load.md             ← Guía de carga ETL para Power Automate
│   ├── ai_system_prompt.md                ← System prompt de la IA (con variables)
│   ├── stripe_integration.md              ← Integración Stripe (pagos y créditos)
│   └── daily_process_flow.md              ← Proceso diario completo (PMS → IA)
│
└── sql/
    ├── schema/
    │   ├── 001_dimensions.sql             ← dim_hotels
    │   ├── 002_daily_facts.sql            ← 5 tablas daily (summary + 4 dimensionales)
    │   ├── 003_monthly_facts.sql          ← 6 tablas monthly
    │   ├── 004_pricing_strategy.sql       ← daily_pricing_strategy (nivel hotel)
    │   ├── 005_access_and_billing.sql     ← users, access, créditos, Stripe
    │   ├── 006_benchmark_sectorial.sql   ← benchmark_categories + benchmark_sectorial + campos benchmark en dim_hotels
    │   ├── 007_pricing_strategy_by_roomtype.sql ← daily_pricing_strategy_by_roomtype (nivel tipo habitación)
    │   ├── 008_conversation_summaries.sql    ← conversation_summaries (resumen rolling 48h por usuario)
    │   └── 009_billing_profile.sql       ← user_billing_profile + sales_ledger (facturación e IVA)
    ├── views/
    │   └── 001_analytical_views.sql       ← 10 vistas analíticas (incluye v_pricing_strategy_by_roomtype, v_benchmark_geo y v_hotel_benchmark)
    └── seeds/
        └── 002_sample_data.sql            ← Datos de ejemplo para desarrollo
```

---

## Documentación detallada

| Documento | Audiencia | Contenido |
|-----------|-----------|-----------|
| [`architecture.md`](docs/architecture.md) | Desarrolladores | Arquitectura técnica, decisiones de diseño, multi-tenancy |
| [`data_dictionary.md`](docs/data_dictionary.md) | Desarrolladores / DBA | Todas las tablas, campos, tipos, constraints |
| [`powerbi_field_spec.md`](docs/powerbi_field_spec.md) | Consultor PowerBI | Qué campos calcular en PowerBI y cómo |
| [`power_automate_load.md`](docs/power_automate_load.md) | Consultor Power Automate | Cómo configurar los flujos de carga ETL |
| [`ai_system_prompt.md`](docs/ai_system_prompt.md) | Desarrolladores | Prompt de la IA, variables, comportamiento |
| [`stripe_integration.md`](docs/stripe_integration.md) | Desarrolladores | Flujo de pagos, webhooks, idempotencia |
| [`daily_process_flow.md`](docs/daily_process_flow.md) | Todos | Proceso completo de un día (PMS a respuesta IA) |

---

## Decisiones de diseño clave

| Decisión | Razón |
|----------|-------|
| **Claves texto** (no IDs numéricos) | PowerBI envía nombres directos. ETL más simple, joins legibles. |
| **Sin tabla calendario** | La IA resuelve festivos/eventos por conocimiento + web search. |
| **Sin snapshots** (UPSERT diario) | Pickup pre-calculado en PowerBI. Schema más simple. |
| **Sin tablas dimensionales** para segmento/canal/etc. | El nombre es la clave. No hay mapeo que sincronizar. |
| **Prepago** (no suscripción) | Consumo variable e impredecible. Pay-as-you-go más justo. |
| **Onboarding por formulario** | El RM configura sus hoteles desde el botón ⚙️ (rápido, sin consumir créditos, siempre accesible). |
| **UPN como PK** de usuario | Identificador único de Microsoft. Sin necesidad de ID propio. |
| **IVA en Revtool** (no en Stripe) | Stripe es solo un cajero. Los datos de facturación viven en Revtool (`user_billing_profile`), el IVA se calcula tras el pago, y el registro queda en `sales_ledger`. |
| **Benchmark con fallback web** | Si hay datos del sector en BD, la IA los usa. Si no, busca en la web. Cobertura parcial no bloquea. |
| **Categorías fijas STR** | 6 categorías estándar del sector (Economy→Luxury). Referencia fija, no texto libre. |

---

## Puntos de fallo y recuperación

| Punto de fallo | Impacto | Recuperación |
|---------------|---------|-------------|
| PowerBI no refresca | Datos de ayer en BD | Reintentar refresco. IA funciona con datos stale. |
| Power Automate falla | Algunos hoteles no actualizados | Reintentar (UPSERT idempotente). |
| PostgreSQL caído | Chat no funciona | Restaurar BD. Datos se re-cargan en siguiente ejecución. |
| Stripe webhook no llega | Pago OK pero crédito no sube | Stripe reintenta 3 días. Idempotencia evita duplicados. |
| Entra ID caído | Login imposible | Sesiones activas siguen. Esperar restauración Microsoft. |
| Un tenant falla | Solo sus hoteles afectados | Reintentar ese tenant. Otros no afectados. |
