"""
In-memory maintenance mode flag.

Activated before the daily data sync (truncate + reload) and deactivated
once the data is fully loaded and the email-reports job is triggered.

Because the backend runs as a single uvicorn process inside Docker,
a simple module-level variable is sufficient — no Redis/DB needed.
"""

from datetime import datetime, timezone

_maintenance_active: bool = False
_maintenance_since: datetime | None = None


def activate():
    global _maintenance_active, _maintenance_since
    _maintenance_active = True
    _maintenance_since = datetime.now(timezone.utc)


def deactivate():
    global _maintenance_active, _maintenance_since
    _maintenance_active = False
    _maintenance_since = None


def is_active() -> bool:
    return _maintenance_active


def status() -> dict:
    return {
        "maintenance": _maintenance_active,
        "since": _maintenance_since.isoformat() if _maintenance_since else None,
    }
