"""
Automated email report executor.

Run via cron:  python -m app.jobs.run_email_reports

Executes all pending report tasks in PARALLEL (up to MAX_PARALLEL_TASKS
concurrent tasks) to maximise throughput. The AnthropicRateLimiter inside
chat() is the final guard against API 429 errors — if both this process
and the web server are running, the rate limiter in each process keeps
its own budget conservative enough to share the Anthropic quota.

For each task:
1. Build system prompt for the hotel
2. Call chat() with the preconfigured report prompt
3. If error → log, skip email, continue to next task
4. If success → charge each subscriber → send email to all recipients → log

Execution order: standard reports first (all in parallel), then custom
reports (all in parallel). This ensures scheduled reports always complete
before user-defined custom reports.

Charging: each subscriber who enabled the report pays the full cost.
If two users subscribed to the same report for the same hotel, each is
charged individually (two charges for one execution).
"""

import asyncio
import logging
import smtplib
import sys
import time
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import formatdate, make_msgid
from datetime import datetime, timezone

from sqlalchemy import text

from app.config import settings
from app.database import async_session
from app.middleware.credits import (
    calculate_sonnet_cost,
    deduct_and_log,
    get_daily_exchange_rate,
)
from app.services.ai import build_system_prompt, chat
from app.services.email_reports import (
    REPORT_PROMPTS,
    REPORT_TITLES,
    ReportTask,
    CustomReportTask,
    build_report_queue,
    build_custom_report_queue,
    log_report_execution,
    get_report_title,
    _EMAIL_CONTEXT,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("email_reports")


async def _get_user_balance(db, upn: str) -> float:
    """Get current balance without raising HTTPException."""
    result = await db.execute(
        text("SELECT balance_eur FROM credit_balance WHERE upn = :upn"),
        {"upn": upn},
    )
    row = result.fetchone()
    return float(row[0]) if row else 0.0


async def _get_accessible_hotels(db, upn: str) -> list[str]:
    """Get hotels accessible to a user."""
    result = await db.execute(
        text("SELECT hotel_name FROM user_hotel_access WHERE upn = :upn ORDER BY hotel_name"),
        {"upn": upn},
    )
    return [row[0] for row in result.fetchall()]


async def _get_hotels_pending_setup(db, hotels: list[str]) -> list[str]:
    """Get hotels pending configuration."""
    if not hotels:
        return []
    result = await db.execute(
        text("""
            SELECT hotel_name FROM v_hotel_setup_status
            WHERE hotel_name = ANY(:hotels) AND setup_complete = FALSE
        """),
        {"hotels": hotels},
    )
    return [row[0] for row in result.fetchall()]


async def _get_user_language(db, upn: str) -> str:
    """Get user's preferred language."""
    result = await db.execute(
        text("SELECT preferred_language FROM users WHERE upn = :upn"),
        {"upn": upn},
    )
    row = result.fetchone()
    return row[0] if row and row[0] else "es"


async def _get_notification_emails(db, upns: list[str]) -> dict[str, str]:
    """
    Get notification emails for recipients.
    Falls back to UPN (which is the Microsoft email) if no billing profile email.
    """
    emails = {}
    for upn in upns:
        result = await db.execute(
            text("""
                SELECT notification_email FROM user_billing_profile WHERE upn = :upn
            """),
            {"upn": upn},
        )
        row = result.fetchone()
        emails[upn] = row[0] if row and row[0] else upn
    return emails


def _html_to_plain_text(html: str) -> str:
    """Convert HTML email body to readable plain text."""
    import re
    text = html
    # Remove style/script blocks
    text = re.sub(r"<style[^>]*>.*?</style>", "", text, flags=re.DOTALL)
    # Convert <br> and block-level tags to newlines
    text = re.sub(r"<br\s*/?>", "\n", text, flags=re.IGNORECASE)
    text = re.sub(r"</(p|div|h[1-6]|tr|li)>", "\n", text, flags=re.IGNORECASE)
    text = re.sub(r"<(hr)\s*/?>", "\n---\n", text, flags=re.IGNORECASE)
    # Table cells: separate with tab
    text = re.sub(r"</(td|th)>", "\t", text, flags=re.IGNORECASE)
    # Strip remaining tags
    text = re.sub(r"<[^>]+>", "", text)
    # Decode HTML entities
    import html as html_mod
    text = html_mod.unescape(text)
    # Collapse excessive blank lines
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _send_email(to_email: str, subject: str, html_body: str, max_retries: int = 3) -> bool:
    """Send an email via SMTP with retry logic. Returns True on success, False on failure."""
    if not settings.smtp_host:
        logger.info("SMTP not configured — would send to %s: %s", to_email, subject)
        return True  # Treat as success when SMTP is not configured (dev mode)

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = f"{settings.smtp_from_name} <{settings.smtp_from_email}>"
    msg["To"] = to_email
    msg["Date"] = formatdate(localtime=True)
    msg["Message-ID"] = make_msgid(domain=settings.smtp_from_email.split("@")[-1])

    # Plain-text version (strip HTML tags for a readable fallback)
    plain_text = _html_to_plain_text(html_body)
    msg.attach(MIMEText(plain_text, "plain", "utf-8"))
    msg.attach(MIMEText(html_body, "html", "utf-8"))

    last_error = None
    for attempt in range(1, max_retries + 1):
        try:
            if settings.smtp_ssl:
                server = smtplib.SMTP_SSL(
                    settings.smtp_host, settings.smtp_port,
                    timeout=settings.smtp_timeout,
                )
            else:
                server = smtplib.SMTP(
                    settings.smtp_host, settings.smtp_port,
                    timeout=settings.smtp_timeout,
                )
                server.starttls()

            with server:
                if settings.smtp_user:
                    server.login(settings.smtp_user, settings.smtp_password)
                server.send_message(msg)

            return True
        except Exception as e:
            last_error = e
            if attempt < max_retries:
                wait = 2 ** attempt  # 2s, 4s
                logger.warning(
                    "SMTP attempt %d/%d failed for %s: %s — retrying in %ds",
                    attempt, max_retries, to_email, e, wait,
                )
                time.sleep(wait)
            else:
                logger.error(
                    "Failed to send email to %s after %d attempts: %s",
                    to_email, max_retries, last_error,
                )

    return False


def _apply_bold(text: str) -> str:
    """Convert **bold** markdown to <strong> HTML tags."""
    import re
    return re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", text)


def _markdown_to_html(
    markdown_text: str,
    hotel_name: str,
    report_title: str,
    cost_eur: float | None = None,
    remaining_balance: float | None = None,
    user_language: str = "es",
) -> str:
    """Convert the AI markdown response to a simple HTML email."""
    # Escape HTML in the markdown content
    import html
    escaped = html.escape(markdown_text)
    # Convert markdown tables and formatting to basic HTML
    lines = escaped.split("\n")
    html_lines = []
    in_table = False

    for line in lines:
        stripped = line.strip()
        # Table rows
        if stripped.startswith("|") and stripped.endswith("|"):
            cells = [_apply_bold(c.strip()) for c in stripped.split("|")[1:-1]]
            if all(set(c) <= set("- :") for c in [c.strip() for c in stripped.split("|")[1:-1]]):
                continue  # Skip separator row
            if not in_table:
                html_lines.append("<table style='border-collapse:collapse;width:100%;margin:12px 0;'>")
                in_table = True
                html_lines.append("<tr>" + "".join(
                    f"<th style='border:1px solid #ddd;padding:8px;background:#f8f9fa;text-align:left;font-size:13px;'>{c}</th>"
                    for c in cells
                ) + "</tr>")
            else:
                html_lines.append("<tr>" + "".join(
                    f"<td style='border:1px solid #ddd;padding:8px;font-size:13px;'>{c}</td>"
                    for c in cells
                ) + "</tr>")
        else:
            if in_table:
                html_lines.append("</table>")
                in_table = False
            # Headers
            if stripped.startswith("### "):
                html_lines.append(f"<h3 style='color:#1e293b;margin:16px 0 8px;'>{_apply_bold(stripped[4:])}</h3>")
            elif stripped.startswith("## "):
                html_lines.append(f"<h2 style='color:#1e293b;margin:16px 0 8px;'>{_apply_bold(stripped[3:])}</h2>")
            elif stripped.startswith("# "):
                html_lines.append(f"<h1 style='color:#1e293b;margin:16px 0 8px;'>{_apply_bold(stripped[2:])}</h1>")
            elif stripped.startswith("- ") or stripped.startswith("* "):
                html_lines.append(f"<li style='margin:4px 0;font-size:14px;'>{_apply_bold(stripped[2:])}</li>")
            elif stripped.startswith(("1.", "2.", "3.", "4.", "5.", "6.", "7.", "8.", "9.")):
                html_lines.append(f"<li style='margin:4px 0;font-size:14px;'>{_apply_bold(stripped[stripped.index('.')+1:].strip())}</li>")
            elif stripped in ("---", "***", "___"):
                html_lines.append("<hr style='border:none;border-top:1px solid #e2e8f0;margin:12px 0;'/>")
            elif stripped == "":
                html_lines.append("<br/>")
            else:
                formatted = _apply_bold(stripped)
                html_lines.append(f"<p style='margin:4px 0;font-size:14px;color:#334155;'>{formatted}</p>")

    if in_table:
        html_lines.append("</table>")

    body_content = "\n".join(html_lines)
    today = datetime.now(timezone.utc).strftime("%d/%m/%Y")

    # Build cost footer line
    cost_line = ""
    if cost_eur is not None and remaining_balance is not None:
        if user_language == "en":
            cost_line = (
                f'<p style="color:#94a3b8;font-size:11px;margin:8px 0 0;">'
                f"Report cost: {cost_eur:.4f}\u202f\u20ac &mdash; "
                f"Remaining balance: {remaining_balance:.2f}\u202f\u20ac"
                f"</p>"
            )
        else:
            cost_line = (
                f'<p style="color:#94a3b8;font-size:11px;margin:8px 0 0;">'
                f"Coste de este informe: {cost_eur:.4f}\u202f\u20ac &mdash; "
                f"Saldo restante: {remaining_balance:.2f}\u202f\u20ac"
                f"</p>"
            )

    return f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8"></head>
<body style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;max-width:700px;margin:0 auto;padding:20px;background:#f8fafc;">
  <div style="background:#060734;padding:16px 24px;border-radius:12px 12px 0 0;">
    <h1 style="color:white;margin:0;font-size:18px;">
      Revtool <span style="color:#60a5fa;">AI</span>
    </h1>
  </div>
  <div style="background:white;padding:24px;border:1px solid #e2e8f0;border-top:none;border-radius:0 0 12px 12px;">
    <h2 style="color:#1e293b;margin:0 0 4px;">{report_title}</h2>
    <p style="color:#64748b;font-size:13px;margin:0 0 20px;">{hotel_name} &mdash; {today}</p>
    <hr style="border:none;border-top:1px solid #e2e8f0;margin:0 0 20px;"/>
    {body_content}
    <hr style="border:none;border-top:1px solid #e2e8f0;margin:20px 0;"/>
    <p style="color:#94a3b8;font-size:11px;margin:0;">
      {"This report was generated automatically by Revtool AI. To modify your subscriptions, go to the app and click the email icon." if user_language == "en" else "Este informe ha sido generado automáticamente por Revtool AI. Para modificar tus suscripciones, accede a la aplicación y pulsa el icono de email."}
    </p>
    {cost_line}
  </div>
</body>
</html>"""



# Max parallel email report tasks.  Matches the rate limiter's
# max_concurrent (default 20) so the limiter inside chat() is the real
# throttle.  This semaphore just prevents spawning hundreds of coroutines
# at once (DB connection pool, memory).  If both this process and the web
# server hit the Anthropic API simultaneously, the SDK retries 429s
# automatically with exponential backoff — emails always complete.
MAX_PARALLEL_TASKS = 20


async def execute_task(task: ReportTask, sem: asyncio.Semaphore) -> bool:
    """
    Execute a single report task. Returns True on success, False on failure.
    Each task opens its own DB session for safe concurrent execution.
    """
    async with sem:
        async with async_session() as db:
            return await _execute_task_inner(db, task)


async def _execute_task_inner(db, task: ReportTask) -> bool:
    """Core logic for a standard report task."""
    hotel = task.hotel_name
    report_type = task.report_type
    prompt = REPORT_PROMPTS[report_type]

    # Use first subscriber's language for shared reports
    user_language = await _get_user_language(db, task.subscriber_upns[0])
    report_title = get_report_title(report_type, user_language)

    logger.info("Executing: %s — %s", hotel, report_title)

    try:
        accessible = [hotel]
        hotels_pending = await _get_hotels_pending_setup(db, accessible)

        system_blocks = build_system_prompt(
            hotel_list=accessible,
            selected_hotels=[hotel],
            analysis_mode="hotel",
            conversation_summary="",
            balance_eur=999.99,
            hotels_pending_setup=hotels_pending,
            user_language=user_language,
        )

        ai_result = await chat(
            db=db,
            system_blocks=system_blocks,
            user_message=prompt,
            accessible_hotels=accessible,
        )

    except Exception as e:
        logger.error(
            "FAILED: %s — %s: %s", hotel, report_title, e, exc_info=True,
        )
        return False

    if ai_result.sql_queries_attempted == 0:
        logger.warning(
            "SKIPPED (no SQL executed — AI responded without querying data): %s — %s",
            hotel, report_title,
        )
        return False

    if ai_result.sql_queries_attempted > 0 and ai_result.sql_queries_succeeded == 0:
        logger.warning(
            "SKIPPED (all SQL failed): %s — %s (%d queries failed)",
            hotel, report_title, ai_result.sql_queries_failed,
        )
        return False

    # ---------------------------------------------------------------
    # Calculate cost
    # ---------------------------------------------------------------
    usd_to_eur = await get_daily_exchange_rate(db)
    cost_eur = calculate_sonnet_cost(
        tokens_input=ai_result.tokens_input,
        tokens_output=ai_result.tokens_output,
        cache_creation_tokens=ai_result.cache_creation_tokens,
        cache_read_tokens=ai_result.cache_read_tokens,
        usd_to_eur=usd_to_eur,
    )

    # ---------------------------------------------------------------
    # Charge each subscriber individually
    # ---------------------------------------------------------------
    charged_upns = []
    for upn in task.subscriber_upns:
        balance = await _get_user_balance(db, upn)
        if balance < cost_eur:
            logger.warning(
                "Cannot charge %s for %s — %s: balance %.4f < cost %.4f",
                upn, hotel, report_title, balance, cost_eur,
            )
            continue

        try:
            await deduct_and_log(
                db=db,
                upn=upn,
                tokens_input=ai_result.tokens_input,
                tokens_output=ai_result.tokens_output,
                cache_creation_tokens=ai_result.cache_creation_tokens,
                cache_read_tokens=ai_result.cache_read_tokens,
                cost_eur=cost_eur,
                usd_to_eur=usd_to_eur,
                model=settings.claude_sonnet_model,
                query_type="email_report",
                analysis_mode="hotel",
                selected_hotels=[hotel],
            )
            await db.commit()
            charged_upns.append(upn)
            logger.info("Charged %s: %.4f EUR for %s — %s", upn, cost_eur, hotel, report_title)
        except Exception as e:
            logger.error("Failed to charge %s: %s", upn, e)
            try:
                await db.rollback()
            except Exception:
                pass

    if not charged_upns:
        logger.warning(
            "No subscribers charged for %s — %s (cost absorbed: %.4f EUR)",
            hotel, report_title, cost_eur,
        )

    # ---------------------------------------------------------------
    # Send email to subscribers only (not all hotel users)
    # Each subscriber gets a personalized footer with their cost/balance
    # ---------------------------------------------------------------
    recipient_emails = await _get_notification_emails(db, task.subscriber_upns)
    subject = f"[Revtool AI] {report_title} — {hotel}"

    sent_count = 0
    for upn, email in recipient_emails.items():
        # Get updated balance after charge for this subscriber
        upn_balance = await _get_user_balance(db, upn)
        upn_cost = cost_eur if upn in charged_upns else None
        html_body = _markdown_to_html(
            ai_result.text, hotel, report_title,
            cost_eur=upn_cost,
            remaining_balance=upn_balance if upn_cost is not None else None,
            user_language=user_language,
        )
        if _send_email(email, subject, html_body):
            sent_count += 1

    logger.info(
        "Emails sent: %d/%d recipients for %s — %s",
        sent_count, len(recipient_emails), hotel, report_title,
    )

    # ---------------------------------------------------------------
    # Log execution
    # ---------------------------------------------------------------
    try:
        await log_report_execution(
            db=db,
            hotel_name=hotel,
            report_type=report_type,
            response_text=ai_result.text,
            tokens_input=ai_result.tokens_input,
            tokens_output=ai_result.tokens_output,
            cost_eur=cost_eur,
            charged_upns=charged_upns,
            recipient_upns=task.subscriber_upns,
            email_sent=sent_count > 0,
        )
    except Exception as e:
        logger.error("Failed to log report execution: %s", e)

    return True


async def execute_custom_task(task: CustomReportTask, sem: asyncio.Semaphore) -> bool:
    """
    Execute a single custom report task. Returns True on success, False on failure.
    Each task opens its own DB session for safe concurrent execution.
    """
    async with sem:
        async with async_session() as db:
            return await _execute_custom_task_inner(db, task)


async def _execute_custom_task_inner(db, task: CustomReportTask) -> bool:
    """Core logic for a custom report task."""
    hotel = task.hotel_name
    report_title = task.title
    prompt = task.prompt + "\n\n" + _EMAIL_CONTEXT

    logger.info("Executing custom: %s — %s (user: %s)", hotel, report_title, task.upn)

    try:
        accessible = [hotel]
        hotels_pending = await _get_hotels_pending_setup(db, accessible)

        # Custom reports use the owner's language
        user_language = await _get_user_language(db, task.upn)

        system_blocks = build_system_prompt(
            hotel_list=accessible,
            selected_hotels=[hotel],
            analysis_mode="hotel",
            conversation_summary="",
            balance_eur=999.99,
            hotels_pending_setup=hotels_pending,
            user_language=user_language,
        )

        ai_result = await chat(
            db=db,
            system_blocks=system_blocks,
            user_message=prompt,
            accessible_hotels=accessible,
        )

    except Exception as e:
        logger.error(
            "FAILED custom: %s — %s: %s", hotel, report_title, e, exc_info=True,
        )
        return False

    if ai_result.sql_queries_attempted == 0:
        logger.warning(
            "SKIPPED custom (no SQL executed): %s — %s", hotel, report_title,
        )
        return False

    if ai_result.sql_queries_attempted > 0 and ai_result.sql_queries_succeeded == 0:
        logger.warning(
            "SKIPPED custom (all SQL failed): %s — %s", hotel, report_title,
        )
        return False

    # Calculate cost
    usd_to_eur = await get_daily_exchange_rate(db)
    cost_eur = calculate_sonnet_cost(
        tokens_input=ai_result.tokens_input,
        tokens_output=ai_result.tokens_output,
        cache_creation_tokens=ai_result.cache_creation_tokens,
        cache_read_tokens=ai_result.cache_read_tokens,
        usd_to_eur=usd_to_eur,
    )

    # Charge the owner
    charged = False
    balance = await _get_user_balance(db, task.upn)
    if balance >= cost_eur:
        try:
            await deduct_and_log(
                db=db,
                upn=task.upn,
                tokens_input=ai_result.tokens_input,
                tokens_output=ai_result.tokens_output,
                cache_creation_tokens=ai_result.cache_creation_tokens,
                cache_read_tokens=ai_result.cache_read_tokens,
                cost_eur=cost_eur,
                usd_to_eur=usd_to_eur,
                model=settings.claude_sonnet_model,
                query_type="email_report_custom",
                analysis_mode="hotel",
                selected_hotels=[hotel],
            )
            await db.commit()
            charged = True
            logger.info("Charged %s: %.4f EUR for custom %s — %s", task.upn, cost_eur, hotel, report_title)
        except Exception as e:
            logger.error("Failed to charge %s: %s", task.upn, e)
            try:
                await db.rollback()
            except Exception:
                pass
    else:
        logger.warning(
            "Cannot charge %s for custom %s — %s: balance %.4f < cost %.4f",
            task.upn, hotel, report_title, balance, cost_eur,
        )

    # Send email only to the owner (with cost/balance footer)
    recipient_emails = await _get_notification_emails(db, [task.upn])
    subject = f"[Revtool AI] {report_title} — {hotel}"
    owner_balance = await _get_user_balance(db, task.upn)
    html_body = _markdown_to_html(
        ai_result.text, hotel, report_title,
        cost_eur=cost_eur if charged else None,
        remaining_balance=owner_balance if charged else None,
        user_language=user_language,
    )

    email_sent = False
    for upn, email in recipient_emails.items():
        if _send_email(email, subject, html_body):
            email_sent = True

    # Log execution
    try:
        await log_report_execution(
            db=db,
            hotel_name=hotel,
            report_type=0,  # 0 = custom report
            response_text=ai_result.text,
            tokens_input=ai_result.tokens_input,
            tokens_output=ai_result.tokens_output,
            cost_eur=cost_eur,
            charged_upns=[task.upn] if charged else [],
            recipient_upns=[task.upn],
            email_sent=email_sent,
        )
    except Exception as e:
        logger.error("Failed to log custom report execution: %s", e)

    return True


async def _run_batch(
    label: str,
    coroutines: list,
) -> tuple[int, int]:
    """
    Run a batch of coroutines in parallel, returning (success, fail) counts.
    """
    if not coroutines:
        return 0, 0

    logger.info("Starting %d %s tasks in parallel (max %d concurrent)...", len(coroutines), label, MAX_PARALLEL_TASKS)
    results = await asyncio.gather(*coroutines, return_exceptions=True)

    success = 0
    fail = 0
    for r in results:
        if isinstance(r, Exception):
            logger.error("Unexpected error in %s task: %s", label, r, exc_info=r)
            fail += 1
        elif r:
            success += 1
        else:
            fail += 1

    logger.info("%s batch done: %d success, %d failed", label, success, fail)
    return success, fail


async def run():
    """
    Main entry point — builds queue and executes tasks in parallel.

    Execution order: standard (scheduled) reports FIRST, then custom reports.
    This ensures scheduled reports always have priority.
    """
    logger.info("=== Email Report Executor started (parallel, max %d) ===", MAX_PARALLEL_TASKS)
    start = datetime.now(timezone.utc)

    # Build both queues using a shared session (read-only)
    async with async_session() as db:
        tasks = await build_report_queue(db)
        custom_tasks = await build_custom_report_queue(db)

    total = len(tasks) + len(custom_tasks)
    if total == 0:
        logger.info("No pending report tasks. Exiting.")
        return

    logger.info(
        "Queue built: %d standard + %d custom = %d total tasks",
        len(tasks), len(custom_tasks), total,
    )

    # Shared semaphore for all tasks — limits concurrency to MAX_PARALLEL_TASKS
    sem = asyncio.Semaphore(MAX_PARALLEL_TASKS)

    # Phase 1: Standard reports (PRIORITY — complete all before custom)
    std_success, std_fail = await _run_batch(
        "standard",
        [execute_task(task, sem) for task in tasks],
    )

    # Phase 2: Custom reports
    cust_success, cust_fail = await _run_batch(
        "custom",
        [execute_custom_task(task, sem) for task in custom_tasks],
    )

    elapsed = (datetime.now(timezone.utc) - start).total_seconds()
    logger.info(
        "=== Email Report Executor finished: %d success, %d failed, %.1fs elapsed ===",
        std_success + cust_success, std_fail + cust_fail, elapsed,
    )


if __name__ == "__main__":
    asyncio.run(run())
