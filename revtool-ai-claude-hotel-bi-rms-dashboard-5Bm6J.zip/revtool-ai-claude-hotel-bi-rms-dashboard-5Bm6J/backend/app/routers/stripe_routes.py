"""
Stripe API routes — checkout creation and webhook handling.

POST /api/stripe/create-checkout  → Creates a Stripe Checkout session
POST /api/stripe/webhook          → Handles Stripe webhook events
GET  /api/credits/balance         → Returns current credit status
"""

import logging

import stripe
from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.database import get_db
from app.middleware.auth import get_current_upn
from app.models.schemas import CreateCheckoutRequest, CreateCheckoutResponse

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api", tags=["stripe", "credits"])

stripe.api_key = settings.stripe_secret_key


# ---------------------------------------------------------------------------
# POST /api/stripe/create-checkout
# ---------------------------------------------------------------------------
@router.post("/stripe/create-checkout", response_model=CreateCheckoutResponse)
async def create_checkout(
    request: CreateCheckoutRequest,
    upn: str = Depends(get_current_upn),
    db: AsyncSession = Depends(get_db),
):
    """Creates a Stripe Checkout session for credit topup."""

    # Block if no billing profile
    profile_check = await db.execute(
        text("SELECT 1 FROM user_billing_profile WHERE upn = :upn"),
        {"upn": upn},
    )
    if not profile_check.fetchone():
        raise HTTPException(
            400,
            "Debes completar tu perfil de facturación antes de recargar saldo",
        )

    amount_cents = round(request.amount_eur * 100)

    # Validate amount range
    if amount_cents < settings.stripe_min_amount_cents:
        raise HTTPException(400, f"Mínimo: {settings.stripe_min_amount_cents / 100}€")
    if amount_cents > settings.stripe_max_amount_cents:
        raise HTTPException(400, f"Máximo: {settings.stripe_max_amount_cents / 100}€")

    # Step 1: Resolve or create Stripe Customer
    result = await db.execute(
        text("SELECT stripe_customer_id FROM stripe_customers WHERE upn = :upn"),
        {"upn": upn},
    )
    row = result.fetchone()

    if row:
        stripe_customer_id = row[0]
    else:
        customer = stripe.Customer.create(metadata={"upn": upn})
        stripe_customer_id = customer.id
        await db.execute(
            text("""
                INSERT INTO stripe_customers (upn, stripe_customer_id)
                VALUES (:upn, :cid)
            """),
            {"upn": upn, "cid": stripe_customer_id},
        )
        await db.commit()

    # Step 2: Create Checkout Session
    session = stripe.checkout.Session.create(
        mode="payment",
        customer=stripe_customer_id,
        payment_method_types=["card"],
        line_items=[
            {
                "price_data": {
                    "currency": settings.stripe_currency,
                    "unit_amount": amount_cents,
                    "product_data": {
                        "name": "Revtool AI - Recarga de saldo",
                        "description": f"Recarga de {request.amount_eur:.2f}€ para consultas IA",
                    },
                },
                "quantity": 1,
            }
        ],
        metadata={"upn": upn, "amount_eur": str(request.amount_eur)},
        customer_update={"name": "auto", "address": "auto"},
        success_url="{CHECKOUT_SESSION_ID}".join(
            settings.cors_origins[0].split("{CHECKOUT_SESSION_ID}")
        )
        if "{CHECKOUT_SESSION_ID}" in settings.cors_origins[0]
        else settings.cors_origins[0] + "/?topup=success",
        cancel_url=settings.cors_origins[0] + "/?topup=cancelled",
    )

    return CreateCheckoutResponse(checkout_url=session.url)


# ---------------------------------------------------------------------------
# POST /api/stripe/webhook
# ---------------------------------------------------------------------------
@router.post("/stripe/webhook")
async def stripe_webhook(
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    """
    Handles Stripe webhook events. Called by Stripe servers, NOT the frontend.
    The raw body is required for signature verification.
    """
    payload = await request.body()
    sig_header = request.headers.get("stripe-signature")

    try:
        event = stripe.Webhook.construct_event(
            payload, sig_header, settings.stripe_webhook_secret
        )
    except (ValueError, stripe.SignatureVerificationError) as e:
        logger.warning("Stripe webhook signature verification failed: %s", e)
        raise HTTPException(400, "Invalid webhook signature")

    # --- checkout.session.completed ---
    if event["type"] == "checkout.session.completed":
        session = event["data"]["object"]
        upn = session["metadata"]["upn"]
        amount_eur = float(session["metadata"]["amount_eur"])
        payment_intent_id = session.get("payment_intent")
        checkout_session_id = session["id"]

        # Idempotency check: skip if already processed
        existing = await db.execute(
            text("""
                SELECT id FROM credit_transactions
                WHERE stripe_payment_intent_id = :pid
            """),
            {"pid": payment_intent_id},
        )
        if existing.fetchone():
            return {"received": True}

        # Fetch billing profile to determine VAT treatment
        profile_result = await db.execute(
            text("""
                SELECT company_name, tax_id, notification_email,
                       address_line, city, province, postal_code, country,
                       vat_applicable
                FROM user_billing_profile
                WHERE upn = :upn
            """),
            {"upn": upn},
        )
        profile = profile_result.fetchone()

        if profile is None:
            logger.error("Payment received without billing profile: %s", upn)
            # Fallback: treat as no VAT, load full amount
            vat_applicable = False
        else:
            vat_applicable = profile.vat_applicable

        # Calculate base amount vs VAT
        if vat_applicable:
            vat_rate = settings.vat_rate
            base_amount = round(amount_eur / (1 + vat_rate / 100), 4)
            vat_amount = round(amount_eur - base_amount, 4)
        else:
            vat_rate = 0.0
            base_amount = amount_eur
            vat_amount = 0.0

        credits_to_load = base_amount

        # Ensure credit_balance row exists
        await db.execute(
            text("""
                INSERT INTO credit_balance (upn, balance_eur, total_topped_up, total_consumed)
                VALUES (:upn, 0, 0, 0)
                ON CONFLICT (upn) DO NOTHING
            """),
            {"upn": upn},
        )

        # Atomic: update balance with credits (base amount, not total paid)
        result = await db.execute(
            text("""
                UPDATE credit_balance
                SET balance_eur = balance_eur + :amount,
                    total_topped_up = total_topped_up + :amount,
                    last_topup_at = NOW()
                WHERE upn = :upn
                RETURNING balance_eur
            """),
            {"amount": credits_to_load, "upn": upn},
        )
        new_balance = result.fetchone()[0]

        # Log credit transaction (credits loaded = base amount)
        await db.execute(
            text("""
                INSERT INTO credit_transactions
                    (upn, transaction_type, amount_eur, balance_after,
                     stripe_payment_intent_id, stripe_checkout_session_id,
                     description, created_by)
                VALUES (:upn, 'topup', :amount, :balance, :pid, :sid,
                        :desc, 'stripe_webhook')
            """),
            {
                "upn": upn,
                "amount": credits_to_load,
                "balance": float(new_balance),
                "pid": payment_intent_id,
                "sid": checkout_session_id,
                "desc": f"Recarga: pagado {amount_eur:.2f}€, base {base_amount:.2f}€ (IVA {vat_rate}%)",
            },
        )

        # Record in sales_ledger (snapshot of billing data for invoicing)
        if profile:
            await db.execute(
                text("""
                    INSERT INTO sales_ledger
                        (upn, company_name, tax_id, notification_email,
                         address_line, city, province, postal_code, country,
                         total_paid_eur, vat_rate, base_amount_eur, vat_amount_eur,
                         credits_loaded_eur,
                         stripe_payment_intent_id, stripe_checkout_session_id)
                    VALUES
                        (:upn, :company_name, :tax_id, :notification_email,
                         :address_line, :city, :province, :postal_code, :country,
                         :total_paid, :vat_rate, :base_amount, :vat_amount,
                         :credits_loaded,
                         :pid, :sid)
                """),
                {
                    "upn": upn,
                    "company_name": profile.company_name,
                    "tax_id": profile.tax_id,
                    "notification_email": profile.notification_email,
                    "address_line": profile.address_line,
                    "city": profile.city,
                    "province": profile.province,
                    "postal_code": profile.postal_code,
                    "country": profile.country,
                    "total_paid": amount_eur,
                    "vat_rate": vat_rate,
                    "base_amount": base_amount,
                    "vat_amount": vat_amount,
                    "credits_loaded": credits_to_load,
                    "pid": payment_intent_id,
                    "sid": checkout_session_id,
                },
            )

        await db.commit()

        logger.info(
            "Topup processed: %s paid %.2f€, base %.2f€, VAT %.2f€ (%.0f%%), credits +%.2f€ (balance: %.2f€)",
            upn, amount_eur, base_amount, vat_amount, vat_rate, credits_to_load, float(new_balance),
        )

    # --- charge.refunded ---
    elif event["type"] == "charge.refunded":
        charge = event["data"]["object"]
        payment_intent_id = charge.get("payment_intent")

        # Find the original topup transaction
        result = await db.execute(
            text("""
                SELECT upn, amount_eur FROM credit_transactions
                WHERE stripe_payment_intent_id = :pid AND transaction_type = 'topup'
            """),
            {"pid": payment_intent_id},
        )
        row = result.fetchone()
        if row:
            upn, original_amount = row[0], float(row[1])
            refund_amount = charge["amount_refunded"] / 100  # cents to EUR

            result = await db.execute(
                text("""
                    UPDATE credit_balance
                    SET balance_eur = balance_eur - :amount
                    WHERE upn = :upn
                    RETURNING balance_eur
                """),
                {"amount": refund_amount, "upn": upn},
            )
            new_balance = result.fetchone()[0]

            await db.execute(
                text("""
                    INSERT INTO credit_transactions
                        (upn, transaction_type, amount_eur, balance_after,
                         stripe_refund_id, description, created_by)
                    VALUES (:upn, 'refund', :amount, :balance,
                            :rid, :desc, 'stripe_webhook')
                """),
                {
                    "upn": upn,
                    "amount": -refund_amount,
                    "balance": float(new_balance),
                    "rid": charge.get("id"),
                    "desc": f"Reembolso de {refund_amount:.2f}€ vía Stripe",
                },
            )
            await db.commit()
            logger.info("Refund processed: %s -%.2f€", upn, refund_amount)

    return {"received": True}


# ---------------------------------------------------------------------------
# GET /api/credits/balance
# ---------------------------------------------------------------------------
@router.get("/credits/balance")
async def get_balance(
    upn: str = Depends(get_current_upn),
    db: AsyncSession = Depends(get_db),
):
    """Returns current credit status for the authenticated user."""
    result = await db.execute(
        text("SELECT * FROM v_user_credit WHERE upn = :upn"),
        {"upn": upn},
    )
    row = result.fetchone()

    if row is None:
        return {
            "balance_eur": 0,
            "is_low_balance": True,
            "is_blocked": True,
            "total_topped_up": 0,
            "total_consumed": 0,
        }

    row_dict = dict(row._mapping)
    return row_dict
