"""
User billing profile routes — company data for invoicing.

GET  /api/user/billing-profile  → Returns current billing profile (or 404)
PUT  /api/user/billing-profile  → Creates or updates billing profile
"""

import logging

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.middleware.auth import get_current_upn
from app.models.schemas import BillingProfileUpdate, BillingProfileResponse

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api", tags=["billing"])


@router.get("/user/billing-profile", response_model=BillingProfileResponse)
async def get_billing_profile(
    upn: str = Depends(get_current_upn),
    db: AsyncSession = Depends(get_db),
):
    """Returns the billing profile for the authenticated user."""
    result = await db.execute(
        text("""
            SELECT upn, company_name, tax_id, notification_email,
                   address_line, city, province, postal_code, country,
                   vat_applicable
            FROM user_billing_profile
            WHERE upn = :upn
        """),
        {"upn": upn},
    )
    row = result.fetchone()

    if not row:
        raise HTTPException(404, "Perfil de facturación no configurado")

    return BillingProfileResponse(**dict(row._mapping))


@router.put("/user/billing-profile", response_model=BillingProfileResponse)
async def update_billing_profile(
    profile: BillingProfileUpdate,
    upn: str = Depends(get_current_upn),
    db: AsyncSession = Depends(get_db),
):
    """Creates or updates the billing profile for the authenticated user."""
    result = await db.execute(
        text("""
            INSERT INTO user_billing_profile
                (upn, company_name, tax_id, notification_email,
                 address_line, city, province, postal_code, country,
                 updated_at)
            VALUES
                (:upn, :company_name, :tax_id, :notification_email,
                 :address_line, :city, :province, :postal_code, :country,
                 NOW())
            ON CONFLICT (upn) DO UPDATE SET
                company_name = EXCLUDED.company_name,
                tax_id = EXCLUDED.tax_id,
                notification_email = EXCLUDED.notification_email,
                address_line = EXCLUDED.address_line,
                city = EXCLUDED.city,
                province = EXCLUDED.province,
                postal_code = EXCLUDED.postal_code,
                country = EXCLUDED.country,
                updated_at = NOW()
            RETURNING upn, company_name, tax_id, notification_email,
                      address_line, city, province, postal_code, country,
                      vat_applicable
        """),
        {
            "upn": upn,
            "company_name": profile.company_name,
            "tax_id": profile.tax_id,
            "notification_email": profile.notification_email,
            "address_line": profile.address_line,
            "city": profile.city,
            "province": profile.province,
            "postal_code": profile.postal_code,
            "country": profile.country,
        },
    )
    row = result.fetchone()
    await db.commit()

    logger.info("Billing profile saved for %s (country=%s, province=%s)",
                upn, profile.country, profile.province)

    return BillingProfileResponse(**dict(row._mapping))
