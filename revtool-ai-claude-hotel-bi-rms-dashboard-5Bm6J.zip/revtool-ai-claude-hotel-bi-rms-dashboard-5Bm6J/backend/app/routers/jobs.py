"""
Cron job endpoints — triggered via HTTP by external schedulers (e.g. Plesk cron).

Authentication: query param ?token= matching CRON_SECRET env var.
The job runs in a BackgroundTask so the HTTP response returns immediately.

GET /api/jobs/run-email-reports?token=XXX          — execute daily email report queue
GET /api/jobs/resend-pending-emails?token=XXX      — resend emails for already-generated reports
GET /api/jobs/trigger-sync?token=XXX               — launch new_revtool_json_sync.php in background
"""

import asyncio
import logging
import shutil
from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException, Query
from sqlalchemy import text
from starlette.background import BackgroundTask
from starlette.responses import JSONResponse

from app.config import settings
from app.database import async_session
from app import maintenance
from app.jobs.run_email_reports import (
    _get_notification_emails,
    _markdown_to_html,
    _send_email,
)
from app.services.email_reports import REPORT_TITLES

router = APIRouter(prefix="/api/jobs", tags=["jobs"])
logger = logging.getLogger("jobs")


def _verify_cron_secret(token: str | None):
    """Validate the cron secret token from query param."""
    if not settings.cron_secret:
        raise HTTPException(503, "CRON_SECRET not configured on server")
    if not token or token != settings.cron_secret:
        raise HTTPException(403, "Invalid or missing token")


async def _run_email_reports_job():
    """Background task: delegates to the parallel runner in run_email_reports."""
    from app.jobs.run_email_reports import run
    try:
        await run()
    except Exception:
        logger.exception("Email Report Job crashed")


@router.get("/run-email-reports")
async def run_email_reports(token: str | None = Query(default=None)):
    """
    Trigger email report execution. Returns immediately; work runs in background.
    Also deactivates maintenance mode (data is fully loaded at this point).

    Plesk cron URL:
      https://revtool.thetotalprofitjourney.com/api/jobs/run-email-reports?token=YOUR_CRON_SECRET
    """
    _verify_cron_secret(token)

    if maintenance.is_active():
        maintenance.deactivate()
        logger.info("Maintenance mode DEACTIVATED (data sync complete, email reports starting)")

    return JSONResponse(
        {"status": "started", "message": "Email report job queued for background execution."},
        background=BackgroundTask(_run_email_reports_job),
    )


# ------------------------------------------------------------------
# Resend pending emails (reports already generated but not delivered)
# ------------------------------------------------------------------

async def _resend_pending_emails_job():
    """Background task: resend emails for log entries where email_sent = FALSE."""
    logger.info("=== Resend Pending Emails started ===")
    start = datetime.now(timezone.utc)

    try:
        async with async_session() as db:
            result = await db.execute(
                text("""
                    SELECT id, hotel_name, report_type, response_text, recipient_upns
                    FROM email_report_log
                    WHERE email_sent = FALSE
                    ORDER BY executed_at ASC
                """)
            )
            rows = result.fetchall()

            if not rows:
                logger.info("No pending emails to resend. Done.")
                return

            logger.info("Found %d reports with unsent emails.", len(rows))

            sent_total = 0
            for row in rows:
                log_id, hotel_name, report_type, response_text, recipient_upns = row
                report_title = REPORT_TITLES.get(report_type, f"Report #{report_type}")
                subject = f"[Revtool AI] {report_title} — {hotel_name}"
                html_body = _markdown_to_html(response_text, hotel_name, report_title)

                recipient_emails = await _get_notification_emails(db, recipient_upns)
                sent_count = 0
                for upn, email in recipient_emails.items():
                    if _send_email(email, subject, html_body):
                        sent_count += 1

                if sent_count > 0:
                    await db.execute(
                        text("UPDATE email_report_log SET email_sent = TRUE WHERE id = :id"),
                        {"id": log_id},
                    )
                    await db.commit()
                    sent_total += 1
                    logger.info(
                        "Resent %d/%d emails for log #%d (%s — %s)",
                        sent_count, len(recipient_emails), log_id, hotel_name, report_title,
                    )
                else:
                    logger.error(
                        "Failed to resend any email for log #%d (%s — %s)",
                        log_id, hotel_name, report_title,
                    )

        elapsed = (datetime.now(timezone.utc) - start).total_seconds()
        logger.info(
            "=== Resend Pending Emails finished: %d/%d reports sent, %.1fs elapsed ===",
            sent_total, len(rows), elapsed,
        )
    except Exception:
        logger.exception("Resend Pending Emails job crashed")


@router.get("/resend-pending-emails")
async def resend_pending_emails(token: str | None = Query(default=None)):
    """
    Resend emails for reports already generated but not delivered (email_sent=FALSE).
    No AI regeneration, no charges — only email delivery.

    URL:
      https://revtool.thetotalprofitjourney.com/api/jobs/resend-pending-emails?token=YOUR_CRON_SECRET
    """
    _verify_cron_secret(token)

    return JSONResponse(
        {"status": "started", "message": "Resend pending emails job queued for background execution."},
        background=BackgroundTask(_resend_pending_emails_job),
    )


# ------------------------------------------------------------------
# Trigger JSON sync (runs new_revtool_json_sync.php on host)
# ------------------------------------------------------------------

SYNC_SCRIPT = "/var/www/vhosts/thetotalprofitjourney.com/revtool_ai/new_revtool_json_sync.php"


async def _run_sync_job():
    """Background task: execute new_revtool_json_sync.php."""
    php_bin = shutil.which("php") or "php"
    logger.info("=== Trigger Sync: launching %s %s ===", php_bin, SYNC_SCRIPT)
    try:
        proc = await asyncio.create_subprocess_exec(
            php_bin, SYNC_SCRIPT,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await proc.communicate()
        if proc.returncode != 0:
            logger.error("Sync script exited with code %d: %s", proc.returncode, stderr.decode())
        else:
            logger.info("=== Trigger Sync finished successfully ===")
    except Exception:
        logger.exception("Trigger Sync job crashed")


@router.get("/trigger-sync")
async def trigger_sync(token: str | None = Query(default=None)):
    """
    Launch new_revtool_json_sync.php in the background.
    Returns immediately; work runs in background.

    URL:
      https://revtool.thetotalprofitjourney.com/api/jobs/trigger-sync?token=YOUR_CRON_SECRET
      https://revtool.thetotalprofitjourney.com/trigger.php?token=YOUR_CRON_SECRET  (nginx alias)
    """
    _verify_cron_secret(token)

    return JSONResponse(
        {"status": "started", "time": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")},
        background=BackgroundTask(_run_sync_job),
    )


# ------------------------------------------------------------------
# Maintenance mode — activated by cron before truncate, deactivated
# when email-reports fires (data fully loaded).
# ------------------------------------------------------------------

@router.get("/maintenance-on")
async def maintenance_on(token: str | None = Query(default=None)):
    """
    Activate maintenance mode. Call this BEFORE truncating tables so the
    frontend shows a friendly "updating data" overlay.

    URL:
      https://revtool.thetotalprofitjourney.com/api/jobs/maintenance-on?token=YOUR_CRON_SECRET
    """
    _verify_cron_secret(token)
    maintenance.activate()
    logger.info("Maintenance mode ACTIVATED")
    return {"status": "maintenance_on", "since": maintenance.status()["since"]}


@router.get("/maintenance-off")
async def maintenance_off(token: str | None = Query(default=None)):
    """
    Manually deactivate maintenance mode (safety valve).

    URL:
      https://revtool.thetotalprofitjourney.com/api/jobs/maintenance-off?token=YOUR_CRON_SECRET
    """
    _verify_cron_secret(token)
    maintenance.deactivate()
    logger.info("Maintenance mode DEACTIVATED (manual)")
    return {"status": "maintenance_off"}


@router.get("/maintenance-status")
async def maintenance_status():
    """
    Public (no auth) endpoint the frontend polls to know when
    maintenance finishes.
    """
    return maintenance.status()
