"""
GET /api/session — Session initialization endpoint.

Called when the user opens the app. Returns everything the frontend needs:
- Accessible hotels (for the selector)
- Hotels pending setup
- Current balance
- Conversation summary (last 48h)
"""

from fastapi import APIRouter, Depends
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.database import get_db
from app import maintenance
from app.middleware.auth import get_current_upn
from app.middleware.hotel_access import get_accessible_hotels
from app.models.schemas import LanguageUpdate, SessionInfo
from app.services.conversation import load_summary

router = APIRouter(prefix="/api", tags=["session"])


@router.get("/session", response_model=SessionInfo)
async def get_session(
    upn: str = Depends(get_current_upn),
    db: AsyncSession = Depends(get_db),
):
    """
    Initializes the user session. Returns all context the frontend needs.
    Also triggers conversation summary purge (>48h).
    Auto-registers the user on first login (UPSERT into users + credit_balance).
    """
    # Auto-register user: ensure users row exists (needed for FK constraints
    # on credit_balance, stripe_customers, conversation_summaries, etc.)
    # Uses lowercase UPN (normalized by auth middleware).
    await db.execute(
        text("""
            INSERT INTO users (upn, first_login_at, last_login_at)
            VALUES (:upn, NOW(), NOW())
            ON CONFLICT (upn) DO UPDATE
            SET last_login_at = NOW(), updated_at = NOW()
        """),
        {"upn": upn},
    )

    # Ensure credit_balance row exists (0 balance until first topup)
    await db.execute(
        text("""
            INSERT INTO credit_balance (upn, balance_eur, total_topped_up, total_consumed)
            VALUES (:upn, 0, 0, 0)
            ON CONFLICT (upn) DO NOTHING
        """),
        {"upn": upn},
    )
    await db.commit()

    # Accessible hotels
    accessible = await get_accessible_hotels(db, upn)

    # Hotels pending setup
    if accessible:
        result = await db.execute(
            text("""
                SELECT hotel_name FROM v_hotel_setup_status
                WHERE hotel_name = ANY(:hotels) AND setup_complete = FALSE
            """),
            {"hotels": accessible},
        )
        hotels_pending = [row[0] for row in result.fetchall()]
    else:
        hotels_pending = []

    # Balance
    result = await db.execute(
        text("SELECT balance_eur FROM credit_balance WHERE upn = :upn"),
        {"upn": upn},
    )
    row = result.fetchone()
    balance = float(row[0]) if row else 0.0

    # Conversation summary (also purges old ones)
    summary = await load_summary(db, upn)

    # Billing profile
    profile_result = await db.execute(
        text("SELECT vat_applicable FROM user_billing_profile WHERE upn = :upn"),
        {"upn": upn},
    )
    profile_row = profile_result.fetchone()
    billing_complete = profile_row is not None
    vat_applicable = profile_row[0] if profile_row else None
    vat_rate = settings.vat_rate if vat_applicable else 0.0

    # Language preference
    lang_result = await db.execute(
        text("SELECT preferred_language FROM users WHERE upn = :upn"),
        {"upn": upn},
    )
    lang_row = lang_result.fetchone()
    preferred_language = lang_row[0] if lang_row and lang_row[0] else "es"

    return SessionInfo(
        upn=upn,
        accessible_hotels=accessible,
        hotels_pending_setup=hotels_pending,
        balance_eur=balance,
        conversation_summary=summary,
        billing_profile_complete=billing_complete,
        vat_applicable=vat_applicable,
        vat_rate=vat_rate,
        maintenance_active=maintenance.is_active(),
        preferred_language=preferred_language,
    )


@router.patch("/user/language")
async def update_language(
    body: LanguageUpdate,
    upn: str = Depends(get_current_upn),
    db: AsyncSession = Depends(get_db),
):
    """Update the user's preferred language (es/en)."""
    await db.execute(
        text("UPDATE users SET preferred_language = :lang WHERE upn = :upn"),
        {"lang": body.language, "upn": upn},
    )
    await db.commit()
    return {"status": "ok", "language": body.language}
