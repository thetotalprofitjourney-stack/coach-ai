"""
Email report subscription endpoints.

GET  /api/email-reports          — current subscription state (per hotel, per report type, weekdays)
PUT  /api/email-reports          — update subscriptions (hotels, report types, weekdays)
POST /api/email-reports/send-now — generate and send a report immediately
GET  /api/email-reports/custom   — list user's custom reports
POST /api/email-reports/custom   — create a custom report
PUT  /api/email-reports/custom/{id} — update a custom report
DELETE /api/email-reports/custom/{id} — delete a custom report
"""

import logging

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession
from starlette.background import BackgroundTask
from starlette.responses import JSONResponse

from app.database import get_db, async_session
from app.middleware.auth import get_current_upn
from app.services.email_reports import REPORT_TITLES

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api", tags=["email-reports"])


class HotelSubscription(BaseModel):
    hotel_name: str
    report_types: list[int]  # e.g. [1, 3]


class UpdateSubscriptionsRequest(BaseModel):
    hotels: list[HotelSubscription]
    weekdays: int | None = None  # DEPRECATED — kept for backwards compat
    weekdays_per_report: dict[str, int] | None = None  # {"1": 62, "2": 8, ...}


@router.get("/email-reports")
async def get_email_reports(
    upn: str = Depends(get_current_upn),
    db: AsyncSession = Depends(get_db),
):
    """
    Return:
      - report_types: [{report_type, title}]
      - accessible_hotels: [str]
      - subscribed_hotels: {hotel_name: [report_type, ...]}
      - weekdays_per_report: {report_type_str: bitmask}  (per report type)
      - weekdays: int (DEPRECATED — max of all per-report weekdays, for backwards compat)
    """
    # Accessible hotels for this user
    hotels_result = await db.execute(
        text("SELECT hotel_name FROM user_hotel_access WHERE upn = :upn ORDER BY hotel_name"),
        {"upn": upn},
    )
    accessible_hotels = [r[0] for r in hotels_result.fetchall()]

    # Current subscriptions
    subs_result = await db.execute(
        text("""
            SELECT hotel_name, report_type, weekdays
            FROM email_report_subscriptions
            WHERE upn = :upn AND enabled = TRUE
        """),
        {"upn": upn},
    )
    rows = subs_result.fetchall()

    subscribed_hotels: dict[str, list[int]] = {}
    # Collect weekdays per report type (take the max across hotels for each rt)
    weekdays_per_report: dict[str, int] = {}
    for row in rows:
        hotel, rt, wd = row[0], row[1], row[2]
        if hotel not in subscribed_hotels:
            subscribed_hotels[hotel] = []
        subscribed_hotels[hotel].append(rt)
        rt_key = str(rt)
        # Use OR to merge weekdays across hotels for same report type
        weekdays_per_report[rt_key] = weekdays_per_report.get(rt_key, 0) | wd

    # Fill defaults for report types not yet configured
    for rt in REPORT_TITLES:
        if str(rt) not in weekdays_per_report:
            weekdays_per_report[str(rt)] = 62  # Mon-Fri default

    report_types = [
        {"report_type": rt, "title": title}
        for rt, title in REPORT_TITLES.items()
    ]

    return {
        "report_types": report_types,
        "accessible_hotels": accessible_hotels,
        "subscribed_hotels": subscribed_hotels,
        "weekdays_per_report": weekdays_per_report,
        "weekdays": max(weekdays_per_report.values()) if weekdays_per_report else 62,
    }


@router.put("/email-reports")
async def update_email_reports(
    request: UpdateSubscriptionsRequest,
    upn: str = Depends(get_current_upn),
    db: AsyncSession = Depends(get_db),
):
    """
    Replace all subscriptions for this user.
    Deletes existing rows, inserts new ones from the request.

    Supports weekdays_per_report (new) or weekdays (legacy, applies to all).
    """
    # Build weekdays lookup per report type
    wpr: dict[int, int] = {}
    if request.weekdays_per_report:
        for rt_str, wd in request.weekdays_per_report.items():
            sanitized = int(wd) & 127
            wpr[int(rt_str)] = sanitized if sanitized else 62
    elif request.weekdays is not None:
        # Legacy: same weekdays for all
        fallback = request.weekdays & 127
        if fallback == 0:
            fallback = 62
        for rt in (1, 2, 3, 4):
            wpr[rt] = fallback
    else:
        for rt in (1, 2, 3, 4):
            wpr[rt] = 62

    # Delete all existing subscriptions for this user
    await db.execute(
        text("DELETE FROM email_report_subscriptions WHERE upn = :upn"),
        {"upn": upn},
    )

    # Insert new subscriptions
    for hotel_sub in request.hotels:
        for rt in hotel_sub.report_types:
            if rt not in (1, 2, 3, 4):
                continue
            wd = wpr.get(rt, 62)
            await db.execute(
                text("""
                    INSERT INTO email_report_subscriptions
                        (upn, hotel_name, report_type, weekdays, enabled)
                    VALUES (:upn, :hotel, :rt, :wd, TRUE)
                """),
                {"upn": upn, "hotel": hotel_sub.hotel_name, "rt": rt, "wd": wd},
            )

    await db.commit()
    return {"status": "ok"}


# ---------------------------------------------------------------------------
# Send now — on-demand report generation and delivery
# ---------------------------------------------------------------------------

class SendNowRequest(BaseModel):
    hotel_name: str
    report_type: int | None = None       # 1-4 for standard reports
    custom_report_id: int | None = None  # for custom reports


async def _send_now_job(upn: str, hotel_name: str, report_type: int | None, custom_report_id: int | None):
    """Background task: generate and send a single report immediately."""
    from app.jobs.run_email_reports import _execute_task_inner, _execute_custom_task_inner
    from app.services.email_reports import (
        REPORT_PROMPTS, CustomReportTask, ReportTask,
    )

    try:
        async with async_session() as db:
            if report_type and report_type in REPORT_PROMPTS:
                task = ReportTask(
                    hotel_name=hotel_name,
                    report_type=report_type,
                    subscriber_upns=[upn],
                )
                await _execute_task_inner(db, task)
            elif custom_report_id:
                result = await db.execute(
                    text("""
                        SELECT title, prompt FROM custom_email_reports
                        WHERE id = :id AND upn = :upn
                    """),
                    {"id": custom_report_id, "upn": upn},
                )
                row = result.fetchone()
                if not row:
                    logger.error("Send-now: custom report %d not found for %s", custom_report_id, upn)
                    return
                task = CustomReportTask(
                    custom_report_id=custom_report_id,
                    hotel_name=hotel_name,
                    title=row[0],
                    prompt=row[1],
                    upn=upn,
                )
                await _execute_custom_task_inner(db, task)
    except Exception:
        logger.exception("Send-now job failed for %s", upn)


@router.post("/email-reports/send-now")
async def send_now(
    request: SendNowRequest,
    upn: str = Depends(get_current_upn),
    db: AsyncSession = Depends(get_db),
):
    """
    Generate and send a report immediately (runs in background).
    Requires either report_type (1-4) or custom_report_id.
    """
    if not request.report_type and not request.custom_report_id:
        raise HTTPException(400, "Debes indicar report_type o custom_report_id.")
    if request.report_type and request.report_type not in (1, 2, 3, 4):
        raise HTTPException(400, "report_type debe ser 1, 2, 3 o 4.")

    # Verify user has access to this hotel
    result = await db.execute(
        text("SELECT 1 FROM user_hotel_access WHERE upn = :upn AND hotel_name = :hotel"),
        {"upn": upn, "hotel": request.hotel_name},
    )
    if not result.fetchone():
        raise HTTPException(403, "No tienes acceso a este hotel.")

    # If custom report, verify ownership
    if request.custom_report_id:
        result = await db.execute(
            text("SELECT 1 FROM custom_email_reports WHERE id = :id AND upn = :upn"),
            {"id": request.custom_report_id, "upn": upn},
        )
        if not result.fetchone():
            raise HTTPException(404, "Informe personalizado no encontrado.")

    return JSONResponse(
        {"status": "queued", "message": "Informe en cola. Lo recibirás por email en breve."},
        background=BackgroundTask(
            _send_now_job, upn, request.hotel_name, request.report_type, request.custom_report_id,
        ),
    )


# ---------------------------------------------------------------------------
# Custom email reports (user-defined prompts, private to each user)
# ---------------------------------------------------------------------------

class CreateCustomReportRequest(BaseModel):
    title: str = Field(..., min_length=1, max_length=100)
    prompt: str = Field(..., min_length=1, max_length=4000)
    weekdays: int = 62  # bitmask, default Mon-Fri
    hotel_names: list[str] = []


class UpdateCustomReportRequest(BaseModel):
    title: str = Field(..., min_length=1, max_length=100)
    prompt: str = Field(..., min_length=1, max_length=4000)
    weekdays: int = 62
    hotel_names: list[str] = []


@router.get("/email-reports/custom")
async def get_custom_reports(
    upn: str = Depends(get_current_upn),
    db: AsyncSession = Depends(get_db),
):
    """Return all custom reports for the current user."""
    result = await db.execute(
        text("""
            SELECT id, title, prompt, weekdays, active, created_at
            FROM custom_email_reports
            WHERE upn = :upn
            ORDER BY created_at
        """),
        {"upn": upn},
    )
    reports = []
    for row in result.fetchall():
        report_id = row[0]
        # Get associated hotels
        hotels_result = await db.execute(
            text("SELECT hotel_name FROM custom_email_report_hotels WHERE custom_report_id = :id"),
            {"id": report_id},
        )
        hotel_names = [r[0] for r in hotels_result.fetchall()]
        reports.append({
            "id": report_id,
            "title": row[1],
            "prompt": row[2],
            "weekdays": row[3],
            "active": row[4],
            "created_at": row[5].isoformat() if row[5] else None,
            "hotel_names": hotel_names,
        })
    return {"custom_reports": reports}


@router.post("/email-reports/custom")
async def create_custom_report(
    request: CreateCustomReportRequest,
    upn: str = Depends(get_current_upn),
    db: AsyncSession = Depends(get_db),
):
    """Create a new custom email report for the current user."""
    weekdays = request.weekdays & 127
    if weekdays == 0:
        weekdays = 62

    result = await db.execute(
        text("""
            INSERT INTO custom_email_reports (upn, title, prompt, weekdays)
            VALUES (:upn, :title, :prompt, :weekdays)
            RETURNING id
        """),
        {"upn": upn, "title": request.title, "prompt": request.prompt, "weekdays": weekdays},
    )
    report_id = result.fetchone()[0]

    # Associate hotels (only those the user has access to)
    if request.hotel_names:
        access_result = await db.execute(
            text("SELECT hotel_name FROM user_hotel_access WHERE upn = :upn"),
            {"upn": upn},
        )
        accessible = {r[0] for r in access_result.fetchall()}
        for hotel in request.hotel_names:
            if hotel in accessible:
                await db.execute(
                    text("""
                        INSERT INTO custom_email_report_hotels (custom_report_id, hotel_name)
                        VALUES (:id, :hotel)
                    """),
                    {"id": report_id, "hotel": hotel},
                )

    await db.commit()
    return {"id": report_id, "status": "created"}


@router.put("/email-reports/custom/{report_id}")
async def update_custom_report(
    report_id: int,
    request: UpdateCustomReportRequest,
    upn: str = Depends(get_current_upn),
    db: AsyncSession = Depends(get_db),
):
    """Update a custom report. Only the owner can update it."""
    # Verify ownership
    result = await db.execute(
        text("SELECT id FROM custom_email_reports WHERE id = :id AND upn = :upn"),
        {"id": report_id, "upn": upn},
    )
    if not result.fetchone():
        raise HTTPException(status_code=404, detail="Informe no encontrado.")

    weekdays = request.weekdays & 127
    if weekdays == 0:
        weekdays = 62

    await db.execute(
        text("""
            UPDATE custom_email_reports
            SET title = :title, prompt = :prompt, weekdays = :weekdays, updated_at = NOW()
            WHERE id = :id AND upn = :upn
        """),
        {"id": report_id, "upn": upn, "title": request.title,
         "prompt": request.prompt, "weekdays": weekdays},
    )

    # Replace hotel associations
    await db.execute(
        text("DELETE FROM custom_email_report_hotels WHERE custom_report_id = :id"),
        {"id": report_id},
    )
    if request.hotel_names:
        access_result = await db.execute(
            text("SELECT hotel_name FROM user_hotel_access WHERE upn = :upn"),
            {"upn": upn},
        )
        accessible = {r[0] for r in access_result.fetchall()}
        for hotel in request.hotel_names:
            if hotel in accessible:
                await db.execute(
                    text("""
                        INSERT INTO custom_email_report_hotels (custom_report_id, hotel_name)
                        VALUES (:id, :hotel)
                    """),
                    {"id": report_id, "hotel": hotel},
                )

    await db.commit()
    return {"status": "ok"}


@router.delete("/email-reports/custom/{report_id}")
async def delete_custom_report(
    report_id: int,
    upn: str = Depends(get_current_upn),
    db: AsyncSession = Depends(get_db),
):
    """Delete a custom report. Only the owner can delete it."""
    result = await db.execute(
        text("SELECT id FROM custom_email_reports WHERE id = :id AND upn = :upn"),
        {"id": report_id, "upn": upn},
    )
    if not result.fetchone():
        raise HTTPException(status_code=404, detail="Informe no encontrado.")

    # CASCADE deletes custom_email_report_hotels rows automatically
    await db.execute(
        text("DELETE FROM custom_email_reports WHERE id = :id AND upn = :upn"),
        {"id": report_id, "upn": upn},
    )
    await db.commit()
    return {"status": "deleted"}
