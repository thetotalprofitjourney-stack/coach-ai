"""
Hotel configuration endpoints.

GET  /api/hotels              → List user's hotels with config status
PUT  /api/hotels/{name}/config → Update hotel configuration
GET  /api/hotels/benchmark-geo → Get benchmark geographic options
GET  /api/hotels/benchmark-categories → Get benchmark categories
"""

import logging

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.middleware.auth import get_current_upn
from app.middleware.hotel_access import get_accessible_hotels

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/hotels", tags=["hotels"])


@router.get("")
async def list_hotels(
    upn: str = Depends(get_current_upn),
    db: AsyncSession = Depends(get_db),
):
    """Returns all hotels accessible by the user with their configuration status."""
    result = await db.execute(
        text("""
            SELECT h.hotel_name, h.destination, h.province, h.city, h.country,
                   h.hotel_type, h.target_client, h.total_rooms, h.currency,
                   h.marketing_highlights,
                   h.benchmark_category, h.benchmark_country, h.benchmark_ccaa,
                   h.benchmark_province, h.benchmark_zone, h.benchmark_available,
                   h.setup_complete, h.setup_by, h.setup_at
            FROM dim_hotels h
            JOIN user_hotel_access uha ON uha.hotel_name = h.hotel_name
            WHERE LOWER(uha.upn) = :upn AND h.active = TRUE
            ORDER BY h.hotel_name
        """),
        {"upn": upn},
    )
    rows = result.fetchall()
    columns = list(result.keys())
    return [dict(zip(columns, row)) for row in rows]


@router.put("/{hotel_name}/config")
async def update_hotel_config(
    hotel_name: str,
    config: dict,
    upn: str = Depends(get_current_upn),
    db: AsyncSession = Depends(get_db),
):
    """Updates hotel configuration. Only accessible hotels can be updated."""
    accessible = await get_accessible_hotels(db, upn)
    if hotel_name not in accessible:
        raise HTTPException(403, "No tienes acceso a este hotel.")

    allowed_fields = {
        "destination", "province", "city", "country", "hotel_type",
        "target_client", "total_rooms", "currency", "marketing_highlights",
        "benchmark_category", "benchmark_country", "benchmark_ccaa",
        "benchmark_province", "benchmark_zone", "benchmark_available",
    }

    updates = {k: v for k, v in config.items() if k in allowed_fields}
    if not updates:
        raise HTTPException(400, "No valid fields to update.")

    set_parts = [f"{k} = :{k}" for k in updates]
    set_parts.append("setup_complete = TRUE")
    set_parts.append("setup_by = :upn")
    set_parts.append("setup_at = NOW()")
    set_parts.append("updated_at = NOW()")

    params = {**updates, "upn": upn, "hotel_name": hotel_name}

    await db.execute(
        text(f"""
            UPDATE dim_hotels
            SET {', '.join(set_parts)}
            WHERE hotel_name = :hotel_name
        """),
        params,
    )
    await db.commit()

    return {"status": "ok", "hotel_name": hotel_name}


@router.get("/benchmark-geo")
async def get_benchmark_geo(
    db: AsyncSession = Depends(get_db),
):
    """Returns available benchmark geographic combinations for the dropdown."""
    result = await db.execute(
        text("""
            SELECT DISTINCT country, ccaa, province, zone,
                   ccaa || ' - ' || province || ' - ' || zone AS display_label
            FROM benchmark_sectorial
            ORDER BY country, ccaa, province, zone
        """)
    )
    rows = result.fetchall()
    columns = list(result.keys())
    return [dict(zip(columns, row)) for row in rows]


@router.get("/benchmark-categories")
async def get_benchmark_categories(
    db: AsyncSession = Depends(get_db),
):
    """Returns available benchmark categories."""
    result = await db.execute(
        text("SELECT category_name FROM benchmark_categories ORDER BY sort_order")
    )
    return [row[0] for row in result.fetchall()]
