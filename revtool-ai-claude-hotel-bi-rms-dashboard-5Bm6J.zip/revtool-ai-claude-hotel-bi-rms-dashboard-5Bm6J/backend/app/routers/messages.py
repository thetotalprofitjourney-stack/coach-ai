"""
GET /api/conversations/messages — Load persisted chat messages (last 24h).
"""

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.middleware.auth import get_current_upn
from app.services.messages import load_messages

router = APIRouter(prefix="/api", tags=["conversations"])


@router.get("/conversations/messages")
async def get_conversation_messages(
    upn: str = Depends(get_current_upn),
    db: AsyncSession = Depends(get_db),
):
    """Return chat messages from the last 24 hours for the authenticated user."""
    messages = await load_messages(db, upn)
    return {"messages": messages}
