"""
POST /api/chat — Main AI conversation endpoint (streaming).
GET  /api/chat/pending — Check if user has an in-flight background task.

Returns a StreamingResponse with ndjson events:
  {"type": "status",  "message": "..."}           — progress updates
  {"type": "delta",   "text": "..."}              — streamed response text
  {"type": "result",  "response": "...", ...}     — final result with cost
  {"type": "error",   "message": "...", ...}      — error (if streaming already started)

The AI processing runs as a background asyncio.Task decoupled from the HTTP
connection.  If the client disconnects (browser closed, page refreshed) the
task keeps running, persists the response to the database, and deducts
credits normally.  When the user returns, GET /api/conversations/messages
already returns the persisted answer.

The complete flow:
1. Auth: extract UPN from Microsoft token
2. Credit check: balance > 0?
3. Hotel access validation (Layer 2): selected ⊆ accessible?
4. Load context: conversation summary, hotel setup status
5. Build system prompt with injected variables
6. Spawn background task (AI + SQL + cost + persist)
7. Stream events from task queue while client is connected
8. If client disconnects → task continues in background
"""

import asyncio
import json
import logging
from datetime import datetime, timezone

from anthropic import RateLimitError

from app.services.rate_limiter import QueueTimeoutError
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.database import async_session, get_db
from app import maintenance
from app.middleware.auth import get_current_upn
from app.middleware.credits import (
    calculate_haiku_cost,
    calculate_sonnet_cost,
    check_balance,
    deduct_and_log,
    get_daily_exchange_rate,
)
from app.middleware.hotel_access import (
    get_accessible_hotels,
    validate_hotel_selection,
)
from app.models.schemas import ChatRequest
from app.services.ai import build_system_prompt, chat_stream
from app.services.conversation import generate_summary, load_summary, save_summary
from app.services.messages import save_message

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api", tags=["chat"])

# ---------------------------------------------------------------------------
# In-memory task registry (single-instance; lost on restart — acceptable)
# ---------------------------------------------------------------------------
_active_tasks: dict[str, asyncio.Task] = {}
_task_queues: dict[str, asyncio.Queue] = {}


def _ndjson(event: dict) -> str:
    """Serialize an event dict as a single ndjson line."""
    return json.dumps(event, ensure_ascii=False) + "\n"


# ---------------------------------------------------------------------------
# GET /api/chat/pending — frontend polls this after reconnecting
# ---------------------------------------------------------------------------
@router.get("/chat/pending")
async def chat_pending(upn: str = Depends(get_current_upn)):
    """Check if user has an active chat task still running."""
    task = _active_tasks.get(upn)
    if task and not task.done():
        return {"pending": True}
    return {"pending": False}


# ---------------------------------------------------------------------------
# Background task — runs independently of the HTTP connection
# ---------------------------------------------------------------------------
async def _run_chat_task(
    upn: str,
    queue: asyncio.Queue,
    system_blocks: list[dict],
    user_message: str,
    accessible_hotels: list[str],
    selected_hotel_names: list[str],
    analysis_mode: str,
    conversation_summary: str,
    balance: float,
) -> None:
    """
    Background task that runs AI chat, persists results, and deducts credits.

    Events are pushed to *queue* so a connected client can stream them.
    If no client is reading, events accumulate harmlessly (bounded by
    max_turns × max_tokens).  On completion the result is always persisted
    to the database.
    """
    try:
        async with async_session() as db:
            await _process_chat(
                db=db,
                queue=queue,
                upn=upn,
                system_blocks=system_blocks,
                user_message=user_message,
                accessible_hotels=accessible_hotels,
                selected_hotel_names=selected_hotel_names,
                analysis_mode=analysis_mode,
                conversation_summary=conversation_summary,
                balance=balance,
            )
    except Exception as e:
        logger.error("Background chat task crashed: %s", e, exc_info=True)
        await queue.put({
            "type": "error",
            "status": 502,
            "message": "Error interno al procesar la consulta.",
        })
    finally:
        await queue.put(None)  # Sentinel — signals stream end
        _active_tasks.pop(upn, None)
        _task_queues.pop(upn, None)


async def _process_chat(
    db: AsyncSession,
    queue: asyncio.Queue,
    upn: str,
    system_blocks: list[dict],
    user_message: str,
    accessible_hotels: list[str],
    selected_hotel_names: list[str],
    analysis_mode: str,
    conversation_summary: str,
    balance: float,
) -> None:
    """Core chat logic extracted for readability."""

    # ------------------------------------------------------------------
    # Run AI chat (multi-turn with SQL)
    # ------------------------------------------------------------------
    ai_result = None

    try:
        async for event in chat_stream(
            db=db,
            system_blocks=system_blocks,
            user_message=user_message,
            accessible_hotels=accessible_hotels,
        ):
            if event["type"] == "done":
                ai_result = event["result"]
            else:
                await queue.put(event)

    except QueueTimeoutError as e:
        logger.warning("Queue timeout: %s", e)
        await queue.put({
            "type": "error",
            "status": 429,
            "message": "El servicio tiene mucha demanda en este momento. Espera unos segundos y vuelve a intentarlo.",
        })
        return
    except RateLimitError as e:
        logger.warning("Rate limited by Anthropic: %s", e)
        await queue.put({
            "type": "error",
            "status": 429,
            "message": "El servicio está temporalmente sobrecargado. Espera unos segundos y vuelve a intentarlo.",
        })
        return
    except Exception as e:
        logger.error("AI chat failed: %s", e, exc_info=True)
        await queue.put({
            "type": "error",
            "status": 502,
            "message": "Error al procesar la consulta con la IA. Inténtalo de nuevo.",
        })
        return

    if ai_result is None:
        await queue.put({
            "type": "error",
            "status": 502,
            "message": "No se obtuvo respuesta de la IA.",
        })
        return

    # ------------------------------------------------------------------
    # Check for all-SQL-failed responses (don't charge user)
    # ------------------------------------------------------------------
    all_sql_failed = (
        ai_result.sql_queries_attempted > 0
        and ai_result.sql_queries_succeeded == 0
    )
    if all_sql_failed:
        usd_to_eur = await get_daily_exchange_rate(db)
        cost_input_usd = round((ai_result.tokens_input / 1000) * settings.price_input_per_1k, 6)
        cost_output_usd = round((ai_result.tokens_output / 1000) * settings.price_output_per_1k, 6)
        cost_cache_create_usd = round((ai_result.cache_creation_tokens / 1000) * settings.price_cache_write_per_1k, 6)
        cost_cache_read_usd = round((ai_result.cache_read_tokens / 1000) * settings.price_cache_read_per_1k, 6)
        cost_total_usd = cost_input_usd + cost_output_usd + cost_cache_create_usd + cost_cache_read_usd
        cost_eur_absorbed = round(
            cost_total_usd * settings.cost_multiplier * usd_to_eur, 6
        )

        try:
            await db.execute(
                text("""
                    INSERT INTO error_log
                        (upn, model_used, tokens_input, tokens_output,
                         cache_creation_tokens, cache_read_tokens,
                         cost_input_usd, cost_output_usd,
                         cost_cache_creation_usd, cost_cache_read_usd,
                         cost_total_usd, cost_eur_absorbed,
                         usd_to_eur_rate, markup_percent,
                         sql_queries_attempted, sql_queries_failed,
                         error_details, analysis_mode, selected_hotels,
                         user_question, created_at)
                    VALUES
                        (:upn, :model, :tin, :tout,
                         :cache_create, :cache_read,
                         :cost_in, :cost_out,
                         :cost_cache_create, :cost_cache_read,
                         :cost_total_usd, :cost_eur,
                         :usd_to_eur, :markup,
                         :sql_attempted, :sql_failed,
                         :errors, :mode, :hotels,
                         :question, :now)
                """),
                {
                    "upn": upn,
                    "model": settings.claude_sonnet_model,
                    "tin": ai_result.tokens_input,
                    "tout": ai_result.tokens_output,
                    "cache_create": ai_result.cache_creation_tokens,
                    "cache_read": ai_result.cache_read_tokens,
                    "cost_in": cost_input_usd,
                    "cost_out": cost_output_usd,
                    "cost_cache_create": cost_cache_create_usd,
                    "cost_cache_read": cost_cache_read_usd,
                    "cost_total_usd": cost_total_usd,
                    "cost_eur": cost_eur_absorbed,
                    "usd_to_eur": usd_to_eur,
                    "markup": settings.cost_multiplier,
                    "sql_attempted": ai_result.sql_queries_attempted,
                    "sql_failed": ai_result.sql_queries_failed,
                    "errors": ai_result.text[:2000],
                    "mode": analysis_mode,
                    "hotels": selected_hotel_names,
                    "question": user_message[:500],
                    "now": datetime.now(timezone.utc),
                },
            )
            await db.commit()
        except Exception as e:
            logger.error("Failed to log error to error_log table: %s", e)

        logger.warning(
            "NOT charging %s: all %d SQL queries failed. "
            "Absorbed cost: %.4f USD / %.4f EUR. Logged to error_log.",
            upn, ai_result.sql_queries_failed,
            cost_total_usd, cost_eur_absorbed,
        )
        # Persist assistant message (no charge)
        try:
            await save_message(
                db, upn, "assistant", ai_result.text,
                cost_eur=0.0, balance_after=balance,
                analysis_mode=analysis_mode,
                selected_hotels=selected_hotel_names,
            )
            await db.commit()
        except Exception as e:
            logger.error("Failed to persist assistant message: %s", e)

        await queue.put({
            "type": "result",
            "response": ai_result.text,
            "analysis_mode": analysis_mode,
            "cost_eur": 0.0,
            "balance_after": balance,
        })
        return

    # ------------------------------------------------------------------
    # Log partial SQL failures (user IS charged)
    # ------------------------------------------------------------------
    has_sql_failures = (
        ai_result.sql_queries_attempted > 0
        and ai_result.sql_queries_failed > 0
        and not all_sql_failed
    )
    if has_sql_failures:
        try:
            await db.execute(
                text("""
                    INSERT INTO error_log
                        (upn, model_used, tokens_input, tokens_output,
                         cache_creation_tokens, cache_read_tokens,
                         cost_input_usd, cost_output_usd,
                         cost_cache_creation_usd, cost_cache_read_usd,
                         cost_total_usd, cost_eur_absorbed,
                         usd_to_eur_rate, markup_percent,
                         sql_queries_attempted, sql_queries_failed,
                         error_details, analysis_mode, selected_hotels,
                         user_question, created_at)
                    VALUES
                        (:upn, :model, :tin, :tout,
                         :cache_create, :cache_read,
                         0, 0, 0, 0, 0, 0,
                         0, :markup,
                         :sql_attempted, :sql_failed,
                         :errors, :mode, :hotels,
                         :question, :now)
                """),
                {
                    "upn": upn,
                    "model": settings.claude_sonnet_model,
                    "tin": ai_result.tokens_input,
                    "tout": ai_result.tokens_output,
                    "cache_create": ai_result.cache_creation_tokens,
                    "cache_read": ai_result.cache_read_tokens,
                    "markup": settings.cost_multiplier,
                    "sql_attempted": ai_result.sql_queries_attempted,
                    "sql_failed": ai_result.sql_queries_failed,
                    "errors": f"PARTIAL FAILURE ({ai_result.sql_queries_failed}/{ai_result.sql_queries_attempted} SQL failed, user charged)",
                    "mode": analysis_mode,
                    "hotels": selected_hotel_names,
                    "question": user_message[:500],
                    "now": datetime.now(timezone.utc),
                },
            )
            await db.commit()
        except Exception as e:
            logger.error("Failed to log partial SQL failure: %s", e)

        logger.warning(
            "Partial SQL failure for %s: %d/%d SQL failed (user charged, logged to error_log)",
            upn, ai_result.sql_queries_failed, ai_result.sql_queries_attempted,
        )

    # ------------------------------------------------------------------
    # Generate conversation summary (Haiku — synchronous)
    # ------------------------------------------------------------------
    summary_result = None
    try:
        summary_result = await generate_summary(
            previous_summary=conversation_summary,
            user_message=user_message,
            ai_response=ai_result.text,
        )
    except Exception as e:
        logger.warning("Summary generation failed (continuing without it): %s", e)

    # ------------------------------------------------------------------
    # Calculate costs (Sonnet + Haiku, both with markup)
    # ------------------------------------------------------------------
    usd_to_eur = await get_daily_exchange_rate(db)

    sonnet_cost_eur = calculate_sonnet_cost(
        tokens_input=ai_result.tokens_input,
        tokens_output=ai_result.tokens_output,
        cache_creation_tokens=ai_result.cache_creation_tokens,
        cache_read_tokens=ai_result.cache_read_tokens,
        usd_to_eur=usd_to_eur,
    )

    haiku_cost_eur = 0.0
    if summary_result:
        haiku_cost_eur = calculate_haiku_cost(
            tokens_input=summary_result.tokens_input,
            tokens_output=summary_result.tokens_output,
            cache_creation_tokens=summary_result.cache_creation_tokens,
            cache_read_tokens=summary_result.cache_read_tokens,
            usd_to_eur=usd_to_eur,
        )

    total_cost_eur = round(sonnet_cost_eur + haiku_cost_eur, 4)

    # ------------------------------------------------------------------
    # Deduct credits atomically (single transaction)
    # ------------------------------------------------------------------
    balance_after = balance - total_cost_eur  # fallback estimate
    try:
        balance_after = await deduct_and_log(
            db=db,
            upn=upn,
            tokens_input=ai_result.tokens_input,
            tokens_output=ai_result.tokens_output,
            cache_creation_tokens=ai_result.cache_creation_tokens,
            cache_read_tokens=ai_result.cache_read_tokens,
            cost_eur=sonnet_cost_eur,
            usd_to_eur=usd_to_eur,
            model=settings.claude_sonnet_model,
            query_type="text",
            analysis_mode=analysis_mode,
            selected_hotels=selected_hotel_names,
        )

        if summary_result and haiku_cost_eur > 0:
            balance_after = await deduct_and_log(
                db=db,
                upn=upn,
                tokens_input=summary_result.tokens_input,
                tokens_output=summary_result.tokens_output,
                cache_creation_tokens=summary_result.cache_creation_tokens,
                cache_read_tokens=summary_result.cache_read_tokens,
                cost_eur=haiku_cost_eur,
                usd_to_eur=usd_to_eur,
                model=settings.claude_haiku_model,
                query_type="summary",
            )

        if summary_result:
            await save_summary(db, upn, summary_result.text)

        await db.commit()

        logger.info(
            "Request completed: user=%s, hotels=%s, mode=%s, turns=%d, "
            "sql=%d/%d ok, cost=%.4f EUR (sonnet=%.4f + haiku=%.4f), balance=%.4f EUR",
            upn, selected_hotel_names, analysis_mode,
            ai_result.turns_used,
            ai_result.sql_queries_succeeded, ai_result.sql_queries_attempted,
            total_cost_eur, sonnet_cost_eur, haiku_cost_eur,
            balance_after,
        )

    except HTTPException:
        # 402 — insufficient credits
        await queue.put({
            "type": "error",
            "status": 402,
            "message": "Saldo insuficiente. Recarga crédito para continuar.",
        })
        return
    except Exception as e:
        logger.error("Credit deduction failed (response was generated): %s", e, exc_info=True)

    # ------------------------------------------------------------------
    # Persist assistant message
    # ------------------------------------------------------------------
    try:
        await save_message(
            db, upn, "assistant", ai_result.text,
            cost_eur=total_cost_eur, balance_after=balance_after,
            analysis_mode=analysis_mode,
            selected_hotels=selected_hotel_names,
        )
        await db.commit()
    except Exception as e:
        logger.error("Failed to persist assistant message: %s", e)

    # ------------------------------------------------------------------
    # Final result event
    # ------------------------------------------------------------------
    await queue.put({
        "type": "result",
        "response": ai_result.text,
        "analysis_mode": analysis_mode,
        "cost_eur": total_cost_eur,
        "balance_after": balance_after,
    })


# ---------------------------------------------------------------------------
# POST /api/chat — entry point
# ---------------------------------------------------------------------------
@router.post("/chat")
async def chat_endpoint(
    request: ChatRequest,
    upn: str = Depends(get_current_upn),
    db: AsyncSession = Depends(get_db),
):
    # ------------------------------------------------------------------
    # Pre-flight checks (before streaming — can use HTTPException)
    # ------------------------------------------------------------------
    if maintenance.is_active():
        raise HTTPException(
            status_code=503,
            detail="Estamos actualizando los datos. En unos minutos estaremos de vuelta.",
        )

    balance = await check_balance(db, upn)

    accessible = await get_accessible_hotels(db, upn)
    validate_hotel_selection(request.selected_hotel_names, accessible)

    # Reject if user already has an active task
    existing = _active_tasks.get(upn)
    if existing and not existing.done():
        raise HTTPException(
            status_code=409,
            detail="Ya hay una consulta en proceso. Espera a que termine.",
        )

    analysis_mode = "hotel" if len(request.selected_hotel_names) == 1 else "group"

    conversation_summary = await load_summary(db, upn)

    result = await db.execute(
        text("""
            SELECT hotel_name FROM v_hotel_setup_status
            WHERE hotel_name = ANY(:hotels) AND setup_complete = FALSE
        """),
        {"hotels": accessible},
    )
    hotels_pending = [row[0] for row in result.fetchall()]

    # User language preference
    lang_result = await db.execute(
        text("SELECT preferred_language FROM users WHERE upn = :upn"),
        {"upn": upn},
    )
    lang_row = lang_result.fetchone()
    user_language = lang_row[0] if lang_row and lang_row[0] else "es"

    system_blocks = build_system_prompt(
        hotel_list=accessible,
        selected_hotels=request.selected_hotel_names,
        analysis_mode=analysis_mode,
        conversation_summary=conversation_summary,
        balance_eur=balance,
        hotels_pending_setup=hotels_pending,
        user_language=user_language,
    )

    # ------------------------------------------------------------------
    # Persist user message (before task starts)
    # ------------------------------------------------------------------
    await save_message(
        db, upn, "user", request.question,
        selected_hotels=request.selected_hotel_names,
    )
    await db.commit()

    # ------------------------------------------------------------------
    # Spawn background task + stream from queue
    # ------------------------------------------------------------------
    queue: asyncio.Queue = asyncio.Queue()

    task = asyncio.create_task(
        _run_chat_task(
            upn=upn,
            queue=queue,
            system_blocks=system_blocks,
            user_message=request.question,
            accessible_hotels=accessible,
            selected_hotel_names=request.selected_hotel_names,
            analysis_mode=analysis_mode,
            conversation_summary=conversation_summary,
            balance=balance,
        ),
    )
    _active_tasks[upn] = task
    _task_queues[upn] = queue

    async def event_stream():
        try:
            while True:
                event = await queue.get()
                if event is None:       # Sentinel — task finished
                    break
                yield _ndjson(event)
        except asyncio.CancelledError:
            # Client disconnected — task continues in background
            logger.info(
                "Client disconnected (user=%s). Background task continues.",
                upn,
            )

    return StreamingResponse(event_stream(), media_type="application/x-ndjson")
