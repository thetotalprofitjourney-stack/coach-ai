"""
Layer 2 (part 1): Microsoft Entra ID authentication (multi-tenant).

Validates the JWT Bearer token from the frontend, extracts the UPN.
The UPN is the user's identity — all downstream security checks use it.

Multi-tenant: accepts tokens from ANY Azure AD tenant. The app is registered
as multi-tenant in Entra ID, so users from any organization can authenticate.
Authorization (which users can actually use the app) is handled downstream
via the `users` and `user_hotel_access` tables.
"""

import logging
import re

import httpx
from fastapi import Depends, HTTPException, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt

from app.config import settings

logger = logging.getLogger(__name__)

bearer_scheme = HTTPBearer()

# Cache for Microsoft's JWKS (JSON Web Key Set)
_jwks_cache: dict | None = None

# Valid issuer pattern for multi-tenant: any Azure AD tenant ID (UUID format)
_ISSUER_PATTERN = re.compile(
    r"^https://login\.microsoftonline\.com/"
    r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/v2\.0$"
)


async def _get_jwks(force_refresh: bool = False) -> dict:
    """
    Fetch Microsoft's public signing keys from the common endpoint.

    Caches the result globally. Use force_refresh=True to invalidate the cache
    (needed when Microsoft rotates their signing keys and the cached JWKS
    no longer contains the kid referenced by a new token).
    """
    global _jwks_cache
    if _jwks_cache is None or force_refresh:
        jwks_url = (
            "https://login.microsoftonline.com/common/discovery/v2.0/keys"
        )
        async with httpx.AsyncClient() as client:
            resp = await client.get(jwks_url)
            resp.raise_for_status()
            _jwks_cache = resp.json()
        if force_refresh:
            logger.info("JWKS cache refreshed (key rotation detected)")
    return _jwks_cache


def _find_signing_key(jwks: dict, kid: str) -> dict | None:
    """Find the RSA public key matching the given kid in the JWKS."""
    for key in jwks.get("keys", []):
        if key["kid"] == kid:
            return key
    return None


async def get_current_upn(
    credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme),
) -> str:
    """
    FastAPI dependency — extracts and validates the UPN from the Bearer token.

    Returns the authenticated user's UPN (e.g. 'rm.mallorca@hotel.com').
    Raises 401 if the token is invalid, expired, or missing.

    Multi-tenant: accepts tokens from any Azure AD tenant. The issuer is
    validated against the token's own `tid` claim to prevent spoofing.

    SECURITY: The UPN comes from the cryptographically signed Microsoft token,
    NOT from the request body. The user cannot forge it.
    """
    token = credentials.credentials

    try:
        jwks = await _get_jwks()

        # Decode header to find the signing key
        unverified_header = jwt.get_unverified_header(token)
        kid = unverified_header.get("kid")

        # Find the matching public key
        rsa_key = _find_signing_key(jwks, kid)

        # Key not found — Microsoft may have rotated signing keys.
        # Refresh the JWKS cache once and retry.
        if rsa_key is None:
            logger.warning("kid '%s' not found in cached JWKS, refreshing…", kid)
            jwks = await _get_jwks(force_refresh=True)
            rsa_key = _find_signing_key(jwks, kid)

        if rsa_key is None:
            logger.error("kid '%s' not found even after JWKS refresh", kid)
            raise HTTPException(status_code=401, detail="Token signing key not found")

        # Verify and decode the token — skip issuer check here, validate manually below
        payload = jwt.decode(
            token,
            rsa_key,
            algorithms=["RS256"],
            audience=settings.azure_client_id,
            options={"verify_iss": False},
        )

        # Multi-tenant issuer validation: ensure issuer matches the token's tid claim
        issuer = payload.get("iss", "")
        tid = payload.get("tid", "")
        expected_issuer = f"https://login.microsoftonline.com/{tid}/v2.0"

        if not tid or issuer != expected_issuer or not _ISSUER_PATTERN.match(issuer):
            logger.warning("Invalid issuer: got '%s', expected '%s'", issuer, expected_issuer)
            raise HTTPException(status_code=401, detail="Invalid token issuer")

        # Extract UPN — Microsoft tokens use 'preferred_username' or 'upn'
        upn = payload.get("preferred_username") or payload.get("upn")
        if not upn:
            logger.error(
                "Token has no UPN claim. Available claims: %s",
                list(payload.keys()),
            )
            raise HTTPException(status_code=401, detail="Token does not contain UPN")

        logger.info("Authenticated: %s", upn.lower())
        return upn.lower()  # Normalize to lowercase

    except JWTError as e:
        logger.error("JWT validation failed: %s", e)
        raise HTTPException(status_code=401, detail=f"Invalid token: {e}")
