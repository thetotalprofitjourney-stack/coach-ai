"""
Layer 2 (part 2): Hotel access validation — security gate.
Layer 4: SQL validation — defense-in-depth.

Layer 2 runs BEFORE the AI is invoked:
  - Queries user_hotel_access to get the user's accessible hotels
  - Validates that ALL selected_hotel_names are in the accessible set
  - If ANY selected hotel is unauthorized → 403 Forbidden (AI is never called)

Layer 4 runs AFTER the AI generates SQL, BEFORE executing it:
  - Extracts hotel_name values from the AI-generated SQL
  - Validates they are all within the user's accessible hotels
  - If violation detected → blocks query, logs incident
"""

import re
import logging

from fastapi import HTTPException
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Layer 2: Pre-validation (security gate)
# ---------------------------------------------------------------------------
async def get_accessible_hotels(db: AsyncSession, upn: str) -> list[str]:
    """
    Returns the list of hotel_name values this user can access.
    Source of truth: user_hotel_access table.
    Uses LOWER() for case-insensitive matching because PowerBI may load
    UPNs with different casing than the backend (which normalizes to lowercase).
    """
    result = await db.execute(
        text("SELECT hotel_name FROM user_hotel_access WHERE LOWER(upn) = :upn"),
        {"upn": upn},
    )
    return [row[0] for row in result.fetchall()]


def validate_hotel_selection(
    selected: list[str], accessible: list[str]
) -> None:
    """
    Layer 2: Validates that every selected hotel is in the user's accessible set.

    Raises 403 Forbidden if ANY selected hotel is not authorized.
    This runs BEFORE the AI is invoked — if it fails, Claude is never called.
    """
    accessible_set = set(accessible)
    unauthorized = [h for h in selected if h not in accessible_set]

    if unauthorized:
        logger.warning(
            "SECURITY: User attempted to access unauthorized hotels: %s",
            unauthorized,
        )
        raise HTTPException(
            status_code=403,
            detail="No tienes acceso a uno o más hoteles seleccionados.",
        )


# ---------------------------------------------------------------------------
# Layer 4: SQL validation (defense-in-depth)
# ---------------------------------------------------------------------------
_HOTEL_NAME_PATTERN = re.compile(
    r"hotel_name\s+(?:=|IN)\s*\(\s*'([^']+)'(?:\s*,\s*'([^']+)')*\s*\)",
    re.IGNORECASE,
)

# Also catch single-value equality: hotel_name = 'Hotel X'
_HOTEL_NAME_EQUALS = re.compile(
    r"hotel_name\s*=\s*'([^']+)'",
    re.IGNORECASE,
)


def extract_hotel_names_from_sql(sql: str) -> set[str]:
    """
    Extracts hotel_name values from an AI-generated SQL string.
    Handles both: hotel_name IN ('A', 'B') and hotel_name = 'A'.
    """
    hotels = set()

    # Match IN (...) clauses
    for match in _HOTEL_NAME_PATTERN.finditer(sql):
        # Extract all values inside the IN clause
        in_clause = match.group(0)
        values = re.findall(r"'([^']+)'", in_clause)
        hotels.update(values)

    # Match = 'X' clauses
    for match in _HOTEL_NAME_EQUALS.finditer(sql):
        hotels.add(match.group(1))

    return hotels


def validate_sql_hotel_access(
    sql: str, accessible: list[str]
) -> None:
    """
    Layer 4: Validates that ALL hotel_name values in the AI-generated SQL
    are within the user's accessible hotels.

    This is the last-resort catch for prompt injection attacks.
    If the AI was tricked into generating SQL for an unauthorized hotel,
    this layer blocks execution.
    """
    hotels_in_sql = extract_hotel_names_from_sql(sql)

    if not hotels_in_sql:
        # No hotel_name found in SQL — could be a non-hotel query (e.g., credits)
        return

    accessible_set = set(accessible)
    unauthorized = hotels_in_sql - accessible_set

    if unauthorized:
        logger.critical(
            "SECURITY ALERT (Layer 4): AI generated SQL with unauthorized hotels. "
            "Hotels in SQL: %s. Unauthorized: %s. SQL: %s",
            hotels_in_sql,
            unauthorized,
            sql[:500],
        )
        raise HTTPException(
            status_code=500,
            detail="No se pudo completar la consulta.",
        )
