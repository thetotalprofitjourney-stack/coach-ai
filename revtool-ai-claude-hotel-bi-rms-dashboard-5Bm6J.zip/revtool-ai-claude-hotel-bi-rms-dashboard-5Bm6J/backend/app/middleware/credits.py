"""
Credit system — balance check, cost calculation, and consumption.

Pre-check: blocks the request if balance <= 0 (AI is never called).
Post-response: deducts cost atomically after successful AI response.

Cost calculation accounts for Anthropic prompt caching:
  - input_tokens          → base input rate
  - cache_creation_tokens → 1.25× base input rate
  - cache_read_tokens     → 0.1× base input rate
  - output_tokens         → output rate

All EUR costs include the configured cost multiplier (default ×3).
"""

import logging
from datetime import datetime, timezone

from fastapi import HTTPException
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings

logger = logging.getLogger(__name__)


async def check_balance(db: AsyncSession, upn: str) -> float:
    """
    Returns current balance. Raises 402 if insufficient.
    Called BEFORE invoking the AI.
    """
    result = await db.execute(
        text("SELECT balance_eur FROM credit_balance WHERE upn = :upn"),
        {"upn": upn},
    )
    row = result.fetchone()

    if row is None or row[0] <= 0:
        raise HTTPException(
            status_code=402,
            detail="Saldo insuficiente. Recarga crédito para continuar.",
        )

    return float(row[0])


async def get_daily_exchange_rate(db: AsyncSession) -> float:
    """
    Looks up today's USD→EUR rate from the exchange_rates table.
    Falls back to the static config value if no rate exists for today
    or if the table is not yet created / has no permissions.
    """
    try:
        result = await db.execute(
            text("SELECT usd_to_eur FROM exchange_rates WHERE rate_date = CURRENT_DATE")
        )
        row = result.fetchone()
        if row:
            return float(row[0])
    except Exception:
        # Table may not exist yet or user lacks permissions — use fallback
        try:
            await db.rollback()
        except Exception:
            pass
    return settings.usd_to_eur


def calculate_sonnet_cost(
    tokens_input: int,
    tokens_output: int,
    cache_creation_tokens: int = 0,
    cache_read_tokens: int = 0,
    usd_to_eur: float | None = None,
) -> float:
    """
    Calculates the EUR cost for a Sonnet interaction, including cache tokens.

    Anthropic prompt caching pricing (Sonnet):
      - input_tokens:          $3/MTok
      - cache_creation_tokens: $3.75/MTok (1.25x)
      - cache_read_tokens:     $0.30/MTok (0.1x)
      - output_tokens:         $15/MTok

    Formula: sum(token_type * rate) * cost_multiplier * usd_to_eur
    """
    if usd_to_eur is None:
        usd_to_eur = settings.usd_to_eur

    cost_input_usd = (tokens_input / 1000) * settings.price_input_per_1k
    cost_output_usd = (tokens_output / 1000) * settings.price_output_per_1k
    cost_cache_creation_usd = (cache_creation_tokens / 1000) * settings.price_cache_write_per_1k
    cost_cache_read_usd = (cache_read_tokens / 1000) * settings.price_cache_read_per_1k

    total_usd = cost_input_usd + cost_output_usd + cost_cache_creation_usd + cost_cache_read_usd
    total_with_multiplier = total_usd * settings.cost_multiplier
    return round(total_with_multiplier * usd_to_eur, 4)


def calculate_haiku_cost(
    tokens_input: int,
    tokens_output: int,
    cache_creation_tokens: int = 0,
    cache_read_tokens: int = 0,
    usd_to_eur: float | None = None,
) -> float:
    """
    Calculates the EUR cost for a Haiku interaction (summary), including cache tokens.

    Anthropic prompt caching pricing (Haiku):
      - input_tokens:          $1/MTok
      - cache_creation_tokens: $1.25/MTok (1.25x)
      - cache_read_tokens:     $0.10/MTok (0.1x)
      - output_tokens:         $5/MTok

    Formula: sum(token_type * rate) * cost_multiplier * usd_to_eur
    """
    if usd_to_eur is None:
        usd_to_eur = settings.usd_to_eur

    cost_input_usd = (tokens_input / 1000) * settings.price_haiku_input_per_1k
    cost_output_usd = (tokens_output / 1000) * settings.price_haiku_output_per_1k
    cost_cache_creation_usd = (cache_creation_tokens / 1000) * settings.price_haiku_cache_write_per_1k
    cost_cache_read_usd = (cache_read_tokens / 1000) * settings.price_haiku_cache_read_per_1k

    total_usd = cost_input_usd + cost_output_usd + cost_cache_creation_usd + cost_cache_read_usd
    total_with_multiplier = total_usd * settings.cost_multiplier
    return round(total_with_multiplier * usd_to_eur, 4)


# Keep old name as alias for backwards compatibility in imports
calculate_cost = calculate_sonnet_cost


async def deduct_and_log(
    db: AsyncSession,
    upn: str,
    tokens_input: int,
    tokens_output: int,
    cache_creation_tokens: int,
    cache_read_tokens: int,
    cost_eur: float,
    usd_to_eur: float,
    model: str,
    query_type: str = "text",
    analysis_mode: str | None = None,
    selected_hotels: list[str] | None = None,
) -> float:
    """
    Credit deduction + logging (does NOT commit — caller must commit).

    Returns balance_after. The UPDATE uses WHERE balance_eur >= cost_eur
    to prevent negative balance from race conditions.

    The caller is responsible for calling db.commit() after all operations
    in the transaction are complete.
    """
    now = datetime.now(timezone.utc)

    # 1. Deduct from balance (with race condition protection)
    result = await db.execute(
        text("""
            UPDATE credit_balance
            SET balance_eur = balance_eur - :cost,
                total_consumed = total_consumed + :cost,
                last_consumption_at = :now
            WHERE upn = :upn AND balance_eur >= :cost
            RETURNING balance_eur
        """),
        {"upn": upn, "cost": cost_eur, "now": now},
    )
    row = result.fetchone()

    if row is None:
        # Balance was insufficient (race condition: another request consumed it)
        raise HTTPException(
            status_code=402,
            detail="Saldo insuficiente. Recarga crédito para continuar.",
        )

    balance_after = float(row[0])

    # 2. Log token usage — use model-specific USD rates for the log columns
    if query_type == "summary":
        cost_input_usd = round((tokens_input / 1000) * settings.price_haiku_input_per_1k, 6)
        cost_output_usd = round((tokens_output / 1000) * settings.price_haiku_output_per_1k, 6)
        cost_cache_creation_usd = round((cache_creation_tokens / 1000) * settings.price_haiku_cache_write_per_1k, 6)
        cost_cache_read_usd = round((cache_read_tokens / 1000) * settings.price_haiku_cache_read_per_1k, 6)
    else:
        cost_input_usd = round((tokens_input / 1000) * settings.price_input_per_1k, 6)
        cost_output_usd = round((tokens_output / 1000) * settings.price_output_per_1k, 6)
        cost_cache_creation_usd = round((cache_creation_tokens / 1000) * settings.price_cache_write_per_1k, 6)
        cost_cache_read_usd = round((cache_read_tokens / 1000) * settings.price_cache_read_per_1k, 6)

    usage_result = await db.execute(
        text("""
            INSERT INTO token_usage_log
                (upn, model_used, tokens_input, tokens_output,
                 cache_creation_tokens, cache_read_tokens,
                 cost_input_usd, cost_output_usd,
                 cost_cache_creation_usd, cost_cache_read_usd,
                 cost_eur, usd_to_eur_rate,
                 query_type, hotels_queried, analysis_mode, created_at)
            VALUES
                (:upn, :model, :tin, :tout,
                 :cache_create, :cache_read,
                 :cost_in_usd, :cost_out_usd,
                 :cost_cache_create_usd, :cost_cache_read_usd,
                 :cost, :usd_to_eur,
                 :query_type, :hotels, :mode, :now)
            RETURNING id
        """),
        {
            "upn": upn,
            "model": model,
            "tin": tokens_input,
            "tout": tokens_output,
            "cache_create": cache_creation_tokens,
            "cache_read": cache_read_tokens,
            "cost_in_usd": cost_input_usd,
            "cost_out_usd": cost_output_usd,
            "cost_cache_create_usd": cost_cache_creation_usd,
            "cost_cache_read_usd": cost_cache_read_usd,
            "cost": cost_eur,
            "usd_to_eur": usd_to_eur,
            "query_type": query_type,
            "mode": analysis_mode,
            "hotels": selected_hotels,
            "now": now,
        },
    )
    token_usage_log_id = usage_result.fetchone()[0]

    # 3. Log credit transaction (linked to token_usage_log)
    total_tokens = tokens_input + tokens_output + cache_creation_tokens + cache_read_tokens
    desc_prefix = "Conversation summary" if query_type == "summary" else "AI interaction"
    await db.execute(
        text("""
            INSERT INTO credit_transactions
                (upn, transaction_type, amount_eur, balance_after,
                 token_usage_log_id, description, created_by)
            VALUES
                (:upn, 'consumption', :amount, :balance,
                 :log_id, :desc, 'system')
        """),
        {
            "upn": upn,
            "amount": -cost_eur,
            "balance": balance_after,
            "log_id": token_usage_log_id,
            "desc": f"{desc_prefix} ({model}, {total_tokens} tokens)",
        },
    )

    return balance_after
