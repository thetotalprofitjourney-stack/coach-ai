"""
Application configuration — loaded from environment variables.
See .env.example for all required variables.
"""

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # --- PostgreSQL ---
    database_url: str

    # --- Microsoft Entra ID (multi-tenant) ---
    azure_client_id: str

    # --- Anthropic (Claude) ---
    anthropic_api_key: str
    claude_sonnet_model: str = "claude-sonnet-4-5-20250929"
    claude_haiku_model: str = "claude-haiku-4-5-20251001"

    # --- Stripe ---
    stripe_secret_key: str
    stripe_publishable_key: str
    stripe_webhook_secret: str
    stripe_currency: str = "eur"
    stripe_min_amount_cents: int = 100
    stripe_max_amount_cents: int = 50000

    # --- Pricing (Sonnet — main AI model) ---
    price_input_per_1k: float = 0.003            # $3/MTok
    price_output_per_1k: float = 0.015           # $15/MTok
    price_cache_write_per_1k: float = 0.00375    # 1.25× base input (5-min TTL)
    price_cache_read_per_1k: float = 0.0003      # 0.1× base input (cache hit)

    # --- Pricing (Haiku — summarization model) ---
    price_haiku_input_per_1k: float = 0.001      # $1/MTok
    price_haiku_output_per_1k: float = 0.005     # $5/MTok
    price_haiku_cache_write_per_1k: float = 0.00125   # 1.25× haiku base
    price_haiku_cache_read_per_1k: float = 0.0001     # 0.1× haiku base

    cost_multiplier: float = 3  # Claude cost × 3, then convert to EUR
    usd_to_eur: float = 0.92  # Fallback when no daily rate in exchange_rates table

    # --- VAT ---
    vat_rate: float = 21.0  # Spanish IVA rate (applied to mainland + Balearic Islands)

    # --- Anthropic rate limiting ---
    # Controls the internal queue that prevents 429 errors from the API.
    anthropic_max_concurrent: int = 20      # Max simultaneous API calls
    anthropic_max_per_minute: int = 40      # Max API calls per rolling 60s window
    anthropic_queue_timeout: float = 0       # 0 = no timeout (wait indefinitely)

    # Token-per-minute limits per model (set at 80% of Tier 4 for safety margin).
    # Tier 4 actual: Sonnet 2M/400K, Haiku 4M/800K.
    anthropic_sonnet_input_tpm: int = 1_600_000
    anthropic_sonnet_output_tpm: int = 320_000
    anthropic_haiku_input_tpm: int = 3_200_000
    anthropic_haiku_output_tpm: int = 640_000

    # --- Data mode ---
    # "complete" = daily dimensional tables (segment/channel/roomtype/mealplan) available
    # "simple"   = only daily_hotel_summary + pricing; dimensional analysis is monthly only
    data_mode: str = "complete"

    # --- Docs / prompts ---
    docs_dir: str = ""  # Absolute path to docs/ dir; auto-detected if empty

    # --- App ---
    app_host: str = "0.0.0.0"
    app_port: int = 8000
    cors_origins: list[str] = ["http://localhost:3000"]
    # Production: set CORS_ORIGINS=["http://localhost:3000","https://revtool.thetotalprofitjourney.com"]

    # --- Email (SMTP for automated reports) ---
    smtp_host: str = "cp7110.webempresa.eu"
    smtp_port: int = 465
    smtp_user: str = ""
    smtp_password: str = ""
    smtp_from_email: str = "noreply@thetotalprofitjourney.com"
    smtp_from_name: str = "Revtool AI"
    smtp_ssl: bool = True  # True = SMTP_SSL (port 465), False = STARTTLS (port 587)
    smtp_timeout: int = 30  # Connection timeout in seconds

    # --- Cron jobs ---
    cron_secret: str = ""  # Shared secret to authenticate cron HTTP calls

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8", "extra": "ignore"}


settings = Settings()
