"""
Revtool AI — FastAPI application entry point.

Start with: uvicorn app.main:app --host 0.0.0.0 --port 8000
"""

import logging

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.base import BaseHTTPMiddleware

from app.config import settings
from app.routers import billing_profile, chat, email_reports, hotels, jobs, messages, session, stripe_routes

# Logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)

logger = logging.getLogger(__name__)

app = FastAPI(
    title="Revtool AI",
    description="Revenue Management AI Assistant API",
    version="1.0.0",
)


# Request logging middleware — logs method, path, origin for debugging 4xx/5xx
class RequestLoggingMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)
        if response.status_code >= 400:
            logger.warning(
                "%s %s → %d (origin=%s)",
                request.method,
                request.url.path,
                response.status_code,
                request.headers.get("origin", "none"),
            )
        return response


app.add_middleware(RequestLoggingMiddleware)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routes
app.include_router(session.router)
app.include_router(chat.router)
app.include_router(stripe_routes.router)
app.include_router(hotels.router)
app.include_router(billing_profile.router)
app.include_router(messages.router)
app.include_router(email_reports.router)
app.include_router(jobs.router)


@app.get("/health")
async def health():
    return {"status": "ok"}
