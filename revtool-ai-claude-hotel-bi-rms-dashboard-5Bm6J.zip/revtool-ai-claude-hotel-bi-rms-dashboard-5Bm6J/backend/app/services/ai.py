"""
AI orchestration service — builds prompts, calls Claude, executes SQL.

This is the core logic:
1. Builds the system prompt with injected variables
2. Calls Claude Sonnet for the main response
3. If Claude generates SQL → validates (Layer 4) → executes → feeds results back
4. Returns the final response + token counts (including cache tokens)

Supports two modes:
- chat()        — blocking, returns ChatResult when done
- chat_stream() — async generator, yields status/delta/done events for SSE
"""

import logging
import re
from collections.abc import AsyncGenerator
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from pathlib import Path

import anthropic
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.middleware.hotel_access import validate_sql_hotel_access
from app.services.rate_limiter import get_limiter

logger = logging.getLogger(__name__)


@dataclass
class ChatResult:
    """Structured result from an AI chat interaction."""
    text: str
    tokens_input: int = 0
    tokens_output: int = 0
    cache_creation_tokens: int = 0
    cache_read_tokens: int = 0
    sql_queries_attempted: int = 0
    sql_queries_succeeded: int = 0
    sql_queries_failed: int = 0
    turns_used: int = 0

# Load the system prompt template once at startup
def _resolve_docs_dir() -> Path:
    """Return the docs directory.  Uses DOCS_DIR env/setting when set (Docker),
    otherwise walks up from this file to the project root (local dev)."""
    if settings.docs_dir:
        return Path(settings.docs_dir)
    # Local dev: backend/app/services/ai.py  →  parents[3] = project root
    return Path(__file__).resolve().parents[3] / "docs"

_PROMPT_TEMPLATE_PATH = _resolve_docs_dir() / "ai_system_prompt.md"
_prompt_cache: dict[str, str] = {}

# Patterns for conditional blocks
_COMPLETE_BLOCK = re.compile(
    r"\{BEGIN_COMPLETE_MODE\}\n?(.*?)\{END_COMPLETE_MODE\}\n?",
    re.DOTALL,
)
_SIMPLE_BLOCK = re.compile(
    r"\{BEGIN_SIMPLE_MODE\}\n?(.*?)\{END_SIMPLE_MODE\}\n?",
    re.DOTALL,
)


def _load_prompt_template(data_mode: str) -> str:
    """
    Load the system prompt template and resolve conditional blocks.

    data_mode = "complete": keeps COMPLETE blocks, strips SIMPLE blocks.
    data_mode = "simple":   keeps SIMPLE blocks, strips COMPLETE blocks.

    Cached per mode so the regex processing only runs once per mode.
    """
    if data_mode not in _prompt_cache:
        raw = _PROMPT_TEMPLATE_PATH.read_text(encoding="utf-8")
        # Extract only the content inside the outermost ``` ``` code block.
        # Use line-anchored pattern (^ and $) so inline backticks like
        # ```sql``` and indented code examples (   ```sql ... ```) are
        # not mistaken for the closing fence.
        match = re.search(r"^```\n(.*?)^```$", raw, re.DOTALL | re.MULTILINE)
        template = match.group(1) if match else raw

        if data_mode == "simple":
            # Remove COMPLETE blocks entirely, keep SIMPLE block content
            template = _COMPLETE_BLOCK.sub("", template)
            template = _SIMPLE_BLOCK.sub(r"\1", template)
        else:
            # Remove SIMPLE blocks entirely, keep COMPLETE block content
            template = _SIMPLE_BLOCK.sub("", template)
            template = _COMPLETE_BLOCK.sub(r"\1", template)

        _prompt_cache[data_mode] = template

    return _prompt_cache[data_mode]


def build_system_prompt(
    hotel_list: list[str],
    selected_hotels: list[str],
    analysis_mode: str,
    conversation_summary: str,
    balance_eur: float,
    hotels_pending_setup: list[str],
    user_language: str = "es",
) -> list[dict]:
    """
    Builds the system prompt as TWO content blocks for optimal prompt caching.

    Block 1 (CACHED): Static instructions with per-user placeholders replaced by
    generic labels (HOTELES_ACCESIBLES, SALDO_USUARIO, etc.). Only date/year values
    are baked in — they change daily but are identical for ALL users, so the entire
    block is shared across users within the same day+data_mode.

    Block 2 (NOT CACHED): Dynamic session context that maps the generic labels to
    the actual per-user values (hotel list, balance, summary, etc.).

    This separation means:
    - First request of the day creates the cache (~14k tokens, cache write)
    - All subsequent requests read from cache (~14k tokens at 0.1x cost)
    - Only the ~1k-token session context is sent fresh each time
    """
    template = _load_prompt_template(settings.data_mode)
    today = date.today()

    # Static part: resolve dates (same for all users) + replace per-user
    # placeholders with descriptive labels that reference SESSION CONTEXT
    static = (
        template
        .replace("{current_date}", today.isoformat())
        .replace("{current_year}", str(today.year))
        .replace("{current_year - 1}", str(today.year - 1))
        .replace("{current_year + 1}", str(today.year + 1))
        .replace("{hotel_list}", "HOTELES_ACCESIBLES")
        .replace("{selected_hotels}", "HOTELES_SELECCIONADOS")
        .replace("{analysis_mode}", "MODO_ANÁLISIS")
        .replace("{conversation_summary}", "RESUMEN_CONVERSACIÓN")
        .replace("{balance_eur}", "SALDO_USUARIO")
        .replace("{hotels_pending_setup}", "HOTELES_PENDIENTES")
        .replace("{hotel_names}", "HOTELES_SELECCIONADOS_SQL")
    )

    # Dynamic part: actual per-user values
    pending = ", ".join(hotels_pending_setup) if hotels_pending_setup else "Ninguno"
    summary = conversation_summary or "(vacío — sesión nueva)"
    hotels_sql = ", ".join("'%s'" % h for h in selected_hotels)

    lang_label = {"es": "español", "en": "English"}.get(user_language, "español")
    lang_instruction = (
        f"\n\n- IDIOMA_USUARIO: {lang_label}\n"
        "  REGLA OBLIGATORIA: El usuario ha seleccionado este idioma en la interfaz. "
        "DEBES responder SIEMPRE en este idioma, independientemente del idioma de las "
        "instrucciones de sistema o del prompt. Los nombres de métricas (OTB, SDLY, ADR, "
        "RevPAR, etc.) se mantienen en su forma original.\n"
        "  CALIDAD: Tu respuesta debe tener EXACTAMENTE la misma profundidad, detalle, "
        "estructura y calidad analítica que darías en español. No resumas más, no simplifiques, "
        "no acortes tablas ni omitas secciones. Mantén el mismo nivel de análisis operativo, "
        "las mismas recomendaciones detalladas y el mismo tono profesional de revenue management. "
        "Traduce conceptos del sector hotelero de forma natural (ej: 'estancia mínima' → 'minimum stay', "
        "'cierre de intermediarios' → 'intermediary closure', 'ocupación' → 'occupancy'). "
        "La respuesta en cualquier idioma debe ser igual de completa y útil."
    )

    dynamic = (
        "CONTEXTO DE SESIÓN ACTUAL:\n"
        "Los siguientes valores sustituyen las referencias en las instrucciones anteriores.\n\n"
        f"- HOTELES_ACCESIBLES: {', '.join(hotel_list)}\n"
        f"- HOTELES_SELECCIONADOS: {', '.join(selected_hotels)}\n"
        f"- HOTELES_SELECCIONADOS_SQL: {hotels_sql}\n"
        f"- HOTELES_PENDIENTES: {pending}\n"
        f"- MODO_ANÁLISIS: {analysis_mode}\n"
        f"- RESUMEN_CONVERSACIÓN: {summary}\n"
        f"- SALDO_USUARIO: {balance_eur:.2f}€"
        f"{lang_instruction}"
    )

    return [
        {"type": "text", "text": static, "cache_control": {"type": "ephemeral"}},
        {"type": "text", "text": dynamic},
    ]


# ---------------------------------------------------------------------------
# SQL extraction + execution
# ---------------------------------------------------------------------------
_SQL_BLOCK_PATTERN = re.compile(r"```sql\s*(.*?)```", re.DOTALL | re.IGNORECASE)


def extract_sql_from_response(response_text: str) -> list[str]:
    """Extracts SQL queries from ```sql ... ``` blocks in the AI response."""
    return [match.group(1).strip() for match in _SQL_BLOCK_PATTERN.finditer(response_text)]


async def execute_sql_safely(
    db: AsyncSession,
    sql: str,
    accessible_hotels: list[str],
) -> list[dict]:
    """
    Layer 4 + execution: validates the SQL, then runs it read-only.

    - Validates hotel_name values in the SQL against the user's accessible hotels
    - Blocks any query that references unauthorized hotels
    - Executes read-only (SELECT only)
    - Sets a 30-second statement timeout to prevent hanging queries
    """
    # Layer 4: validate hotel names in SQL
    validate_sql_hotel_access(sql, accessible_hotels)

    # Safety: only allow SELECT statements (strip leading SQL comments first)
    normalized = re.sub(r"--[^\n]*\n", "", sql).strip().upper()
    if not normalized.startswith("SELECT"):
        logger.warning("SECURITY: AI generated non-SELECT SQL: %s", sql[:200])
        return []

    # Set statement timeout to prevent hanging queries from exhausting the pool
    await db.execute(text("SET LOCAL statement_timeout = '60s'"))
    result = await db.execute(text(sql))
    columns = list(result.keys())
    return [dict(zip(columns, row)) for row in result.fetchall()]


# ---------------------------------------------------------------------------
# Main AI call
# ---------------------------------------------------------------------------
_client: anthropic.AsyncAnthropic | None = None


def _get_client() -> anthropic.AsyncAnthropic:
    global _client
    if _client is None:
        _client = anthropic.AsyncAnthropic(
            api_key=settings.anthropic_api_key,
            max_retries=1,  # default=2; avoid 40-57s retry-after waits that cause 504
        )
    return _client


async def chat(
    db: AsyncSession,
    system_blocks: list[dict],
    user_message: str,
    accessible_hotels: list[str],
) -> ChatResult:
    """
    Main AI interaction loop:
    1. Send system prompt + user message to Claude Sonnet
    2. If response contains SQL → validate (Layer 4) → execute → send results back
    3. Return ChatResult with token counts (including cache tokens)

    The loop handles up to 5 turns:
      Turn 0: User question → Claude responds (may include SQL)
      Turn 1: SQL results → Claude formats the final answer (or generates new SQL)
      Turn 2-3: Additional SQL iterations for complex multi-step queries
      Turn 4: Final turn — any remaining SQL blocks are stripped

    On the final turn, any remaining SQL blocks are stripped so the user
    never sees raw SQL in the response.

    system_blocks is a list of content blocks (from build_system_prompt) with
    cache_control on the static block for cross-request prompt caching.
    """
    client = _get_client()
    messages = [{"role": "user", "content": user_message}]

    total_input = 0
    total_output = 0
    total_cache_creation = 0
    total_cache_read = 0
    total_sql_attempted = 0
    total_sql_succeeded = 0
    total_sql_failed = 0

    limiter = get_limiter()
    max_turns = 5
    for turn in range(max_turns):
        async with limiter.acquire(f"chat-turn-{turn}", model="sonnet"):
            response = await client.messages.create(
                model=settings.claude_sonnet_model,
                max_tokens=16384,
                system=system_blocks,
                messages=messages,
            )
        limiter.report_usage("sonnet", response.usage.input_tokens, response.usage.output_tokens)

        total_input += response.usage.input_tokens
        total_output += response.usage.output_tokens
        total_cache_creation += getattr(response.usage, "cache_creation_input_tokens", 0) or 0
        total_cache_read += getattr(response.usage, "cache_read_input_tokens", 0) or 0

        assistant_text = response.content[0].text

        # Check for SQL in the response
        sql_queries = extract_sql_from_response(assistant_text)

        if not sql_queries or turn == max_turns - 1:
            # No SQL or final turn → return, stripping any leftover SQL blocks
            final_text = _strip_sql_blocks(assistant_text) if sql_queries else assistant_text
            result = ChatResult(
                text=final_text,
                tokens_input=total_input,
                tokens_output=total_output,
                cache_creation_tokens=total_cache_creation,
                cache_read_tokens=total_cache_read,
                sql_queries_attempted=total_sql_attempted,
                sql_queries_succeeded=total_sql_succeeded,
                sql_queries_failed=total_sql_failed,
                turns_used=turn + 1,
            )
            logger.info(
                "AI chat completed: turns=%d, sql=%d/%d ok, tokens_in=%d, tokens_out=%d",
                result.turns_used,
                total_sql_succeeded, total_sql_attempted,
                total_input, total_output,
            )
            return result

        # Execute SQL queries and collect results
        all_results = []
        for sql in sql_queries:
            total_sql_attempted += 1
            try:
                rows = await execute_sql_safely(db, sql, accessible_hotels)
                all_results.append({"sql": sql, "rows": rows, "row_count": len(rows)})
                total_sql_succeeded += 1
            except Exception as e:
                total_sql_failed += 1
                logger.warning("SQL execution failed (turn %d): %s\nSQL: %s", turn, e, sql[:500])
                try:
                    await db.rollback()
                except Exception as rollback_err:
                    logger.error("Rollback also failed (connection may be dead): %s", rollback_err)
                all_results.append({"sql": sql, "error": str(e)})

        # Feed results back to Claude for formatting
        results_text = _format_sql_results(all_results)
        messages.append({"role": "assistant", "content": assistant_text})
        messages.append({"role": "user", "content": results_text})

    # Should not reach here, but just in case — strip SQL blocks
    result = ChatResult(
        text=_strip_sql_blocks(assistant_text),
        tokens_input=total_input,
        tokens_output=total_output,
        cache_creation_tokens=total_cache_creation,
        cache_read_tokens=total_cache_read,
        sql_queries_attempted=total_sql_attempted,
        sql_queries_succeeded=total_sql_succeeded,
        sql_queries_failed=total_sql_failed,
        turns_used=max_turns,
    )
    logger.info(
        "AI chat completed (max turns): turns=%d, sql=%d/%d ok, tokens_in=%d, tokens_out=%d",
        max_turns, total_sql_succeeded, total_sql_attempted,
        total_input, total_output,
    )
    return result


async def chat_stream(
    db: AsyncSession,
    system_blocks: list[dict],
    user_message: str,
    accessible_hotels: list[str],
) -> AsyncGenerator[dict, None]:
    """
    Streaming version of chat(). Yields events for SSE:

    - {"type": "status", "message": "..."}   — progress updates (keeps connection alive)
    - {"type": "delta",  "text": "..."}      — streamed response text
    - {"type": "done",   "result": ChatResult} — final result with token counts

    Intermediate turns use the non-streaming API (status events provide feedback).
    The last turn (turn 2) uses the streaming API so the user sees text appearing
    progressively. If a turn exits early (no SQL), the full text is sent as a
    single delta event.
    """
    client = _get_client()
    messages = [{"role": "user", "content": user_message}]

    total_input = 0
    total_output = 0
    total_cache_creation = 0
    total_cache_read = 0
    total_sql_attempted = 0
    total_sql_succeeded = 0
    total_sql_failed = 0

    limiter = get_limiter()
    max_turns = 5
    assistant_text = ""

    for turn in range(max_turns):
        is_last_turn = turn == max_turns - 1

        if turn == 0:
            queued = limiter.queued_count
            if queued > 0:
                yield {"type": "status", "message": f"En cola ({queued} consultas pendientes)..."}
            else:
                yield {"type": "status", "message": "Analizando consulta..."}
        else:
            yield {"type": "status", "message": "Procesando resultados..."}

        if is_last_turn:
            # Stream the final turn for progressive text display
            async with limiter.acquire(f"stream-turn-{turn}", model="sonnet"):
                async with client.messages.stream(
                    model=settings.claude_sonnet_model,
                    max_tokens=16384,
                    system=system_blocks,
                    messages=messages,
                ) as stream:
                    async for chunk in stream.text_stream:
                        yield {"type": "delta", "text": chunk}
                    response = await stream.get_final_message()
        else:
            async with limiter.acquire(f"stream-turn-{turn}", model="sonnet"):
                response = await client.messages.create(
                    model=settings.claude_sonnet_model,
                    max_tokens=16384,
                    system=system_blocks,
                    messages=messages,
                )
        limiter.report_usage("sonnet", response.usage.input_tokens, response.usage.output_tokens)

        # Update token counts
        total_input += response.usage.input_tokens
        total_output += response.usage.output_tokens
        total_cache_creation += getattr(response.usage, "cache_creation_input_tokens", 0) or 0
        total_cache_read += getattr(response.usage, "cache_read_input_tokens", 0) or 0

        assistant_text = response.content[0].text
        sql_queries = extract_sql_from_response(assistant_text)

        if not sql_queries or is_last_turn:
            final_text = _strip_sql_blocks(assistant_text) if sql_queries else assistant_text

            # Early exit (not last turn) — send full text as single delta
            if not is_last_turn:
                yield {"type": "delta", "text": final_text}

            result = ChatResult(
                text=final_text,
                tokens_input=total_input,
                tokens_output=total_output,
                cache_creation_tokens=total_cache_creation,
                cache_read_tokens=total_cache_read,
                sql_queries_attempted=total_sql_attempted,
                sql_queries_succeeded=total_sql_succeeded,
                sql_queries_failed=total_sql_failed,
                turns_used=turn + 1,
            )
            logger.info(
                "AI chat completed: turns=%d, sql=%d/%d ok, tokens_in=%d, tokens_out=%d",
                result.turns_used,
                total_sql_succeeded, total_sql_attempted,
                total_input, total_output,
            )
            yield {"type": "done", "result": result}
            return

        # Execute SQL queries
        num_queries = len(sql_queries)
        yield {
            "type": "status",
            "message": f"Ejecutando {num_queries} consulta{'s' if num_queries > 1 else ''} SQL...",
        }

        all_results = []
        for sql in sql_queries:
            total_sql_attempted += 1
            try:
                rows = await execute_sql_safely(db, sql, accessible_hotels)
                all_results.append({"sql": sql, "rows": rows, "row_count": len(rows)})
                total_sql_succeeded += 1
            except Exception as e:
                total_sql_failed += 1
                logger.warning("SQL execution failed (turn %d): %s\nSQL: %s", turn, e, sql[:500])
                try:
                    await db.rollback()
                except Exception as rollback_err:
                    logger.error("Rollback also failed (connection may be dead): %s", rollback_err)
                all_results.append({"sql": sql, "error": str(e)})

        results_text = _format_sql_results(all_results)
        messages.append({"role": "assistant", "content": assistant_text})
        messages.append({"role": "user", "content": results_text})


def _strip_sql_blocks(text: str) -> str:
    """Remove ```sql ... ``` blocks from text so raw SQL is never shown to the user."""
    return _SQL_BLOCK_PATTERN.sub("", text).strip()


def _format_sql_results(results: list[dict]) -> str:
    """Formats SQL query results as text for Claude to interpret."""
    parts = []
    for i, r in enumerate(results):
        if "error" in r:
            parts.append(f"Query {i + 1} error: {r['error']}")
        elif r["row_count"] == 0:
            parts.append(f"Query {i + 1}: No results returned.")
        else:
            # Format as a simple table
            rows = r["rows"]
            headers = list(rows[0].keys())
            lines = [" | ".join(headers)]
            for row in rows[:500]:  # Cap at 500 rows
                lines.append(" | ".join(str(row.get(h, "")) for h in headers))
            parts.append(f"Query {i + 1} ({r['row_count']} rows):\n" + "\n".join(lines))

    return "SQL query results:\n\n" + "\n\n".join(parts)
