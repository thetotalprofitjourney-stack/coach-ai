"""
Conversation message persistence — save and load individual messages (24h TTL).
"""

import logging
from datetime import datetime

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

logger = logging.getLogger(__name__)


async def save_message(
    db: AsyncSession,
    upn: str,
    role: str,
    content: str,
    cost_eur: float | None = None,
    balance_after: float | None = None,
    analysis_mode: str | None = None,
    selected_hotels: list[str] | None = None,
) -> None:
    """Insert a single message into conversation_messages."""
    await db.execute(
        text("""
            INSERT INTO conversation_messages
                (upn, role, content, cost_eur, balance_after, analysis_mode, selected_hotels)
            VALUES
                (:upn, :role, :content, :cost_eur, :balance_after, :analysis_mode, :selected_hotels)
        """),
        {
            "upn": upn,
            "role": role,
            "content": content,
            "cost_eur": cost_eur,
            "balance_after": balance_after,
            "analysis_mode": analysis_mode,
            "selected_hotels": selected_hotels,
        },
    )


async def load_messages(db: AsyncSession, upn: str) -> list[dict]:
    """
    Load messages from the last 24 hours for a user.
    Also purges messages older than 24h.
    """
    # Purge old messages
    await db.execute(
        text("""
            DELETE FROM conversation_messages
            WHERE upn = :upn AND created_at < NOW() - INTERVAL '24 hours'
        """),
        {"upn": upn},
    )
    await db.commit()

    # Load recent messages
    result = await db.execute(
        text("""
            SELECT role, content, cost_eur, balance_after, analysis_mode, created_at
            FROM conversation_messages
            WHERE upn = :upn AND created_at >= NOW() - INTERVAL '24 hours'
            ORDER BY created_at ASC
        """),
        {"upn": upn},
    )

    messages = []
    for row in result.fetchall():
        msg: dict = {
            "role": row[0],
            "content": row[1],
            "timestamp": row[5].isoformat() if isinstance(row[5], datetime) else str(row[5]),
        }
        if row[2] is not None:
            msg["cost_eur"] = float(row[2])
        if row[3] is not None:
            msg["balance_after"] = float(row[3])
        if row[4] is not None:
            msg["analysis_mode"] = row[4]
        messages.append(msg)

    return messages
