"""
Conversation summary service — load and update rolling 48h summaries.

After each AI response, Haiku generates an updated summary synchronously
so its cost can be included in the total cost shown to the user.
Haiku token costs are logged separately in token_usage_log (query_type='summary').
"""

import logging
from dataclasses import dataclass

import anthropic
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings

logger = logging.getLogger(__name__)


@dataclass
class SummaryResult:
    """Token usage from the Haiku summarization call."""
    text: str
    tokens_input: int
    tokens_output: int
    cache_creation_tokens: int
    cache_read_tokens: int


async def load_summary(db: AsyncSession, upn: str) -> str:
    """
    Loads conversation summaries from the last 2 UTC calendar days.
    Concatenates them in chronological order.
    Also purges summaries older than 48h.
    """
    # Purge old summaries for this user (runs on every session load)
    await db.execute(
        text("""
            DELETE FROM conversation_summaries
            WHERE upn = :upn AND summary_date < CURRENT_DATE - INTERVAL '2 days'
        """),
        {"upn": upn},
    )
    await db.commit()

    # Load recent summaries
    result = await db.execute(
        text("""
            SELECT summary_text FROM conversation_summaries
            WHERE upn = :upn AND summary_date >= CURRENT_DATE - INTERVAL '2 days'
            ORDER BY summary_date ASC
        """),
        {"upn": upn},
    )

    rows = result.fetchall()
    if not rows:
        return ""

    return "\n\n".join(row[0] for row in rows)


async def generate_summary(
    previous_summary: str,
    user_message: str,
    ai_response: str,
) -> SummaryResult:
    """
    Calls Haiku to generate an updated conversation summary.

    Pure API call — no DB operations. The caller is responsible for
    saving the summary and logging/deducting the cost.
    """
    from app.services.rate_limiter import get_limiter

    client = anthropic.AsyncAnthropic(api_key=settings.anthropic_api_key)
    limiter = get_limiter()

    haiku_prompt = f"""You are a summarization assistant. Your job is to maintain a detailed,
cumulative summary of a revenue management conversation.

Previous summary (may be empty if this is the first interaction today):
{previous_summary or '(empty — first interaction)'}

New exchange:
User: {user_message}
Assistant: {ai_response[:6000]}

Generate an updated cumulative summary that integrates the new exchange into the
previous summary. IMPORTANT: Organize the summary by hotel, using this structure:

## [Hotel Name] — [Date or period analyzed]
- Key metrics discussed (OTB, SDLY, pickup, cancellations, ADR, RevPAR, etc.)
- Recommendations given
- Decisions pending or actions taken
- Files analyzed (if any — content summary, not the file itself)

(Repeat for each hotel discussed)

## General / Cross-hotel
- Any cross-hotel comparisons or general topics discussed

Rules:
- Do NOT omit relevant information. Include all key data points, numbers, and recommendations.
- If multiple hotels were discussed, keep each hotel's section separate and clear.
- If only one hotel was discussed, use a single section for that hotel.
- Write in the same language as the conversation.
- Be thorough but avoid redundancy — merge repeated topics within the same hotel section.
Output ONLY the summary text, nothing else."""

    async with limiter.acquire("haiku-summary", model="haiku"):
        response = await client.messages.create(
            model=settings.claude_haiku_model,
            max_tokens=1024,
            messages=[{"role": "user", "content": haiku_prompt}],
        )
    limiter.report_usage("haiku", response.usage.input_tokens, response.usage.output_tokens)

    return SummaryResult(
        text=response.content[0].text,
        tokens_input=response.usage.input_tokens,
        tokens_output=response.usage.output_tokens,
        cache_creation_tokens=getattr(response.usage, "cache_creation_input_tokens", 0) or 0,
        cache_read_tokens=getattr(response.usage, "cache_read_input_tokens", 0) or 0,
    )


async def save_summary(db: AsyncSession, upn: str, summary_text: str) -> None:
    """UPSERT today's conversation summary."""
    await db.execute(
        text("""
            INSERT INTO conversation_summaries (upn, summary_date, summary_text)
            VALUES (:upn, CURRENT_DATE, :summary)
            ON CONFLICT (upn, summary_date) DO UPDATE
            SET summary_text = EXCLUDED.summary_text
        """),
        {"upn": upn, "summary": summary_text},
    )
