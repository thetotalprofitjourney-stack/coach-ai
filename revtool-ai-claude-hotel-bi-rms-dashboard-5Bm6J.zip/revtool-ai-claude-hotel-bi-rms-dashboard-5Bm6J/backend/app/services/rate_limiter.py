"""
Anthropic API rate limiter — queue-based concurrency, per-minute throttling,
and per-model token-per-minute (TPM) budget tracking.

Prevents 429 errors by limiting:
1. Max concurrent requests to the Anthropic API (asyncio.Semaphore)
2. Max requests per minute (sliding window with automatic wait)
3. Max input/output tokens per minute per model (sliding window)

When the limit is reached, new requests wait in the queue rather than
hitting the API and getting rejected.  If a request waits longer than
``queue_timeout`` seconds it raises ``QueueTimeoutError`` so the caller
can return a friendly message to the user.

Usage:
    from app.services.rate_limiter import get_limiter

    limiter = get_limiter()
    async with limiter.acquire("sonnet", model="sonnet"):
        response = await client.messages.create(...)
    limiter.report_usage("sonnet", response.usage.input_tokens, response.usage.output_tokens)
"""

import asyncio
import logging
import time
from collections import deque
from contextlib import asynccontextmanager
from dataclasses import dataclass

logger = logging.getLogger(__name__)


class QueueTimeoutError(Exception):
    """Raised when a request has waited too long in the queue."""


@dataclass(frozen=True)
class TokenLimits:
    """Input and output token-per-minute limits for a model."""
    input_tpm: int
    output_tpm: int


class AnthropicRateLimiter:
    """
    Async rate limiter combining concurrency + per-minute windowing + TPM budgets.

    Parameters
    ----------
    max_concurrent : int
        Max simultaneous in-flight API calls.
    max_per_minute : int
        Max API calls started within any rolling 60-second window.
    queue_timeout : float
        Seconds a request will wait in the queue before raising
        ``QueueTimeoutError``.  Set to 0 for no timeout.
    token_limits : dict[str, TokenLimits] | None
        Per-model token budgets.  Keys are short model names (e.g. "sonnet",
        "haiku").  When provided, ``acquire()`` also waits until the
        model's rolling 60-second token window has room.
    """

    def __init__(
        self,
        max_concurrent: int = 20,
        max_per_minute: int = 40,
        queue_timeout: float = 0,
        token_limits: dict[str, TokenLimits] | None = None,
    ) -> None:
        self._max_concurrent = max_concurrent
        self._semaphore = asyncio.Semaphore(max_concurrent)
        self._max_per_minute = max_per_minute
        self._queue_timeout = queue_timeout

        # Sliding window: timestamps (monotonic) of recent API call starts
        self._window: deque[float] = deque()
        self._lock = asyncio.Lock()

        # Token-per-minute tracking per model
        # Each entry: deque of (timestamp, input_tokens, output_tokens)
        self._token_limits: dict[str, TokenLimits] = token_limits or {}
        self._token_windows: dict[str, deque[tuple[float, int, int]]] = {
            model: deque() for model in self._token_limits
        }
        self._token_lock = asyncio.Lock()

        # Metrics
        self._total_queued = 0
        self._total_completed = 0
        self._total_timeouts = 0
        self._total_token_waits = 0

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    @asynccontextmanager
    async def acquire(self, label: str = "", model: str = ""):
        """
        Async context manager that waits for an available slot.

        Blocks until:
        - A concurrency slot is free (semaphore)
        - The per-minute request window has room
        - The per-model token budget has room (if model is specified)

        Raises ``QueueTimeoutError`` if the combined wait exceeds
        ``queue_timeout``.
        """
        entered = time.monotonic()
        self._total_queued += 1
        remaining = self._queue_timeout

        # 1) Wait for concurrency slot
        try:
            await asyncio.wait_for(
                self._semaphore.acquire(),
                timeout=remaining if remaining > 0 else None,
            )
        except asyncio.TimeoutError:
            self._total_timeouts += 1
            raise QueueTimeoutError(
                f"Request '{label}' timed out waiting for a concurrency slot "
                f"after {self._queue_timeout:.0f}s"
            )

        try:
            # 2) Wait for per-minute request window slot
            elapsed = time.monotonic() - entered
            remaining = max(0.0, self._queue_timeout - elapsed) if self._queue_timeout > 0 else 0

            await self._wait_for_window_slot(label, remaining)

            # 3) Wait for per-model token budget (if model specified)
            if model and model in self._token_limits:
                elapsed = time.monotonic() - entered
                remaining = max(0.0, self._queue_timeout - elapsed) if self._queue_timeout > 0 else 0
                await self._wait_for_token_budget(model, label, remaining)

            # Record this call in the request window
            async with self._lock:
                self._window.append(time.monotonic())

            queue_time = time.monotonic() - entered
            if queue_time > 1.0:
                logger.info(
                    "Rate limiter: '%s' waited %.1fs in queue (concurrent=%d, window=%d/%d)",
                    label, queue_time,
                    self.active_count, len(self._window), self._max_per_minute,
                )

            yield

        finally:
            self._semaphore.release()
            self._total_completed += 1

    def report_usage(self, model: str, input_tokens: int, output_tokens: int) -> None:
        """
        Record actual token usage after an API call completes.

        Must be called after the ``acquire()`` context exits so the
        sliding token window reflects real consumption.  Thread-safe
        (uses the event-loop; call from the same async context).
        """
        if model not in self._token_limits:
            return
        window = self._token_windows[model]
        window.append((time.monotonic(), input_tokens, output_tokens))

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    async def _wait_for_window_slot(self, label: str, timeout: float) -> None:
        """
        Sleeps until the sliding 60-second request window has room.
        """
        deadline = time.monotonic() + timeout if timeout > 0 else float("inf")

        while True:
            now = time.monotonic()

            async with self._lock:
                cutoff = now - 60.0
                while self._window and self._window[0] < cutoff:
                    self._window.popleft()

                if len(self._window) < self._max_per_minute:
                    return

                wait_until = self._window[0] + 60.0

            sleep_for = wait_until - now + 0.05

            if time.monotonic() + sleep_for > deadline:
                self._total_timeouts += 1
                raise QueueTimeoutError(
                    f"Request '{label}' timed out waiting for rate limit window"
                )

            logger.debug(
                "Rate limiter: '%s' waiting %.1fs for per-minute window (%d/%d)",
                label, sleep_for, len(self._window), self._max_per_minute,
            )
            await asyncio.sleep(sleep_for)

    async def _wait_for_token_budget(self, model: str, label: str, timeout: float) -> None:
        """
        Sleeps until the model's rolling 60-second token window has room.

        Checks both input and output token budgets.  If either is exceeded,
        waits until the oldest entry expires to free up capacity.
        """
        limits = self._token_limits[model]
        window = self._token_windows[model]
        deadline = time.monotonic() + timeout if timeout > 0 else float("inf")

        while True:
            now = time.monotonic()
            cutoff = now - 60.0

            async with self._token_lock:
                # Prune expired entries
                while window and window[0][0] < cutoff:
                    window.popleft()

                # Sum current window usage
                total_input = sum(entry[1] for entry in window)
                total_output = sum(entry[2] for entry in window)

                input_ok = total_input < limits.input_tpm
                output_ok = total_output < limits.output_tpm

                if input_ok and output_ok:
                    return

                # Need to wait — find the oldest entry to expire
                if window:
                    wait_until = window[0][0] + 60.0
                else:
                    return  # Empty window, should not happen but safe fallback

            sleep_for = wait_until - now + 0.05
            self._total_token_waits += 1

            if time.monotonic() + sleep_for > deadline:
                self._total_timeouts += 1
                raise QueueTimeoutError(
                    f"Request '{label}' timed out waiting for token budget "
                    f"(model={model}, input={total_input}/{limits.input_tpm}, "
                    f"output={total_output}/{limits.output_tpm})"
                )

            exceeded = []
            if not input_ok:
                exceeded.append(f"input={total_input}/{limits.input_tpm}")
            if not output_ok:
                exceeded.append(f"output={total_output}/{limits.output_tpm}")

            logger.info(
                "Rate limiter: '%s' waiting %.1fs for token budget (model=%s, %s)",
                label, sleep_for, model, ", ".join(exceeded),
            )
            await asyncio.sleep(sleep_for)

    # ------------------------------------------------------------------
    # Metrics (for monitoring / health checks)
    # ------------------------------------------------------------------

    @property
    def active_count(self) -> int:
        """Number of currently in-flight API calls."""
        return self._max_concurrent - self._semaphore._value  # type: ignore[attr-defined]

    @property
    def queued_count(self) -> int:
        """Approximate number of requests waiting."""
        return self._total_queued - self._total_completed - self.active_count

    def token_window_usage(self, model: str) -> dict:
        """Current token usage in the rolling 60s window for a model."""
        if model not in self._token_windows:
            return {}
        window = self._token_windows[model]
        now = time.monotonic()
        cutoff = now - 60.0
        # Don't mutate here — just read
        total_input = sum(e[1] for e in window if e[0] >= cutoff)
        total_output = sum(e[2] for e in window if e[0] >= cutoff)
        limits = self._token_limits.get(model)
        return {
            "input_tokens_used": total_input,
            "input_tokens_limit": limits.input_tpm if limits else 0,
            "output_tokens_used": total_output,
            "output_tokens_limit": limits.output_tpm if limits else 0,
        }

    @property
    def stats(self) -> dict:
        """Snapshot of rate limiter metrics."""
        base = {
            "active": self.active_count,
            "queued_approx": max(0, self.queued_count),
            "window_usage": len(self._window),
            "window_limit": self._max_per_minute,
            "total_completed": self._total_completed,
            "total_timeouts": self._total_timeouts,
            "total_token_waits": self._total_token_waits,
        }
        for model in self._token_limits:
            base[f"tokens_{model}"] = self.token_window_usage(model)
        return base


# ---------------------------------------------------------------------------
# Singleton — shared across the entire application
# ---------------------------------------------------------------------------
def _create_limiter() -> AnthropicRateLimiter:
    """Deferred import to avoid circular dependency with config."""
    from app.config import settings

    return AnthropicRateLimiter(
        max_concurrent=settings.anthropic_max_concurrent,
        max_per_minute=settings.anthropic_max_per_minute,
        queue_timeout=settings.anthropic_queue_timeout,
        token_limits={
            "sonnet": TokenLimits(
                input_tpm=settings.anthropic_sonnet_input_tpm,
                output_tpm=settings.anthropic_sonnet_output_tpm,
            ),
            "haiku": TokenLimits(
                input_tpm=settings.anthropic_haiku_input_tpm,
                output_tpm=settings.anthropic_haiku_output_tpm,
            ),
        },
    )


# Lazy singleton: initialized on first access
_limiter: AnthropicRateLimiter | None = None


def get_limiter() -> AnthropicRateLimiter:
    global _limiter
    if _limiter is None:
        _limiter = _create_limiter()
    return _limiter
