"""
Email report service — preconfigured prompts, queue builder, and scheduler.

Report types:
  1 = Diagnóstico diario — OTB status for next 60 days vs SDLY
  2 = Señales de pricing — pricing recommendations for next 30 days
  3 = Visión mensual — current month + next 2 months overview
  4 = Campañas online — campaign recommendations for the next 4 months
"""

import logging
from dataclasses import dataclass
from datetime import date, datetime, timezone

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Preconfigured report prompts (used by the scheduler)
# ---------------------------------------------------------------------------
REPORT_TITLES = {
    1: "Diagnóstico diario",
    2: "Señales de pricing",
    3: "Visión mensual",
    4: "Campañas online",
}

REPORT_TITLES_EN = {
    1: "Daily diagnostic",
    2: "Pricing signals",
    3: "Monthly overview",
    4: "Online campaigns",
}


def get_report_title(report_type: int, language: str = "es") -> str:
    """Get localized report title."""
    if language == "en":
        return REPORT_TITLES_EN.get(report_type, REPORT_TITLES.get(report_type, ""))
    return REPORT_TITLES.get(report_type, "")

_EMAIL_CONTEXT = (
    "IMPORTANTE: Este informe se enviará por email automáticamente. "
    "No incluyas frases conversacionales, preguntas al usuario ni invitaciones "
    "a pedir más información (el destinatario no puede responder). "
    "Sé directo y profesional. "
    "OBLIGATORIO: Debes consultar la base de datos con SQL para obtener datos reales. "
    "NO inventes ni estimes datos sin haberlos consultado primero."
)

REPORT_PROMPTS = {
    1: (
        "Dame un diagnóstico rápido del estado OTB de mi hotel para los próximos 60 días. "
        "Consulta la vista v_daily_summary (columnas clave: stay_date, rn_otb, revenue_otb, adr_otb, "
        "occ_otb, rn_sdly_gross, revenue_sdly_gross, adr_sdly_gross, occ_sdly_gross, "
        "pickup_rn_7d, pickup_rn_1d, cancel_rn_7d, cancel_rate_otb, cancel_rate_sdly, "
        "rn_forecast, occ_forecast, rooms_available, total_rooms). "
        "Compara OTB con SDLY bruto.\n\n"
        "ESTRUCTURA OBLIGATORIA — usa EXACTAMENTE estos 3 bloques como encabezados, en este orden:\n\n"
        "## RESUMEN EJECUTIVO\n"
        "Párrafo breve con la foto general del estado OTB: tendencia de ocupación, "
        "revenue y ADR vs SDLY para el período.\n\n"
        "## ALERTAS CRÍTICAS\n"
        "Lista de alertas concretas: días con ocupación baja, cancelaciones elevadas, "
        "pickup débil u otras anomalías detectadas. Presenta los datos de soporte en tabla compacta.\n\n"
        "## ACCIONES PRIORITARIAS\n"
        "Las 3 acciones prioritarias más relevantes derivadas de las alertas anteriores.\n\n"
        "No añadas otros bloques ni encabezados adicionales. " + _EMAIL_CONTEXT
    ),
    2: (
        "Muestra las señales de pricing para los próximos 30 días. "
        "Consulta la vista v_pricing_strategy (columnas: stay_date, price_delta, "
        "close_intermediaries, rooms_remaining, rooms_remaining_diff_prev, rooms_remaining_diff_next). "
        "Complementa con v_daily_summary para los mismos días (occ_otb, occ_sdly_gross, rn_otb) "
        "y así dar contexto de ocupación a cada señal de pricing.\n\n"
        "ESTRUCTURA OBLIGATORIA — usa EXACTAMENTE estos 3 bloques como encabezados, en este orden:\n\n"
        "## TABLA DE ESTRATEGIA DIARIA\n"
        "Tabla con TODOS los días de los próximos 30 días, una fila por día. "
        "Columnas obligatorias:\n"
        "- Fecha (stay_date)\n"
        "- Price Delta (variación de precio a aplicar, de v_pricing_strategy.price_delta)\n"
        "- Cierre Interm. (Sí / No, de close_intermediaries)\n"
        "- Hab. Libres (rooms_remaining)\n"
        "- Est. Mínima (recomienda si aplicar estancia mínima y de cuántas noches basándote en "
        "rooms_remaining y rooms_remaining_diff_prev/next; si no procede, 'No')\n"
        "- Occ OTB (occ_otb de v_daily_summary)\n"
        "- Occ SDLY (occ_sdly_gross de v_daily_summary)\n"
        "- Variación OCC (diferencia entre Occ OTB y Occ SDLY en puntos porcentuales)\n\n"
        "## PLAN DE ACCIÓN POR PERÍODO\n"
        "Agrupa los días en períodos con comportamiento similar y describe las acciones "
        "concretas a tomar para cada período (subidas, bajadas, cierres, estancias mínimas, etc.).\n\n"
        "## RESUMEN EJECUTIVO\n"
        "Párrafo breve con la visión general de la estrategia de pricing para el período.\n\n"
        "REGLA DE COHERENCIA OBLIGATORIA: Tu interpretación en 'Plan de acción' y 'Resumen ejecutivo' "
        "NUNCA puede contradecir los datos de la tabla. Los datos son la fuente de verdad. "
        "Si la tabla dice price_delta = -9€, tu texto DEBE respetar esa bajada como acción principal. "
        "Si la ocupación OTB es superior a SDLY, no digas que va por debajo. "
        "Puedes añadir contexto y matices, pero los datos mandan siempre — nunca inviertas "
        "el sentido de lo que reflejan las cifras.\n\n"
        "No añadas otros bloques ni encabezados adicionales. " + _EMAIL_CONTEXT
    ),
    3: (
        "Dame una visión del mes actual y los dos meses siguientes. "
        "Consulta la vista v_monthly_summary (columnas clave: year, month_num, "
        "rn_otb, revenue_otb, adr_otb, occ_otb, rn_sdly_gross, revenue_sdly_gross, "
        "adr_sdly_gross, occ_sdly_gross, rn_forecast, revenue_forecast, adr_forecast, occ_forecast, "
        "rn_budget, revenue_budget, adr_budget, occ_budget, "
        "pickup_rn_7d, pickup_rev_7d, cancel_rate_otb, cancel_rate_sdly, rooms_available, total_rooms).\n\n"
        "ESTRUCTURA OBLIGATORIA — usa EXACTAMENTE estos 4 bloques como encabezados, en este orden:\n\n"
        "## TABLA COMPARATIVA\n"
        "Para cada mes (actual + 2 siguientes), tabla con OCC, ADR y RevPAR comparando: "
        "OTB vs SDLY Bruto vs Budget vs Forecast. "
        "NO incluyas datos de benchmark del sector ni comparativas sectoriales, solo datos propios del hotel.\n\n"
        "## PICKUP Y CANCELACIONES\n"
        "Para cada mes, muestra el pickup acumulado de 7 días (rn y revenue) y las tasas de "
        "cancelación OTB vs SDLY. Destaca tendencias o anomalías.\n\n"
        "## DIAGNÓSTICO\n"
        "Párrafo breve con la interpretación del estado de cada mes: "
        "si va por encima o por debajo de budget/forecast/SDLY y por qué.\n\n"
        "## ACCIONES RECOMENDADAS\n"
        "Acciones concretas y operativas derivadas del diagnóstico anterior.\n\n"
        "No añadas otros bloques ni encabezados adicionales. "
        "No consultes ni menciones datos de benchmark del sector. " + _EMAIL_CONTEXT
    ),
    4: (
        "Recomienda las mejores campañas online para los próximos 4 meses de estancia. "
        "Sigue estos pasos obligatoriamente:\n\n"
        "1. Calcula el mes actual y los 4 meses siguientes de estancia (month_num). "
        "Para cada mes, calcula el booking_window correspondiente: "
        "months_diff = stay_month - current_month (si es negativo, suma 12). "
        "Mapeo: 0='en el mes', 1='entre 1 y 2 meses antes', 2='entre 2 y 3 meses antes', "
        "3='entre 3 y 4 meses antes', 4='entre 4 y 5 meses antes', "
        "5='entre 5 y 6 meses antes', 6='entre 6 y 7 meses antes', "
        "7='entre 7 y 8 meses antes', 8-11='entre 8 y 12 meses antes'.\n\n"
        "2. Consulta la tabla campaign_profiles "
        "(columnas: hotel_name, month_num, booking_window, occupancy_type, country_name, "
        "share_rn, avg_length_of_stay) filtrando por el hotel, los 4 month_num "
        "y el booking_window correspondiente a cada mes. "
        "Ordena por share_rn DESC para identificar los perfiles con mayor probabilidad de compra.\n\n"
        "3. Consulta v_monthly_summary para esos mismos meses y obtén el adr_otb y occ_otb actuales, "
        "y adr_sdly_gross y occ_sdly_gross del año anterior, para comparar rendimiento.\n\n"
        "4. Consulta dim_hotels para obtener el contexto del hotel: "
        "hotel_type, target_client, destination, province, city, country, marketing_highlights. "
        "Usa estos datos para personalizar los briefs de ejecución. "
        "Si marketing_highlights tiene contenido, úsalo como puntos fuertes del hotel "
        "en el copy y en el prompt de imagen. NO inventes características del hotel.\n\n"
        "5. Consulta monthly_hotel_mealplan para cada mes objetivo: "
        "SELECT meal_plan_name, share_rn_otb FROM monthly_hotel_mealplan "
        "WHERE hotel_name = el hotel AND month_num = mes AND year = año actual "
        "ORDER BY share_rn_otb DESC LIMIT 3. "
        "Usa el meal plan con mayor cuota para incluir el régimen real en el copy "
        "(ej: 'media pensión', 'solo alojamiento', 'todo incluido'). "
        "Si no hay datos, NO asumas ningún régimen.\n\n"
        "7. Para cada mes, presenta UNA TABLA con las campañas recomendadas "
        "(máximo 3-4 perfiles por mes, los de mayor share_rn). "
        "Columnas de la tabla:\n"
        "- País objetivo\n"
        "- Tipo de ocupación (Individual / Adultos / Familias)\n"
        "- %% cuota histórica (share_rn)\n"
        "- Estancia sugerida (avg_length_of_stay noches)\n"
        "Debajo de cada tabla, indica el ADR mixto de referencia del mes como dato contextual.\n\n"
        "8. Para el perfil PRIORITARIO de cada mes (el de mayor share_rn), genera un BRIEF DE "
        "EJECUCIÓN completo con esta estructura:\n\n"
        "**CAMPAÑA: [Título — ej: Familias alemanas · Julio]**\n\n"
        "▸ SEGMENTO\n"
        "  País, tipo de ocupación, anticipación, cuota histórica, estancia media.\n\n"
        "▸ CONFIGURACIÓN ADS\n"
        "  Plataforma sugerida (Meta Ads / Google Ads), segmentación geográfica, "
        "intereses (basados en occupancy_type + hotel_type + destination), "
        "rango de edad, fechas de campaña, formatos recomendados "
        "(Meta Feed 1080×1080, Stories 1080×1920, Google Display 1200×628).\n\n"
        "▸ COPY SUGERIDO (en el IDIOMA DEL MERCADO OBJETIVO)\n"
        "  Headline + descripción + CTA, todo en el idioma nativo del país objetivo "
        "(alemán para Alemania, francés para Francia, inglés para UK, etc.). "
        "Menciona el destino (destination), la duración sugerida y el régimen de alojamiento "
        "dominante obtenido de monthly_hotel_mealplan (H=solo alojamiento, HD=B&B, "
        "HMP=media pensión, HPC=pensión completa, HTI=todo incluido). "
        "El copy debe sonar nativo, no traducido.\n\n"
        "▸ PROMPT PARA IMAGEN\n"
        "  Prompt en inglés optimizado para generar imagen con IA (Midjourney, DALL-E, Canva AI). "
        "Debe incluir: escenario del hotel (basado en hotel_type + destination), "
        "escena humana (basada en occupancy_type), atmósfera según temporada del mes, "
        "y estilo fotográfico editorial (photorealistic, Canon EOS R5, 35mm, natural lighting). "
        "Añade nota: 'Usa este prompt con una foto real de tu hotel como referencia para "
        "mejores resultados.'\n\n"
        "7. Añade un bloque de ACCIONES RECOMENDADAS al final. "
        "No repitas lo que ya dicen las tablas ni los briefs. Sé operativo y concreto:\n"
        "- Para cada perfil prioritario, sugiere el TIPO DE CAMPAÑA concreto "
        "(ej: 'última hora', 'early booking', 'estancia mínima X noches', 'paquete escapada') "
        "con el perfil objetivo (ej: 'adultos españoles', 'familias francesas').\n"
        "- Si la ocupación OTB del mes va PEOR que SDLY (occ_otb < occ_sdly_gross), "
        "sugiere valor añadido o urgencia para estimular demanda.\n"
        "- Si la ocupación OTB del mes va IGUAL O MEJOR que SDLY, "
        "sugiere upgrades gratuitos o experiencias premium para proteger ADR.\n"
        "- PROHIBIDO sugerir precios, PVP, tarifas, 'desde X€' o cualquier importe. "
        "El precio lo decide el usuario. No calcules ni estimes precios de venta.\n\n"
        "Cierra con esta nota: 'Estos briefs son un punto de partida basado en datos históricos "
        "de tu hotel. Ajusta el copy, la segmentación y la imagen según tu conocimiento del "
        "mercado y la identidad visual de tu marca.'\n\n"
        + _EMAIL_CONTEXT
    ),
}


@dataclass
class ReportTask:
    """A single deduplicated task in the execution queue."""
    hotel_name: str
    report_type: int
    subscriber_upns: list[str]  # Users who enabled this (will be charged AND receive email)


@dataclass
class CustomReportTask:
    """A single custom report task — private to one user."""
    custom_report_id: int
    hotel_name: str
    title: str
    prompt: str
    upn: str  # Owner — charged and receives the email


async def build_report_queue(db: AsyncSession) -> list[ReportTask]:
    """
    Build the deduplicated execution queue from active subscriptions.

    Only includes subscriptions where today's weekday bit is set in the
    weekdays bitmask (bit 0 = Monday .. bit 6 = Sunday).

    Returns a list of ReportTask, one per unique (hotel_name, report_type).
    The AI is called once per task; the email is sent only to subscribers
    who enabled it for today (they are also the ones charged).
    """
    # Current weekday: Monday=0 .. Sunday=6
    today_bit = 1 << datetime.now(timezone.utc).weekday()

    # Get all enabled subscriptions for today's weekday
    result = await db.execute(
        text("""
            SELECT DISTINCT
                ers.hotel_name,
                ers.report_type,
                ers.upn AS subscriber_upn
            FROM email_report_subscriptions ers
            WHERE ers.enabled = TRUE
              AND (ers.weekdays & :today_bit) > 0
            ORDER BY ers.hotel_name, ers.report_type
        """),
        {"today_bit": today_bit},
    )

    # Group by (hotel, report_type)
    tasks_map: dict[tuple[str, int], list[str]] = {}
    for row in result.fetchall():
        key = (row[0], row[1])
        if key not in tasks_map:
            tasks_map[key] = []
        tasks_map[key].append(row[2])

    # Build tasks — subscribers are both charged and emailed
    tasks = []
    for (hotel_name, report_type), subscriber_upns in tasks_map.items():
        tasks.append(ReportTask(
            hotel_name=hotel_name,
            report_type=report_type,
            subscriber_upns=subscriber_upns,
        ))

    logger.info(
        "Built email report queue: %d tasks from %d subscriptions (weekday bit: %d)",
        len(tasks), sum(len(t.subscriber_upns) for t in tasks), today_bit,
    )
    return tasks


async def build_custom_report_queue(db: AsyncSession) -> list[CustomReportTask]:
    """
    Build the execution queue for custom (user-defined) reports.

    Only includes reports where today's weekday bit is set and the report is active.
    Returns one CustomReportTask per (custom_report_id, hotel_name).
    """
    today_bit = 1 << datetime.now(timezone.utc).weekday()

    result = await db.execute(
        text("""
            SELECT cr.id, cr.upn, cr.title, cr.prompt, crh.hotel_name
            FROM custom_email_reports cr
            JOIN custom_email_report_hotels crh ON crh.custom_report_id = cr.id
            WHERE cr.active = TRUE
              AND (cr.weekdays & :today_bit) > 0
            ORDER BY cr.upn, cr.id, crh.hotel_name
        """),
        {"today_bit": today_bit},
    )

    tasks = []
    for row in result.fetchall():
        tasks.append(CustomReportTask(
            custom_report_id=row[0],
            hotel_name=row[4],
            title=row[2],
            prompt=row[3],
            upn=row[1],
        ))

    logger.info(
        "Built custom report queue: %d tasks (weekday bit: %d)",
        len(tasks), today_bit,
    )
    return tasks


async def log_report_execution(
    db: AsyncSession,
    hotel_name: str,
    report_type: int,
    response_text: str,
    tokens_input: int,
    tokens_output: int,
    cost_eur: float,
    charged_upns: list[str],
    recipient_upns: list[str],
    email_sent: bool = False,
) -> None:
    """Log a completed report execution for auditing."""
    await db.execute(
        text("""
            INSERT INTO email_report_log
                (hotel_name, report_type, response_text, tokens_input, tokens_output,
                 cost_eur, charged_upns, recipient_upns, email_sent)
            VALUES
                (:hotel, :type, :text, :tin, :tout, :cost, :charged, :recipients, :email_sent)
        """),
        {
            "hotel": hotel_name,
            "type": report_type,
            "text": response_text,
            "tin": tokens_input,
            "tout": tokens_output,
            "cost": cost_eur,
            "charged": charged_upns,
            "recipients": recipient_upns,
            "email_sent": email_sent,
        },
    )
    await db.commit()
