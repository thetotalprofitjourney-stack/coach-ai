"""
Pydantic schemas for API request/response validation.
"""

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Chat
# ---------------------------------------------------------------------------
class ChatRequest(BaseModel):
    question: str = Field(..., min_length=1, max_length=10000)
    selected_hotel_names: list[str] = Field(..., min_length=1)


class ChatResponse(BaseModel):
    response: str
    analysis_mode: str
    cost_eur: float
    balance_after: float


# ---------------------------------------------------------------------------
# Stripe
# ---------------------------------------------------------------------------
class CreateCheckoutRequest(BaseModel):
    amount_eur: float = Field(..., gt=0)


class CreateCheckoutResponse(BaseModel):
    checkout_url: str


# ---------------------------------------------------------------------------
# Session / Auth
# ---------------------------------------------------------------------------
class SessionInfo(BaseModel):
    upn: str
    accessible_hotels: list[str]
    hotels_pending_setup: list[str]
    balance_eur: float
    conversation_summary: str
    billing_profile_complete: bool = False
    vat_applicable: bool | None = None
    vat_rate: float = 0.0
    maintenance_active: bool = False
    preferred_language: str = "es"


# ---------------------------------------------------------------------------
# Language preference
# ---------------------------------------------------------------------------
class LanguageUpdate(BaseModel):
    language: str = Field(..., pattern=r"^(es|en)$")


# ---------------------------------------------------------------------------
# Billing Profile
# ---------------------------------------------------------------------------
class BillingProfileUpdate(BaseModel):
    company_name: str = Field(..., min_length=1, max_length=300)
    tax_id: str = Field(..., min_length=1, max_length=30)
    notification_email: str = Field(..., min_length=1, max_length=300)
    address_line: str = Field(..., min_length=1, max_length=500)
    city: str = Field(..., min_length=1, max_length=200)
    province: str = Field(..., min_length=1, max_length=200)
    postal_code: str | None = Field(None, max_length=20)
    country: str = Field(..., min_length=1, max_length=100)


class BillingProfileResponse(BaseModel):
    upn: str
    company_name: str
    tax_id: str
    notification_email: str
    address_line: str
    city: str
    province: str
    postal_code: str | None
    country: str
    vat_applicable: bool
